package com.wdkj.plugs.extract.web;

import com.wdkj.plugs.core.model.to.Result;
import com.wdkj.plugs.extract.schedule.DatabaseBackupSchedule;
import com.wdkj.plugs.utils.enu.MessageEnum;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @ClassName UpdateSnmpRepeatController
 * @Description TODO
 * @Author Mr.xie
 * @Date 2021/7/15 15:34
 */
@RestController
@RequestMapping("/databaseBackup")
public class DatabaseBackupController {
    private static Logger logger = LoggerFactory.getLogger(DatabaseBackupController.class);
    @Autowired
    private DatabaseBackupSchedule databaseBackupSchedule;

    @PostMapping("/update")
    @ApiOperation(value = "定时数据备份", tags = "定时数据备份", httpMethod = "POST")
    public Result<?> update() {
        try {
            logger.info("-----定时数据备份开始-----");
            databaseBackupSchedule.execute();
            logger.info("-----定时数据备份结束-----");
            return new Result<>(MessageEnum.SUCCESS);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("定时数据备份失败={}" , e.getMessage());
            return new Result<>(MessageEnum.FAIL,e.getMessage());
        }
    }
}
