package com.wdkj.plugs.extract.schedule;

import com.wdkj.plugs.core.model.po.User;
import com.wdkj.plugs.core.service.IPasswordService;
import com.wdkj.plugs.core.service.IUserQueryService;
import com.wdkj.plugs.systemlog.service.ISystemLogService;
import com.wdkj.plugs.utils.enu.LogLevelEnum;
import com.wdkj.plugs.utils.enu.LogTypeEnum;
import com.wdkj.plugs.utils.enu.ServiceTypeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @ClassName
 * @Description 密码备份定时程序
 * @Author gy
 * @Date 2023年1月5日16:18:18
 */
@Component
public class PasswordCheckSchedule {
    private static Logger log = LoggerFactory.getLogger(PasswordCheckSchedule.class);

    @Autowired
    private IUserQueryService userQueryService;
    @Autowired
    private IPasswordService passwordService;
    @Autowired
    private ISystemLogService systemLogService;

    /**
     * 任务执行频率，默认2分钟执行一次
     */
    @Scheduled(cron = "0 0/2 * * * ? ")
    public void passwordRestore(){
        log.info("密码恢复定时任务开始");
        try {
            List<User> decryptUserList = userQueryService.getDecryptUserList();
            decryptUserList.stream().forEach(user -> {
                passwordService.passwordCheckRestore(user);
            });
            log.info("密码恢复定时任务结束");
        } catch (Exception e) {
            log.error("密码恢复定时任务报错:{}",e);
            systemLogService.saveLog(LogLevelEnum.LEVEL1.code(),e.getMessage(), ServiceTypeEnum.EXTRACT.lable(), LogTypeEnum.LOG_TYPE_ERROR.lable(),"密码恢复定时任务", this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }
}
