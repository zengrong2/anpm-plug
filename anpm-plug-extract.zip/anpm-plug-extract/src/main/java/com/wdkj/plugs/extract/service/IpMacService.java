package com.wdkj.plugs.extract.service;

public interface IpMacService {
    void excute();
}
