package com.wdkj.plugs.extract.service.impl;



import com.wdkj.plugs.extract.dao.mysql.IIndexSyncDao;
import com.wdkj.plugs.extract.service.IIndexSyncService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 数据抽取记录Service
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class IndexSyncServiceImpl implements IIndexSyncService {

    @Autowired
    private IIndexSyncDao indexSyncMapper;

    @Override
    public String getLastDateByName(String tableName) {
        return indexSyncMapper.getLastDateByName(tableName);
    }
}
