package com.wdkj.plugs.extract.dao.click;


import com.wdkj.plugs.model.vo.PathLinkDataVo;
import java.util.List;
import java.util.Set;

import org.apache.ibatis.annotations.Param;
import org.mapstruct.Mapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author lp
 *
 */
@Repository
@Mapper
public interface IPathLinkDataClickDao {

    List<PathLinkDataVo> getLinkDataList(@Param("tableName") String tableName,@Param("routeIds") List<Integer> routeIds,@Param("startTime")Long startTime,@Param("endTime")Long endTime);

    PathLinkDataVo getLinkData(@Param("query") PathLinkDataVo pathLinkDataVo);
}

