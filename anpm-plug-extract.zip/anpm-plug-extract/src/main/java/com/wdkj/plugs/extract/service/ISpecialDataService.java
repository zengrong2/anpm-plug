package com.wdkj.plugs.extract.service;


/**
 * @Author liuxf
 * @Date 2021/5/27 10:01
 */
public interface ISpecialDataService {
    void updatesJob();
}
