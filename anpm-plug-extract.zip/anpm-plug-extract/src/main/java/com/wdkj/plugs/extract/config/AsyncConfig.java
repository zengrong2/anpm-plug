package com.wdkj.plugs.extract.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * @author 郑兴泉 956607644@qq.com
 * @data 2025/4/17
 * 描述：
 */
//@Configuration
public class AsyncConfig {

    private static Logger log = LoggerFactory.getLogger(AsyncConfig.class);

    /**
     * Set the ThreadPoolExecutor's core pool size.
     * 线程池维护线程的最小数量.
     */
    @Value("${anpm.extract.core-pool-size:4}")
    private Integer corePoolSize;
    /**
     * Set the ThreadPoolExecutor's maximum pool size.
     * 线程池维护线程的最大数量
     */
    @Value("${anpm.extract.max-pool-size:10}")
    private Integer maxPoolSize;
    /**
     * Set the capacity for the ThreadPoolExecutor's BlockingQueue.
     * 队列最大长度
     */
    @Value("${anpm.extract.queue-size:100}")
    private Integer queueCapacity;


    @Bean(name = "taskExecutor")
    public ThreadPoolTaskExecutor taskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        // 核心线程数
        executor.setCorePoolSize(corePoolSize);
        // 最大线程数
        executor.setMaxPoolSize(maxPoolSize);
        // 队列容量
        executor.setQueueCapacity(queueCapacity);
        executor.setThreadNamePrefix("extract-async-thead-");
        // rejection-policy：当pool已经达到max size的时候，如何处理新任务
        // CALLER_RUNS：不在新线程中执行任务，而是有调用者所在的线程来执行
        executor.setRejectedExecutionHandler(new RejectedExecutionHandler() {

            @Override
            public void rejectedExecution(Runnable r, ThreadPoolExecutor e) {
                log.error("线程池已满，拒绝线程：{}", r);
                log.error("线程池已满 Task " + r.toString() + " rejected from " + e.toString());
                if (!e.isShutdown()) {
                    r.run();
                }
            }
        });
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.initialize();
        return executor;
    }
}
