package com.wdkj.plugs.extract.config;

import com.wdkj.plugs.core.constant.Constants;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.Parameter;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 
 * @author zj
 *
 */
@EnableSwagger2
@Configuration
public class PlugExtractAPIConfig {

	@Bean
	public Docket buildPlugExtractAPI() {
		ParameterBuilder tokenParameter = new ParameterBuilder();
		tokenParameter.name(Constants.TOKEN_ID).description("认证/令牌（ID）").modelRef(new ModelRef("string"))
				.parameterType("header").required(true).build();
		List<Parameter> operationParameters = new ArrayList<Parameter>();
		return new Docket(DocumentationType.SWAGGER_2).groupName("PlugExtractAPIGroup").apiInfo(new ApiInfoBuilder()
				// 页面标题
				.title("抽取工程")
				// 版本号
				.version("V2.2.0")
				// 描述
				.description("API 描述:<br>抽取工程<br>").build()).select()
				.apis(RequestHandlerSelectors.basePackage("com.wdkj.plugs.extract.web")).paths(PathSelectors.any())
				.build().securitySchemes(Collections.singletonList(new ApiKey("BASE_TOKEN", Constants.TOKEN_ID, "pass")))
				.globalOperationParameters(operationParameters);
	}

}