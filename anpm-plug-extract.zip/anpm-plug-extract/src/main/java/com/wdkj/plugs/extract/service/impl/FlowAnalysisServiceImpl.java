package com.wdkj.plugs.extract.service.impl;

import com.wdkj.plugs.core.support.DynamicTableContext;
import com.wdkj.plugs.extract.dao.click.IFlowAnalysisClickDao;
import com.wdkj.plugs.extract.dao.mysql.IFlowAnalysisDao;
import com.wdkj.plugs.extract.service.IFlowAnalysisService;
import com.wdkj.plugs.model.po.RunTimeRecordPo;
import com.wdkj.plugs.model.vo.FlowAnalysisDialogVo;
import com.wdkj.plugs.model.vo.SflowDataApply;
import com.wdkj.plugs.model.vo.SflowDataIpVo;
import com.wdkj.plugs.model.vo.SflowDataVo;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import ru.yandex.clickhouse.ClickHouseConnection;
import ru.yandex.clickhouse.ClickHouseDataSource;
import ru.yandex.clickhouse.ClickHousePreparedStatement;
import ru.yandex.clickhouse.ClickHouseStatement;
import ru.yandex.clickhouse.settings.ClickHouseProperties;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import org.springframework.beans.factory.annotation.Qualifier;
@Service
@Transactional(rollbackFor = Exception.class)
public class FlowAnalysisServiceImpl  implements IFlowAnalysisService {
    private static Logger log = LoggerFactory.getLogger(FlowAnalysisServiceImpl.class);
    @Autowired
    private IFlowAnalysisClickDao flowAnalysisClickDao;

    @Autowired
    private IFlowAnalysisDao flowAnalysisDao;
    //一次性插入数据库条数默认20w
    @Value("${extract-sflowAnalysis-saveCount:200000}")
    public Integer extractSflowAnalysisSaveCount;
    //检查天抽取范围默认90天
    @Value("${extract-sflowAnalysis-checkDays:90}")
    private Integer dayCount;
    //查询ip对数量条数限制默认100w
    @Value("${extract-sflowAnalysis-queryCount:1000000}")
    private Integer extractSflowAnalysisQueryCount;
    //查询应用数量条数限制默认100w
    @Value("${extract-sflowAnalysis-queryAppCount:1000000}")
    private Integer extractSflowAnalysisQueryAppCount;
    //处理设备线程数量默认5个
    @Value("${extract-sflowAnalysis-deviceThreadPool:5}")
    private Integer deviceThreadPool;

    //插入数据库线程数量默认2个
    @Value("${extract-sflowAnalysis-insertDataThreadPool:1}")
    private Integer insertDataThreadPool;
    /*private DataSource clickHouseDataSource;
    @Override
    public void setDataSource(DataSource dataSource) {
        this.clickHouseDataSource = dataSource;
    }*/
    private JdbcTemplate jdbcTemplate;
    @Autowired
    public void setJdbcTemplate(@Qualifier("clickDataSource") DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    /**
     * 处理应用天数据
     * @param type
     * @param hourType
     */
    @Override
    public void analysisDataAppOldDay(Integer type,Integer hourType) {
        try {
            //获取62天内所有没有抽取天
            List<Long> endTimeList = handelGetNotFinishDayRecord(type);
            //检查是否抽取了24小时的小时记录，如果抽取了完了再执行抽取天
            List<Long> executeEndTimeList = new ArrayList<>();
            if (!CollectionUtils.isEmpty(endTimeList)) {
                for (Long endTime : endTimeList) {
                    Long startTime = endTime - (60 * 60 * 24);  // 计算起始时间
                    Long countHour = flowAnalysisDao.findRecordDayHourCountByTime(startTime,endTime,hourType);
                    if(countHour<24l){
                        continue;
                    }
                    executeEndTimeList.add(endTime);
                }
            }
            executeEndTimeList = executeEndTimeList.stream().distinct().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
            // 异步处理每个时间段的数据
            if (!CollectionUtils.isEmpty(executeEndTimeList)) {
                //创建设备查询线程数
                ExecutorService executorService = Executors.newFixedThreadPool(deviceThreadPool);
                //创建插入数据库线程数
                ExecutorService insertDataExecutorService = Executors.newFixedThreadPool(insertDataThreadPool);
                List<CompletableFuture<Void>> futures = new ArrayList<>();
                try {
                    List<Integer> deviceIds = flowAnalysisDao.findDeviceId();
                    for (Long endTime : executeEndTimeList) {
                        Long startTime = endTime - (60 * 60 * 24);  // 计算起始时间
                        /*try (Connection connection = getClickHouseConnectionWithRetry(clickHouseDataSource, 5)) {*/
                            for (Integer deviceId : deviceIds) {
                                // 异步任务处理每个时间段的数据
                                CompletableFuture<Void> task = CompletableFuture.runAsync(() -> {
                                    String tableName = DynamicTableContext.genSflowDataTableName(deviceId);
                                    List<SflowDataApply> resSflowDataVos = flowAnalysisClickDao.findApplyDaySflowDataVoData(tableName, deviceId, startTime, endTime);
                                    if (!CollectionUtils.isEmpty(resSflowDataVos)) {
                                        flowAnalysisClickDao.deleteSflowDataApplyDayByStartAndEndTime(deviceId, startTime, endTime);
                                        for (SflowDataApply sflowDataApply : resSflowDataVos) {
                                            sflowDataApply.setReportTs(endTime.intValue() - 1);
                                            sflowDataApply.setDevId(deviceId);
                                        }
                                        // 批量插入数据
                                        if (resSflowDataVos.size() > 0) {
                                            int batchSize = extractSflowAnalysisSaveCount;  // 优化批次大小
                                            List<CompletableFuture<Void>> insertDataFutures = newInsertSflowDataApplyDayData(resSflowDataVos, batchSize, "sflow_data_apply_day", insertDataExecutorService, jdbcTemplate);
                                            // 等待所有插入数据任务完成
                                            CompletableFuture.allOf(insertDataFutures.toArray(new CompletableFuture[0])).join();
                                        }
                                    }
                                }, executorService);
                                futures.add(task);
                            }
                            // 等待所有任务完成
                            CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
                            // 插入运行时间记录
                            RunTimeRecordPo recordPo = new RunTimeRecordPo();
                            recordPo.setCreateTime(System.currentTimeMillis() / 1000);
                            recordPo.setTime(endTime);
                            recordPo.setType(type);
                            flowAnalysisDao.insertRecord(recordPo);
                        /*} catch (SQLException sql) {
                            log.error("抽取应用小时获取数据库连接失败", sql);
                        }*/
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    log.error("抽取应用天执行失败: {}", e.getMessage(), e);
                } finally {
                    // 关闭查询设备数据线程池
                    executorService.shutdown();
                    // 关闭插入数据线程池
                    insertDataExecutorService.shutdown();
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error("抽取应用天执行失败: {}", e.getMessage(), e);
        }
    }
    private Connection getClickHouseConnectionWithRetry(DataSource dataSource, int maxRetries) throws SQLException {
        int retryCount = 0;
        while (retryCount < maxRetries) {
            try {
                return dataSource.getConnection();
            } catch (SQLException e) {
                retryCount++;
                log.warn("获取 ClickHouse 连接失败，重试次数: {}", retryCount);
                if (retryCount >= maxRetries) throw e;
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new SQLException("重试过程中断", ie);
                }
            }
        }
        throw new SQLException("无法获取 ClickHouse 连接");
    }

    /**
     * 插入app数据
     * @param resSflowDataVos
     * @param batchSize
     * @param tableName
     * @param insertDateexecutorService
     * @param finalConnection
     * @return
     */
    /*private List<CompletableFuture<Void>> newInsertSflowDataApplyDayData(List<SflowDataApply> resSflowDataVos, int batchSize, String tableName,ExecutorService insertDateexecutorService, Connection connection) {
        // 将任务分成多个批次
        List<CompletableFuture<Void>> futures =  IntStream.range(0, (resSflowDataVos.size() + batchSize - 1) / batchSize)
                .mapToObj(i -> {
                    int start = i * batchSize;
                    int end = Math.min(resSflowDataVos.size(), start + batchSize);
                    List<SflowDataApply> batch = resSflowDataVos.subList(start, end);
                    // 提交任务到线程池
                    return CompletableFuture.runAsync(() -> {
                        int retryCount = 0;
                        boolean success = false;
                        while (retryCount < 5 && !success) { // 最多重试3次
                            try {
                                String sql = "INSERT INTO " + tableName + " (apply_id, package_in_size, package_out_size, dev_id, interface_id, report_ts) VALUES (?, ?, ?, ?, ?, ?)";
                                try (PreparedStatement pstmt =  connection.prepareStatement(sql)) {
                                    for (SflowDataApply item : batch) {
                                        pstmt.setString(1, String.valueOf(item.getApplyId()));
                                        pstmt.setLong(2, item.getPackageInSize());
                                        pstmt.setLong(3, item.getPackageOutSize());
                                        pstmt.setInt(4, item.getDevId());
                                        pstmt.setString(5, item.getInterfaceId());
                                        pstmt.setInt(6, item.getReportTs());
                                        pstmt.addBatch();
                                    }
                                    pstmt.executeBatch(); // 批量提交
                                    success = true; // 标记成功
                                }
                            } catch (Exception e) {
                                retryCount++;
                                if (retryCount < 5) {
                                    log.warn("流量分析抽取-app-插入数据错误，开始第 {} 次重试，错误信息：{}", retryCount, e.getMessage());
                                    try {
                                        Thread.sleep(1000 * retryCount); // 重试延迟（1秒、2秒、3秒）
                                    } catch (InterruptedException ex) {
                                        Thread.currentThread().interrupt();
                                    }
                                } else {
                                    e.printStackTrace();
                                    log.error("流量分析抽取-app-插入数据错误，重试 {} 次后失败，错误信息：{}", retryCount, e.getMessage());
                                }
                            }
                        }
                    }, insertDateexecutorService);
                }).collect(Collectors.toList());
        return futures;
    }*/

    private List<CompletableFuture<Void>> newInsertSflowDataApplyDayData(List<SflowDataApply> resSflowDataVos, int batchSize, String tableName,ExecutorService insertDateexecutorService, JdbcTemplate jdbcTemplate) {
        // 将任务分成多个批次
        List<CompletableFuture<Void>> futures =  IntStream.range(0, (resSflowDataVos.size() + batchSize - 1) / batchSize)
                .mapToObj(i -> {
                    int start = i * batchSize;
                    int end = Math.min(resSflowDataVos.size(), start + batchSize);
                    List<SflowDataApply> batch = resSflowDataVos.subList(start, end);
                    // 提交任务到线程池
                    return CompletableFuture.runAsync(() -> {
                            try {
                                String sql = "INSERT INTO "+tableName+" (apply_id, package_in_size, package_out_size, dev_id, interface_id, report_ts) VALUES (?, ?, ?, ?, ?, ?)";
                                jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
                                    @Override
                                    public void setValues(PreparedStatement ps, int i) throws SQLException {
                                        SflowDataApply item = batch.get(i);
                                        ps.setString(1, String.valueOf(item.getApplyId()));
                                        ps.setLong(2, item.getPackageInSize());
                                        ps.setLong(3, item.getPackageOutSize());
                                        ps.setInt(4, item.getDevId());
                                        ps.setString(5, item.getInterfaceId());
                                        ps.setInt(6, item.getReportTs());
                                    }
                                    @Override
                                    public int getBatchSize() {
                                        return batch.size();
                                    }
                                });
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                    }, insertDateexecutorService);
                }).collect(Collectors.toList());
        return futures;
    }



    /**
     * 获取62天内所有没有抽取天
     * @param type
     * @return
     * @throws ParseException
     */
    private List<Long> handelGetNotFinishDayRecord(Integer type) throws ParseException {
        // 获取时间范围
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        List<Long> endTimeList = new ArrayList<>();
        Calendar cal = Calendar.getInstance();
        cal.setTime(sdf.parse(sdf.format(new Date())));
        cal.add(Calendar.DAY_OF_YEAR, -dayCount);

        // 获取记录列表并计算时间段
        List<RunTimeRecordPo> poList = flowAnalysisDao.findGreaterThanRecordList(cal.getTimeInMillis() / 1000, type);
        List<Long> poTimeList = poList.stream().map(RunTimeRecordPo::getTime).collect(Collectors.toList());
        for (int i = 0; i < dayCount; i++) {
            cal.add(Calendar.DAY_OF_YEAR, 1);
            if (!poTimeList.contains(cal.getTimeInMillis() / 1000)) {
                endTimeList.add(cal.getTimeInMillis() / 1000);
            }
        }
        return endTimeList;
    }


    /**
     * 处理应用数据
     * @param finalResDataMap
     * @param sflowDataApply
     * @param destAppKey
     * @param appIdDest
     */
    private void handleSflowDataApplyData(Map<String, SflowDataApply> finalResDataMap, SflowDataApply sflowDataApply, String destAppKey, Long appId) {
        if (null != finalResDataMap.get(destAppKey)) {
            SflowDataApply beforeSflowDataApply = finalResDataMap.get(destAppKey);
            beforeSflowDataApply.setPackageInSize(beforeSflowDataApply.getPackageInSize() + sflowDataApply.getPackageInSize());
            beforeSflowDataApply.setPackageOutSize(beforeSflowDataApply.getPackageOutSize() + sflowDataApply.getPackageOutSize());
        } else {
            SflowDataApply newSflowDataApply = new SflowDataApply(appId, sflowDataApply.getDevId(), sflowDataApply.getInterfaceId(), sflowDataApply.getPackageInSize(),
                    sflowDataApply.getPackageOutSize(), sflowDataApply.getReportTs());
            finalResDataMap.put(destAppKey, newSflowDataApply);
        }
    }

    /**
     * 处理应用小时数据
     * @param type
     * @param dayType
     */
    @Override
    public void analysisDataAppCurrentDayHour(Integer type,Integer dayType) {
        try {
            // 获取当前时间范围的结束时间列表
            List<Long> endTimeList = new ArrayList<>();
            //获取62天内所有没有抽取的所有小时
            handelGetNotFinishDayHourRecord(type, dayType, endTimeList);

            endTimeList = endTimeList.stream().distinct().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
            // 异步处理每个时间段的数据
            if (!CollectionUtils.isEmpty(endTimeList)) {
                // 延迟五分钟
                Thread.sleep(1000*60*5);
                //创建设备查询线程数
                ExecutorService executorService = Executors.newFixedThreadPool(deviceThreadPool);
                //创建插入数据库线程数
                ExecutorService insertDataExecutorService = Executors.newFixedThreadPool(insertDataThreadPool);
                List<CompletableFuture<Void>> futures = new ArrayList<>();
                try {
                List<Integer> deviceIds = flowAnalysisDao.findDeviceId();
                for (Long endTime : endTimeList) {
                    Long startTime = endTime - (60 * 60);  // 计算每个时间段的起始时间
//                    try (Connection connection = getClickHouseConnectionWithRetry(clickHouseDataSource, 5)) {
                        // 异步查询设备数据
                        Map<Integer,Long> devMap = new HashMap<>();
                        deviceIds.parallelStream().forEach(deviceId -> { // 使用并行流
                            String tableName = DynamicTableContext.genSflowDataTableName(deviceId);
                            Long resSflowDataApplyCount = flowAnalysisClickDao.findApplySflowDataVoDataCount(tableName, deviceId, startTime, endTime);
                            if (null != resSflowDataApplyCount && resSflowDataApplyCount > 0l) {
                                devMap.put(deviceId,resSflowDataApplyCount);
                                //删除之前的脏数据
                                flowAnalysisClickDao.deleteSflowDataApplyHourByStartAndEndTime(deviceId, startTime, endTime);
                            }
                        });
                        if(!CollectionUtils.isEmpty(devMap)){
                            for (Map.Entry<Integer, Long> entry : devMap.entrySet()) {
                                // 将每个任务放入异步执行列表
                                CompletableFuture<Void> task = CompletableFuture.runAsync(() -> {
                                Integer deviceId = entry.getKey();
                                Long resSflowDataApplyCount = entry.getValue();
                                String tableName = DynamicTableContext.genSflowDataTableName(deviceId);
                                if (resSflowDataApplyCount > 0l) {
                                    Integer querySize = extractSflowAnalysisQueryAppCount;  // 优化批次大小
                                    Integer pageNo = 0;
                                    for (long queryStart = 0l; queryStart <= resSflowDataApplyCount; queryStart += querySize) {
                                        pageNo = pageNo + 1;
                                        List<SflowDataApply> resSflowDataVos = flowAnalysisClickDao.findApplySflowDataVoData(tableName, deviceId, startTime, endTime,pageNo, querySize);
                                        if (!CollectionUtils.isEmpty(resSflowDataVos)) {
                                            Map<String, SflowDataApply> finalResDataMap = new HashMap<>();
                                            for (SflowDataApply sflowDataApply : resSflowDataVos) {
                                                sflowDataApply.setReportTs(endTime.intValue() - 1);
                                                String sourceAppKey = sflowDataApply.getDevId() + "_" + sflowDataApply.getInterfaceId() + "_" + sflowDataApply.getAppIdSource();
                                                String destAppKey = sflowDataApply.getDevId() + "_" + sflowDataApply.getInterfaceId() + "_" + sflowDataApply.getAppIdDest();
                                                if (sflowDataApply.getAppIdSource().equals(sflowDataApply.getAppIdDest())) {
                                                    //处理源应用
                                                    handleSflowDataApplyData(finalResDataMap, sflowDataApply, sourceAppKey, sflowDataApply.getAppIdSource());
                                                } else {
                                                    if (0l != sflowDataApply.getAppIdSource() && 0l == sflowDataApply.getAppIdDest()) {
                                                        handleSflowDataApplyData(finalResDataMap, sflowDataApply, sourceAppKey, sflowDataApply.getAppIdSource());
                                                    } else if (0l == sflowDataApply.getAppIdSource() && 0l != sflowDataApply.getAppIdDest()) {
                                                        handleSflowDataApplyData(finalResDataMap, sflowDataApply, destAppKey, sflowDataApply.getAppIdDest());
                                                    } else {
                                                        handleSflowDataApplyData(finalResDataMap, sflowDataApply, sourceAppKey, sflowDataApply.getAppIdSource());
                                                        handleSflowDataApplyData(finalResDataMap, sflowDataApply, destAppKey, sflowDataApply.getAppIdDest());
                                                    }
                                                }
                                            }
                                            // 批量插入处理
                                            if (finalResDataMap.values().size() > 0) {
                                                int batchSize = extractSflowAnalysisSaveCount;
                                                List<SflowDataApply> handleList = new ArrayList<>(finalResDataMap.values());
                                                List<CompletableFuture<Void>> insertDataFutures = newInsertSflowDataApplyDayData(handleList,batchSize,"sflow_data_apply_hour", insertDataExecutorService, jdbcTemplate);
                                                // 等待所有插入数据任务完成
                                                CompletableFuture.allOf(insertDataFutures.toArray(new CompletableFuture[0])).join();
                                            }
                                        }
                                    }
                                }
                                }, executorService);
                                futures.add(task);
                            }
                            // 等待所有任务完成
                            CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
                        }
                        // 插入运行时间记录
                        RunTimeRecordPo recordPo = new RunTimeRecordPo();
                        recordPo.setCreateTime(System.currentTimeMillis() / 1000);
                        recordPo.setTime(endTime);
                        recordPo.setType(type);
                        flowAnalysisDao.insertRecord(recordPo);
                    /*} catch (SQLException sql) {
                        log.error("抽取应用天获取数据库连接失败", sql);
                    }*/
                }
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    // 关闭查询设备数据线程池
                    executorService.shutdown();
                    // 关闭插入数据线程池
                    insertDataExecutorService.shutdown();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    /**
     * 处理ip对天数据
     * @param type
     * @param hourType
     */
    @Override
    public void analysisDataIpOldDay(Integer type,Integer hourType) {
        try {
            //获取62天内所有没有抽取天
            List<Long> endTimeList = handelGetNotFinishDayRecord(type);
            //检查是否抽取了24小时的小时记录，如果抽取了完了再执行抽取天
            List<Long> executeEndTimeList = new ArrayList<>();
            if (!CollectionUtils.isEmpty(endTimeList)) {
                for (Long endTime : endTimeList) {
                    Long startTime = endTime - (60 * 60 * 24);  // 计算起始时间
                    Long countHour = flowAnalysisDao.findRecordDayHourCountByTime(startTime,endTime,hourType);
                    if(countHour<24l){
                        continue;
                    }
                    executeEndTimeList.add(endTime);
                }
            }
            executeEndTimeList = executeEndTimeList.stream().distinct().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
            // 异步处理每个时间段的数据
            if (!CollectionUtils.isEmpty(executeEndTimeList)) {
                //创建查询设备线程数
                ExecutorService executorService = Executors.newFixedThreadPool(deviceThreadPool);
                //创建插入数据线程数
                ExecutorService insertDataExecutorService = Executors.newFixedThreadPool(insertDataThreadPool);
                List<CompletableFuture<Void>> futures = new ArrayList<>();
                try{
                List<Integer> deviceIds = flowAnalysisDao.findDeviceId();
                for (Long endTime : executeEndTimeList) {
                    Long startTime = endTime - (60 * 60 * 24);  // 计算起始时间
//                    try (Connection connection = getClickHouseConnectionWithRetry(clickHouseDataSource, 5)) {
                        // 异步查询设备数据
                        Map<Integer,Long> devMap = new HashMap<>();
                        deviceIds.parallelStream().forEach(deviceId -> { // 使用并行流
                            String tableName = DynamicTableContext.genSflowDataTableName(deviceId);
                            Long resSflowDataVosCount = flowAnalysisClickDao.findIpDaySflowDataVoDataCount(tableName, deviceId, startTime, endTime);
                            if (null != resSflowDataVosCount && resSflowDataVosCount > 0l) {
                                devMap.put(deviceId,resSflowDataVosCount);
                                //删除之前的脏数据
                                flowAnalysisClickDao.deleteSflowDataIpDayByStartAndEndTime(deviceId, startTime, endTime);
                            }
                        });
                        if(!CollectionUtils.isEmpty(devMap)){
                            for (Map.Entry<Integer, Long> entry : devMap.entrySet()) {
                                // 将每个任务放入异步执行列表
                                CompletableFuture<Void> task = CompletableFuture.runAsync(() -> {
                                Integer deviceId = entry.getKey();
                                Long resSflowDataVosCount = entry.getValue();
                                String tableName = DynamicTableContext.genSflowDataTableName(deviceId);
                                if (resSflowDataVosCount > 0l) {
                                    Integer querySize = extractSflowAnalysisQueryCount;  // 优化批次大小
                                    Integer pageNo = 0;
                                    for (long queryStart = 0l; queryStart <= resSflowDataVosCount; queryStart += querySize) {
                                        pageNo = pageNo + 1;
                                        List<SflowDataIpVo> resSflowDataVos = flowAnalysisClickDao.findIpDaySflowDataVoData(tableName, deviceId, startTime, endTime, pageNo, querySize);
                                        if (!CollectionUtils.isEmpty(resSflowDataVos)) {
                                            for (SflowDataIpVo sflowDataApply : resSflowDataVos) {
                                                sflowDataApply.setDevId(deviceId);
                                                sflowDataApply.setReportTs(endTime.intValue() - 1);
                                                List<String> newApplyIds = new ArrayList<>();
                                                if (StringUtils.isNotBlank(sflowDataApply.getApplyIds())) {
                                                    List<String> applyIds = Arrays.asList(sflowDataApply.getApplyIds().split(",")).stream().distinct().collect(Collectors.toList());
                                                    newApplyIds.addAll(applyIds);
                                                }
                                                sflowDataApply.setApplyIds(newApplyIds.stream().collect(Collectors.joining(",")));
                                            }
                                            // 批量插入数据
                                            if (resSflowDataVos.size() > 0) {
                                                int batchSize = extractSflowAnalysisSaveCount;  // 优化批次大小
                                                List<CompletableFuture<Void>> insertDataFutures = newInsertSflowDataIpData(resSflowDataVos,batchSize,"sflow_data_ip_day", insertDataExecutorService, jdbcTemplate);
                                                // 等待所有插入数据任务完成
                                                CompletableFuture.allOf(insertDataFutures.toArray(new CompletableFuture[0])).join();

                                            }
                                        }
                                    }
                                }
                                }, executorService);
                                futures.add(task);
                            }
                            // 等待所有任务完成
                            CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
                        }
                        // 插入运行时间记录
                        RunTimeRecordPo recordPo = new RunTimeRecordPo();
                        recordPo.setCreateTime(System.currentTimeMillis() / 1000);
                        recordPo.setTime(endTime);
                        recordPo.setType(type);
                        flowAnalysisDao.insertRecord(recordPo);
//                    } catch (SQLException sql) {
//                        log.error("抽取ip天获取数据库连接失败", sql);
//                    }
                }
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    // 关闭查询设备数据线程池
                    executorService.shutdown();
                    // 关闭插入数据线程池
                    insertDataExecutorService.shutdown();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * ip对插入数据
     * @param resSflowDataVos
     * @param batchSize
     * @param tableName
     * @param insertDataExecutorService
     * @param finalConnection
     * @return
     */
    /*private List<CompletableFuture<Void>> newInsertSflowDataIpData(List<SflowDataIpVo> resSflowDataVos, int batchSize, String tableName,ExecutorService insertDataExecutorService, Connection connection) {
        // 将任务分成多个批次
        List<CompletableFuture<Void>>  futures =  IntStream.range(0, (resSflowDataVos.size() + batchSize - 1) / batchSize)
                .mapToObj(i -> {
                    int start = i * batchSize;
                    int end = Math.min(resSflowDataVos.size(), start + batchSize);
                    List<SflowDataIpVo> batch = resSflowDataVos.subList(start, end);
                    // 提交任务到线程池
                    return CompletableFuture.runAsync(() -> {
                        int retryCount = 0;
                        boolean success = false;
                        while (retryCount < 5 && !success) { // 最多重试3次
                            try {
                                String sql = "INSERT INTO " + tableName + " (src_ip, dest_ip, package_in_size, package_out_size, dev_id, interface_id, report_ts, apply_ids) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                                try (PreparedStatement pstmt =  connection.prepareStatement(sql)) {
                                    for (SflowDataIpVo item : batch) {
                                        pstmt.setString(1, item.getSrcIp());
                                        pstmt.setString(2, item.getDestIp());
                                        pstmt.setLong(3, item.getPackageInSize());
                                        pstmt.setLong(4, item.getPackageOutSize());
                                        pstmt.setInt(5, item.getDevId());
                                        pstmt.setString(6, item.getInterfaceId());
                                        pstmt.setInt(7, item.getReportTs());
                                        pstmt.setString(8, item.getApplyIds());
                                        pstmt.addBatch();
                                    }
                                    pstmt.executeBatch(); // 批量提交
                                    success = true; // 标记成功
                                }
                            } catch (Exception e) {
                                retryCount++;
                                if (retryCount < 5) {
                                    log.warn("流量分析抽取-Ip-插入数据错误，开始第 {} 次重试，错误信息：{}", retryCount, e.getMessage());
                                    try {
                                        Thread.sleep(1000 * retryCount); // 重试延迟（1秒、2秒、3秒）
                                    } catch (InterruptedException ex) {
                                        Thread.currentThread().interrupt();
                                    }
                                } else {
                                    e.printStackTrace();
                                    log.error("流量分析抽取-Ip-插入数据错误，重试 {} 次后失败，错误信息：{}", retryCount, e.getMessage());
                                }
                            }
                        }
                    }, insertDataExecutorService);
                }).collect(Collectors.toList());
        return futures;
    }*/
    private List<CompletableFuture<Void>> newInsertSflowDataIpData(List<SflowDataIpVo> resSflowDataVos, int batchSize, String tableName,ExecutorService insertDataExecutorService, JdbcTemplate jdbcTemplate) {
        // 将任务分成多个批次
        List<CompletableFuture<Void>>  futures =  IntStream.range(0, (resSflowDataVos.size() + batchSize - 1) / batchSize)
                .mapToObj(i -> {
                    int start = i * batchSize;
                    int end = Math.min(resSflowDataVos.size(), start + batchSize);
                    List<SflowDataIpVo> batch = resSflowDataVos.subList(start, end);
                    // 提交任务到线程池
                    return CompletableFuture.runAsync(() -> {
                            try {
                                String sql = "INSERT INTO "+tableName+" (src_ip, dest_ip, package_in_size, package_out_size, dev_id, interface_id, report_ts, apply_ids) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                                jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
                                    @Override
                                    public void setValues(PreparedStatement ps, int i) throws SQLException {
                                        SflowDataIpVo item = batch.get(i);
                                        ps.setString(1, item.getSrcIp());
                                        ps.setString(2, item.getDestIp());
                                        ps.setLong(3, item.getPackageInSize());
                                        ps.setLong(4, item.getPackageOutSize());
                                        ps.setInt(5, item.getDevId());
                                        ps.setString(6, item.getInterfaceId());
                                        ps.setInt(7, item.getReportTs());
                                        ps.setString(8, item.getApplyIds());
                                    }
                                    @Override
                                    public int getBatchSize() {
                                        return batch.size();
                                    }
                                });
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                    }, insertDataExecutorService);
                }).collect(Collectors.toList());
        return futures;
    }

    /**
     * 处理IP对小时数据
     * @param type
     * @param dayType
     */
    @Override
    public void analysisDataIpCurrentDayHour(Integer type,Integer dayType) {
        try {
            // 获取当前时间范围的结束时间列表
            List<Long> endTimeList = new ArrayList<>();
            //获取62天内所有没有抽取的所有小时
            handelGetNotFinishDayHourRecord(type, dayType, endTimeList);
            endTimeList = endTimeList.stream().distinct().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
            // 异步处理每个时间段的数据
            if (!CollectionUtils.isEmpty(endTimeList)) {
                // 延迟五分钟
                Thread.sleep(1000*60*5);
                //创建查询设备线程数
                ExecutorService executorService = Executors.newFixedThreadPool(deviceThreadPool);
                //创建插入数据线程数
                ExecutorService insertDataExecutorService = Executors.newFixedThreadPool(insertDataThreadPool);
                List<CompletableFuture<Void>> futures = new ArrayList<>();
                try{
                List<Integer> deviceIds = flowAnalysisDao.findDeviceId();
                for (Long endTime : endTimeList) {
                    Long startTime = endTime - (60 * 60);  // 计算每个时间段的起始时间
//                    try (Connection connection = getClickHouseConnectionWithRetry(clickHouseDataSource, 5)) {
                        // 异步查询设备数据
                        Map<Integer,Long> devMap = new HashMap<>();
                        deviceIds.parallelStream().forEach(deviceId -> { // 使用并行流
                            String tableName = DynamicTableContext.genSflowDataTableName(deviceId);
                            Long resSflowDataVosCount = flowAnalysisClickDao.findIpSflowDataVoDataCount(tableName, deviceId, startTime, endTime);
                            if (null != resSflowDataVosCount && resSflowDataVosCount > 0l) {
                                devMap.put(deviceId,resSflowDataVosCount);
                                //删除之前的脏数据
                                flowAnalysisClickDao.deleteSflowDataIpHourByStartAndEndTime(deviceId, startTime, endTime);
                            }
                        });
                        if(!CollectionUtils.isEmpty(devMap)){
                            for (Map.Entry<Integer, Long> entry : devMap.entrySet()) {
                                // 将每个任务放入异步执行列表
                                CompletableFuture<Void> task = CompletableFuture.runAsync(() -> {
                                Integer deviceId = entry.getKey();
                                Long resSflowDataVosCount = entry.getValue();
                                String tableName = DynamicTableContext.genSflowDataTableName(deviceId);
                                if (resSflowDataVosCount > 0l) {
                                    Integer querySize = extractSflowAnalysisQueryCount;  // 优化批次大小
                                    Integer pageNo = 0;
                                    for (long queryStart = 0l; queryStart <= resSflowDataVosCount; queryStart += querySize) {
                                        pageNo = pageNo + 1;
                                        /*long a = System.currentTimeMillis();*/
                                        List<SflowDataIpVo> resSflowDataVos = flowAnalysisClickDao.findIpSflowDataVoData(tableName, deviceId, startTime, endTime, pageNo, querySize);
                                        /*long b = System.currentTimeMillis();
                                        log.info("查询IP对"+tableName+"表deviceId="+deviceId+"数据量"+extractSflowAnalysisSaveCount+"小时流量分析数据耗时=" + (b - a) );*/
                                        if (!CollectionUtils.isEmpty(resSflowDataVos)) {
                                            for (SflowDataIpVo sflowDataApply : resSflowDataVos) {
                                                sflowDataApply.setDevId(deviceId);
                                                sflowDataApply.setReportTs(endTime.intValue() - 1);
                                                List<String> applyIds = new ArrayList<>();
                                                if (StringUtils.isNotBlank(sflowDataApply.getAppIdSources())) {
                                                    List<String> sourceAppIds = Arrays.asList(sflowDataApply.getAppIdSources().split(",")).stream().distinct().collect(Collectors.toList());
                                                    applyIds.addAll(sourceAppIds);
                                                }
                                                if (StringUtils.isNotBlank(sflowDataApply.getAppIdDests())) {
                                                    List<String> destAppIds = Arrays.asList(sflowDataApply.getAppIdDests().split(",")).stream().distinct().collect(Collectors.toList());
                                                    applyIds.addAll(destAppIds);
                                                }
                                                sflowDataApply.setApplyIds(applyIds.stream().collect(Collectors.joining(",")));
                                            }
                                            // 批量插入处理
                                            if (resSflowDataVos.size() > 0) {
                                                int batchSize = extractSflowAnalysisSaveCount;
                                                List<CompletableFuture<Void>> insertDataFutures = newInsertSflowDataIpData(resSflowDataVos,batchSize,"sflow_data_ip_hour", insertDataExecutorService, jdbcTemplate);
                                                // 等待所有插入数据任务完成
                                                CompletableFuture.allOf(insertDataFutures.toArray(new CompletableFuture[0])).join();
                                            }
                                        }
                                    }
                                }
                            }, executorService);
                            futures.add(task);
                            }
                            // 等待所有任务完成
                            CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
                        }
                        // 插入运行时间记录
                        RunTimeRecordPo recordPo = new RunTimeRecordPo();
                        recordPo.setCreateTime(System.currentTimeMillis() / 1000);
                        recordPo.setTime(endTime);
                        recordPo.setType(type);
                        flowAnalysisDao.insertRecord(recordPo);
                    /*} catch (SQLException sql) {
                        log.error("抽取ip小时获取数据库连接失败", sql);
                    }*/
                }
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    // 关闭查询设备数据线程池
                    executorService.shutdown();
                    // 关闭插入数据线程池
                    insertDataExecutorService.shutdown();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取62天内所有没有抽取的所有小时
     * @param type
     * @param dayType
     * @param endTimeList
     * @throws ParseException
     */
    private void handelGetNotFinishDayHourRecord(Integer type, Integer dayType, List<Long> endTimeList) throws ParseException {
        //获取62天内所有没有抽取天
        List<Long> dayEndTimeList = handelGetNotFinishDayRecord(dayType);
        List<Long> dayHourEndTimeList = new ArrayList<>();
        //获取62天内所有没有抽取天的小时数据
        for (Long dayEndTime : dayEndTimeList) {
            for (int i = 0; i < 24; i++) {
                Long startTime = dayEndTime - (60 * 60) * i;  // 计算每个时间段的起始时间
                dayHourEndTimeList.add(startTime);
            }
        }
        // 获取当前时间范围
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:00:00");
        Calendar cal = Calendar.getInstance();
        cal.setTime(sdf.parse(sdf.format(new Date())));

        // 获取数据库记录并构建时间段
        List<RunTimeRecordPo> poList = flowAnalysisDao.findLessThanCurrRecordList(cal.getTimeInMillis() / 1000, type);
        List<Long> poTimeList = poList.stream().map(RunTimeRecordPo::getTime).collect(Collectors.toList());
        //获取当前天内所有没有抽取天的所有小时
        int hourCount = cal.get(Calendar.HOUR_OF_DAY);
        cal.add(Calendar.HOUR_OF_DAY, 1);
        for (int i = 0; i < hourCount + 1; i++) {
            cal.add(Calendar.HOUR_OF_DAY, -1);
            dayHourEndTimeList.add(cal.getTimeInMillis() / 1000);
        }
        //过滤62天内所有没有抽取的所有小时
        dayHourEndTimeList = dayHourEndTimeList.stream().distinct().collect(Collectors.toList());
        for (Long dayHourEndTime : dayHourEndTimeList) {
            if (!poTimeList.contains(dayHourEndTime)) {
                endTimeList.add(dayHourEndTime);
            }
        }
    }

}
