package com.wdkj.plugs.extract.schedule;

import com.wdkj.plugs.extract.service.*;
import com.wdkj.plugs.extract.util.DateUtil;
import com.wdkj.plugs.model.po.ExtractPathData;
import com.wdkj.plugs.model.vo.BackupDefaultValue;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.ExecutionException;

/**
 * 性能调整测试优化类
 *
 * @author yuy
 */
@Component
public class Test implements CommandLineRunner {


	private static final String AUTO_BACK_FLAG = "AUTO_BACK_FLAG";
	private static final String BACK_CYCLE = "BACK_CYCLE";
	private static final String BACK_TIME = "BACK_TIME";

	private static final String BACK_FIRST_DATE = "BACK_FIRST_DATE";
	private static final String ENABLE = "ENABLE";

	@Autowired
	private IExtractPathService extractPathService;

	public static List<ExtractPathData> dataList = new ArrayList<>();

	@Autowired
	private IIndexSyncService indexSyncService;

	@Autowired
	private IExtractSnmpService extractSnmpService;

	@Autowired
	private IExtractSpecialService extractSpecialService;

	@Autowired
	private IFlowExtractService flowExtractService;

	@Autowired
	private ISpecialDataService specialDataService ;

	@Autowired
	private IDatabaseBackupService databaseBackupService;

	@Autowired
	private ISpecialMatchFlowService specialMatchFlowService;

	@Autowired
	private IRunTimeService linkRunTimeService;

	@Autowired
	private UpdateSysGetherSchedule updateSysGetherSchedule ;

	@Autowired
	private ICheckReportTimeService iCheckReportTimeService;

	@Override
	public void run(String... args) throws Exception {
//		testExtractSpecial();
//		testExtractPath();
//		testExtractSnmp();
//		testExtractFlowDay();
//		testExtractFlowHour();
//		testUpdateJob();
//		testMatchFlowJob();
//		testAutoBackUp();
//		linkRunTimeService.analysisData(0);
//		linkRunTimeService.analysisData(1);
//		iCheckReportTimeService.checkReportTime();
	}

	private void testAutoBackUp() {
		LocalDateTime now = LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES);
		DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		boolean isFirstExtract = false;
		// 获取数据库自动备份最后一次执行的时间
		LocalDateTime lastTimeDate = null ;
		String lastTime = indexSyncService.getLastDateByName("database_backup");
		if (StringUtils.isBlank(lastTime)) {
			isFirstExtract = true;
		} else {
			lastTimeDate = LocalDateTime.parse(lastTime, df);
		}
		//获取自动备份默认值
		List<BackupDefaultValue> list = databaseBackupService.getBackupDefaultValue();
		Map<String, String> map = new HashMap<>(16);
		for (BackupDefaultValue defaultValue : list) {
			map.put(defaultValue.getKey(), defaultValue.getValue());
		}
		//判断是否启动自动备份
		String autoBackFlag = map.get(AUTO_BACK_FLAG);
		if (ENABLE.equals(autoBackFlag)){
			//判断当前时间是否满足
			String backDataTime = map.get(BACK_FIRST_DATE) + " " + map.get(BACK_TIME);
			LocalDateTime firstBackTime = LocalDateTime.parse(backDataTime, df);
			//前后5分钟，并且未执行过备份，则执行
			boolean flag3 = isFirstExtract || !(lastTimeDate.isBefore(firstBackTime.plusMinutes(5)) && lastTimeDate.isAfter(firstBackTime.minusMinutes(5)));
			if ((now.isBefore(firstBackTime.plusMinutes(5)) && now.isAfter(firstBackTime.minusMinutes(5)) && flag3)
			){
					//判断是否远程备份
					databaseBackupService.dataSourceBackup(now,isFirstExtract,map);
			}else if (now.isAfter(firstBackTime)){
				//表示已经过了备份日期,加上备份周期
				LocalDateTime startBackTime;
				while (true){
					startBackTime = firstBackTime.plusDays(Long.parseLong(map.get(BACK_CYCLE)));
					boolean flag4 = isFirstExtract || !(lastTimeDate.isBefore(startBackTime.plusMinutes(5)) && lastTimeDate.isAfter(startBackTime.minusMinutes(5)));
					if (startBackTime.isAfter(now)){
						break;
					}else if ((now.isBefore(startBackTime.plusMinutes(5)) && now.isAfter(startBackTime.minusMinutes(5)) && flag4)){
						databaseBackupService.dataSourceBackup(now,isFirstExtract,map);
						break;
					}
					firstBackTime = startBackTime;
				}
			}
		}
	}


	public void testUpdateJob(){
		specialDataService.updatesJob();
	}

	public void testMatchFlowJob(){
		specialMatchFlowService.updatesJob();
	}

	public void testExtractFlowHour() {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Calendar nowCalendar = Calendar.getInstance();
			System.out.println("开始抽取流量小时数据。。。。。" + sdf.format(nowCalendar.getTime()));
			//计算抽取开始结束时间，抽取1分钟以前当前数据
			long startTimezone = System.currentTimeMillis();
			nowCalendar.add(Calendar.MINUTE, -1);
			String endTime = sdf.format(nowCalendar.getTime());
			//刚好跨小时处理
			if (nowCalendar.get(Calendar.MINUTE) == 0) {
				nowCalendar.add(Calendar.HOUR, -1);//抽取上个小时数据
			}
			//开始时间小时整点
			nowCalendar.set(Calendar.MINUTE, 0);
			nowCalendar.set(Calendar.SECOND, 0);
			String startTime = sdf.format(nowCalendar.getTime());

			//执行抽取
			flowExtractService.extractFlowHourData(startTime, endTime);

			nowCalendar = Calendar.getInstance();
			System.out.println("抽取流量小时数据完成！ " + sdf.format(nowCalendar.getTime()));
			System.out.println("抽取流量小时数据完成，time" + (startTimezone - System.currentTimeMillis()) / 1000);
		} catch (Exception ee) {
			ee.printStackTrace();
		}
	}


	public void testExtractFlowDay() {
		try {
			long startTimezone = System.currentTimeMillis();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Calendar nowCalendar = Calendar.getInstance();
			System.out.println("开始抽取流量天数据。。。。。" + sdf.format(nowCalendar.getTime()));
			//计算抽取开始结束时间，抽取1分钟以前当前数据
			nowCalendar.add(Calendar.MINUTE, -5);
			String endTime = sdf.format(nowCalendar.getTime());
			//刚好跨天处理
			if (nowCalendar.get(Calendar.HOUR) == 0 && nowCalendar.get(Calendar.MINUTE) == 0) {
				nowCalendar.add(Calendar.DAY_OF_MONTH, -1);//抽取昨天数据
			}
			//开始时间天凌晨
			nowCalendar.set(Calendar.HOUR_OF_DAY, 0);
			nowCalendar.set(Calendar.MINUTE, 0);
			nowCalendar.set(Calendar.SECOND, 0);
			String startTime = sdf.format(nowCalendar.getTime());

			//执行抽取
			flowExtractService.extractFlowDayData(startTime, endTime);

			nowCalendar = Calendar.getInstance();
			System.out.println("抽取流量天数据完成！ " + sdf.format(nowCalendar.getTime()));
			System.out.println("抽取流量天数据完成！，time" + (startTimezone - System.currentTimeMillis()) / 1000);
		} catch (Exception ee) {
			ee.printStackTrace();
		}
	}

	public void testExtractSpecial() {
		try {
			String lastTime = indexSyncService.getLastDateByName("extract_special_data");
			long startTimezone = System.currentTimeMillis();
			LocalDateTime now = DateUtil.getNear5(LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES));
			LocalDateTime startTime;
			//每五分钟抽一次
			//第一次抽取,取前五分钟
			startTime = now.minusMinutes(5);
			LocalDateTime end = startTime.plusMinutes(5);//查询结束时间
			extractSpecialService.saveSpecialData(false, startTime, end);
			System.out.println("testExtractSpecial耗费时间：" + (System.currentTimeMillis() - startTimezone));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	//	public void testExtractPath() throws ClassNotFoundException, ExecutionException, InterruptedException, IOException {
//		System.out.println("---------start path-路径数据抽取任务开始 Job----------");
//		try {
//			long startTimezone = System.currentTimeMillis();
//			DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
//			boolean isFirstExtract = false;
//			// 获取基础数据最后一次抽取的时间
//			String lastTime = indexSyncService.getLastDateByName("extract_path_data");
//			LocalDateTime now = DateUtil.getNear5(LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES));
//			LocalDateTime startTime,endTime;
//			//每五分钟抽一次
//			if (StringUtils.isBlank(lastTime)){
//				//第一次抽取,取前五分钟
//				startTime = now.minusMinutes(5);
//				isFirstExtract = true;
//				endTime = now;
//			}else {
//				startTime = LocalDateTime.parse(lastTime,df);
//				endTime = now.minusMinutes(2);
//			}
//			while (startTime.isBefore(endTime)){
//				//每次抽取暂停100毫秒；防止补数据时，占用CPU过高
//				Thread.sleep(100);
//				//查询结束时间
//				LocalDateTime end = startTime.plusMinutes(5);
//				if(end.isAfter(endTime)){
//					break;
//				}
//				extractPathService.savePathData(isFirstExtract,startTime,end);
//				isFirstExtract = false;
//				startTime = end;
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}finally {
//		}
//	}
	public void testExtractPath() throws ClassNotFoundException, ExecutionException, InterruptedException, IOException {
		System.out.println("---------start path-路径数据抽取任务开始 Job----------");
		try {
			String lastTime = indexSyncService.getLastDateByName("extract_special_data");
			long startTimezone = System.currentTimeMillis();
			LocalDateTime now = DateUtil.getNear5(LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES));
			LocalDateTime startTime;
			//每五分钟抽一次
			//第一次抽取,取前五分钟
			startTime = now.minusMinutes(5);
			LocalDateTime end = startTime.plusMinutes(5);//查询结束时间
			extractPathService.savePathData(true, startTime, end);
			System.out.println("testExtractPath耗费时间：" + (System.currentTimeMillis() - startTimezone));
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
	}

	public void testExtractSnmp() {
		try {
			long startTimezone = System.currentTimeMillis();
			boolean isFirstExtract = false;
			// 获取基础数据最后一次抽取的时间
			LocalDateTime now = DateUtil.getNear5(LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES));
			LocalDateTime startTime;
			startTime = now.minusMinutes(5);
			LocalDateTime end = startTime.plusMinutes(5);//查询结束时间
			extractSnmpService.saveSnmpData(isFirstExtract, startTime,end);
			System.out.println("testExtractSnmp耗费时间：" + (System.currentTimeMillis() - startTimezone));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		Integer a = 84710 ;
		int b = a/60 ;//分钟
		int d = b/60 ;//多少时
		int e = b % 60 ;//多少分
		int c = a%60 ;//多少秒
		System.out.println(d+ ":" + e + ":"+c);
	}
}
