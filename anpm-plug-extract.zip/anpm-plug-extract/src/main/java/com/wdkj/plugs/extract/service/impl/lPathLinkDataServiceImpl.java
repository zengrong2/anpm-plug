package com.wdkj.plugs.extract.service.impl;


import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.wdkj.plugs.core.support.DynamicTableContext;
import com.wdkj.plugs.extract.dao.click.IPathLinkDataClickDao;
import com.wdkj.plugs.extract.dao.mysql.IPathLinkDataDao;
import com.wdkj.plugs.extract.service.LanguageService;
import com.wdkj.plugs.extract.service.PathLinkDataService;
import com.wdkj.plugs.model.po.EngineRoute;
import com.wdkj.plugs.model.vo.PathLinkDataVo;
import com.wdkj.plugs.utils.List.ListUtils;
import com.wdkj.plugs.utils.date.DateUtil;
import com.wdkj.plugs.utils.string.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.sql.DataSource;
import java.util.*;


/**
 * @author lp
 */
@Service
public class lPathLinkDataServiceImpl implements PathLinkDataService {

    private static Logger logger = LoggerFactory.getLogger(lPathLinkDataServiceImpl.class);

    @Autowired
    private IPathLinkDataDao pathLinkDataDao;
    @Autowired
    private IPathLinkDataClickDao pathLinkDataClickDao;

    private JdbcTemplate jdbcTemplate;

    @Autowired
    public void setJdbcTemplate(@Qualifier("gaussDataSource") DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Autowired
    private LanguageService languageService;
    private long makeSqlTotalUseMs = 0;
    private long makeSqlTotalCount = 0;

    @Override
    public void handleLinkData(Integer delayLossQueryMinute) {
    	long startMs = System.currentTimeMillis();
    	makeSqlTotalUseMs = 0;makeSqlTotalCount = 0;     
        languageService.setLanguage();
        //List<PathLinkDataVo> pathLinkDatalist = pathLinkDataDao.getPathLinkDataList();
        //获取每个路径的节点对
        logger.info(Thread.currentThread().getId()+" > 路径拓扑节点对的时延 getTableNameList go");
        Map<String, Set<Integer>> tableNameList = getTableNameList();
        logger.info("> 路径拓扑节点对的时延 getTableNameList done");
        if (CollectionUtils.isEmpty(tableNameList)) {
            logger.info("handleLinkData getTableNameList is null");
            return;
        }
//        Map<String, PathLinkDataVo> linkDataMap = getLinkDataMap(pathLinkDatalist);
        // 不可信节点
        logger.info("> 路径拓扑节点对的时延 getPathLinkList go");
        PathLinkDataObj pathLinkObj = getPathLinkList();
        logger.info(">路径拓扑节点对的时延  getPathLinkList done tableNameList.size="+tableNameList.size());
        //查询流速表的所有流量根据接口id分组
        Long startTimeLong = null;
        Long endTimeLong = null;
        if (null != delayLossQueryMinute) {
            Date now = new Date();
            String endTime = DateUtil.getTimeStr(now);
            String startTime = DateUtil.currDataAddReduceHMSNum(now, 2, -delayLossQueryMinute);
            startTimeLong = DateUtil.dateToStampTwo(startTime);
            endTimeLong = DateUtil.dateToStampTwo(endTime);
        }

        HashMap<Integer, HashMap<String, HashMap<String, PathLinkDataVo>>> linkDataSaveMap = new HashMap<>();
        pathLinkObj.datas.forEach(d->{
        	if(!linkDataSaveMap.containsKey(d.getRouteId()))
        		linkDataSaveMap.put(d.getRouteId(), new HashMap<>());

        	if(!linkDataSaveMap.get(d.getRouteId()).containsKey(d.getPreIp()))
        		linkDataSaveMap.get(d.getRouteId()).put(d.getPreIp(), new HashMap<>());

            linkDataSaveMap.get(d.getRouteId()).get(d.getPreIp()).put(d.getCurIp(), d);
        });

        long totalSearchTs = 0;
        long ct = 0;
        for (Map.Entry<String, Set<Integer>> entry : tableNameList.entrySet()) {
            String tableName = entry.getKey();
            Set<Integer> routeIds = entry.getValue();
            List<PathLinkDataVo> linkDataList = new LinkedList<>();
            if (!CollectionUtils.isEmpty(routeIds)) {
            	//logger.error("> 路径拓扑节点对的时延 getLinkDataList go");
                linkDataList = pathLinkDataClickDao.getLinkDataList(tableName, Lists.newLinkedList(routeIds), startTimeLong, endTimeLong);
                //logger.error("> 路径拓扑节点对的时延 getLinkDataList done");  约 300ms
            }

            //logger.error(">> 路径拓扑节点对的时延 linkDataList go "+linkDataList.size());
            
            for (PathLinkDataVo linkData : linkDataList) {
                // 不可信节点前的线路时延丢包需要置空
                if (pathLinkObj.getUntrustNodeIps().contains(linkData.getCurIp())) {
                    linkData.setDelay(null);
                    linkData.setLoseRate(null);
                }
                
                long ms1 = System.currentTimeMillis();
                PathLinkDataVo pathLinkDataVo = null;
                if(
                    linkDataSaveMap.containsKey(linkData.getRouteId())
                    && linkDataSaveMap.get(linkData.getRouteId()).containsKey(linkData.getPreIp())
                    && linkDataSaveMap.get(linkData.getRouteId()).get(linkData.getPreIp()).containsKey(linkData.getCurIp())
                ) {
                    pathLinkDataVo = linkDataSaveMap.get(linkData.getRouteId()).get(linkData.getPreIp()).get(linkData.getCurIp());
                }

                totalSearchTs += System.currentTimeMillis()-ms1;
                ct++;
                
                if (pathLinkDataVo != null) {
                    if (linkData.getDelay() != null) {
                        pathLinkDataVo.setDelayStr(linkData.getDelay() < 0 ? "" : String.format("%.2f", linkData.getDelay()));
                    } else {
                        pathLinkDataVo.setDelayStr("");
                    }
                    if (linkData.getLoseRate() != null) {
                        String loseRate = linkData.getLoseRate() < 0 ? "" : String.format("%.2f", linkData.getLoseRate() / 100);
                        pathLinkDataVo.setLoseRateStr(loseRate);
                    } else {
                        pathLinkDataVo.setLoseRateStr("");
                    }
                    pathLinkDataVo.setDataV4Name(tableName);
                    pathLinkDataVo.flag = true;
                }
            }
            //logger.error(">> 路径拓扑节点对的时延 linkDataList done "+linkDataList.size()); 约 2ms
        }
        
        logger.info(">> 路径拓扑节点对的时延 all linkDataList done  searh avg="+(ct>0?totalSearchTs/ct:0));
        
        logger.info("> 路径拓扑节点对的时延 execute sql  go");
        //先删除path_link_data所有的数据，再重新写入统计数据
        pathLinkDataDao.delete();
        //批量写入数据库        
        String sqlHead = "INSERT INTO path_link_data (task_id,route_id,pre_ip,cur_ip,delay,lose_rate,data_v4_name,create_time)VALUES";
        StringBuffer sql = new StringBuffer(sqlHead);
        int[] count = new int[]{0};

        final String date = DateUtil.formatTime(new Date(), null);
        long[] startMs1 = new long[] { System.currentTimeMillis()};
        linkDataSaveMap.forEach((routeId, map)->{		
        	map.forEach((preIp, map1)->{
                map1.forEach((curIp, data)-> {
                        if (data.flag) {
                            count[0]++;
                            sql.append("( ").append(data.getTaskId()).append(",").append(data.getRouteId()).append(",'").append(data.getPreIp()).append("','").append(data.getCurIp()).append("','").append(data.getDelayStr())
                                    .append("','").append(data.getLoseRateStr()).append("','").append(data.getDataV4Name()).append("','").append(date).append("' ),");
                            makeSqlTotalCount++;
                            if (count[0] >= 2000) {
                                makeSqlTotalUseMs += System.currentTimeMillis() - startMs1[0];
                                startMs1[0] = System.currentTimeMillis();
                                sql.setLength(sql.length() - 1);//去尾 .
                                jdbcTemplate.execute(sql.toString());
                                sql.setLength(0);
                                sql.append(sqlHead);
                                count[0] = 0;
                            }
                        }
                    }
                );
        	});
        });
        makeSqlTotalUseMs += System.currentTimeMillis() - startMs1[0];

        if(count[0]>0) {
        	sql.setLength(sql.length()-1);//去尾 . 
			jdbcTemplate.execute(sql.toString());
		}

        logger.info("> 路径拓扑节点对的时延 execute sql  done date="+date.toString());
        // 清除对象
        pathLinkObj.clear();
        linkDataSaveMap.clear();        
        
        try {
        	long useMs = System.currentTimeMillis() - startMs;
        	logger.info(
        		">[lx0421] handleLinkData total time=" + useMs + " 数据create_time="+date.toString() + ", makeSqlTotalUseMs="+makeSqlTotalUseMs+
        		", makeSqlTotalCount="+makeSqlTotalCount+"/avg="+(makeSqlTotalCount>0?makeSqlTotalUseMs/makeSqlTotalCount:0)
        		+", totalSearchTs="+totalSearchTs+", ct="+ct+", avg="+(ct>0?totalSearchTs/ct:0)
        	);
        } catch (Exception e) {
			logger.info("> lx0421 "+e.getMessage());
		}
    }


    private PathLinkDataObj getPathLinkList() {
        List<EngineRoute> routeList = pathLinkDataDao.getRouteList();
        if (CollectionUtils.isEmpty(routeList)) {
            return new PathLinkDataObj(Collections.EMPTY_LIST, Collections.EMPTY_SET);
        }
        Set<String> untrustNodeIps = new HashSet<>();
        List<PathLinkDataVo> list = Lists.newLinkedList();

        for (EngineRoute route : routeList) {
            // 处理不可信节点
            String untrustNodes = route.getUntrustNodes();
            if (StringUtils.isNotBlank(untrustNodes)) {
                String[] nodes = untrustNodes.split(",");
                untrustNodeIps.addAll(Sets.newHashSet(nodes));
            }
            if (StringUtils.isEmpty(route.getRoutePathLayer()) || "null".equals(route.getRoutePathLayer())) {
                continue;
            }
            List<String> ipList = ListUtils.StringToListStr(route.getRoutePathLayer());//路径ip集合
            List<String> unodeIpList = ListUtils.StringToListStr(route.getUntrustNodes());//不可用节点
            if (route.getSourceIp() != null && !ipList.contains(route.getSourceIp())) {
                ipList.add(0, route.getSourceIp());
            }
            if (route.getDestIp() != null && !ipList.contains(route.getDestIp())) {
                ipList.add(route.getDestIp());
            }
            List<String> routeIpList = ListUtils.StringToListStr(route.getRoutePathLayer());//路径ip集合
            for (String ip : ipList) {
                //过滤掉*,不可用节点
                if (!"*".equals(ip) && !unodeIpList.contains(ip)) {
                    routeIpList.add(ip);
                }
            }
            for (int i = 0; i < routeIpList.size() - 1; i++) {
                PathLinkDataVo linkData = new PathLinkDataVo();
                linkData.setTaskId(route.getBizDataId());
                linkData.setRouteId(route.getId());
                linkData.setPreIp(routeIpList.get(i));
                linkData.setCurIp(routeIpList.get(i + 1));
                list.add(linkData);
            }
        }

        return new PathLinkDataObj(list, untrustNodeIps);
    }

    class PathLinkDataObj {

        private final List<PathLinkDataVo> datas;
        private final Set<String> untrustNodeIps;

        public PathLinkDataObj(List<PathLinkDataVo> datas, Set<String> untrustNodeIps) {
            this.datas = datas;
            this.untrustNodeIps = untrustNodeIps;
        }

        public List<PathLinkDataVo> getDatas() {
            return datas;
        }

        public Set<String> getUntrustNodeIps() {
            return untrustNodeIps;
        }

        public void clear() {
            if (datas != null) {
                datas.clear();
            }
            if (untrustNodeIps != null) {
                untrustNodeIps.clear();
            }
        }
    }

    public static void main(String[] args) {
        String sourceIp = "8.1.16.6";
        String path = "8.1.16.1,8.1.16.2,8.1.16.3,8.1.16.4,8.1.16.5,8.1.16.6";
        if (path.contains(sourceIp)) {
            System.out.println();
        }
    }

    /**
     * 根据数据计算出data_v4的表名
     *
     * @return key 为 data_v 表名称 ， value 为 要查询的 表中的 routeId
     */
    private Map<String, Set<Integer>> getTableNameList() {
        List<PathLinkDataVo> taskRouteList = pathLinkDataDao.getTaskRouteList();
        if (CollectionUtils.isEmpty(taskRouteList)) {
            return Collections.EMPTY_MAP;
        }
        Map<String, Set<Integer>> tableNameDataMap = new LinkedHashMap<>();
        for (PathLinkDataVo taskRouteVo : taskRouteList) {
            if (Objects.isNull(taskRouteVo.getTaskId()) || Objects.isNull(taskRouteVo.getRouteId())) {
                continue;
            }
            String tableName = DynamicTableContext.genTraceDataTableName(taskRouteVo.getTaskId(), taskRouteVo.getRouteId(), 0);
            if (StringUtils.isNotEmpty(tableName)) {
                tableNameDataMap.putIfAbsent(tableName, Sets.newHashSet());
                tableNameDataMap.get(tableName).add(taskRouteVo.getRouteId());
            }
        }
        return tableNameDataMap;
    }

}

