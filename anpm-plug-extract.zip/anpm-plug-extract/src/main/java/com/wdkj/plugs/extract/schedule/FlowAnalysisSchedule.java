package com.wdkj.plugs.extract.schedule;

import com.wdkj.plugs.extract.service.IFlowAnalysisService;
import com.wdkj.plugs.extract.service.IRunTimeService;
import com.wdkj.plugs.extract.util.DateUtil;
import com.wdkj.plugs.utils.enu.LogLevelEnum;
import com.wdkj.plugs.utils.enu.LogTypeEnum;
import com.wdkj.plugs.utils.enu.ServiceTypeEnum;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.sql.DataSource;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import org.springframework.beans.factory.annotation.Qualifier;
/**
 * @ClassName 流量分析
 * @Description 主要做流量分析数据抽取，抽取一天得数据
 * @Author yuy
 * @Date 2023/07/25
 */
@Component
public class FlowAnalysisSchedule {
    private static Logger log = LoggerFactory.getLogger(FlowAnalysisSchedule.class);

    @Autowired
    private IFlowAnalysisService flowAnalysisService;

    private final Lock lockExecute = new ReentrantLock();

    // 创建一个线程池用于异步执行任务
    private final ExecutorService executor = Executors.newFixedThreadPool(2);

    /*@Autowired
    @Qualifier("clickDataSource") // 明确使用 ClickHouse 数据源
    private DataSource clickHouseDataSource;
    @PostConstruct
    public void init() {
        flowAnalysisService.setDataSource(clickHouseDataSource); // 传递 DataSource
    }*/

    @Scheduled(cron = "0 */1 * * * ?")
    public void executeSflowDataApply() {
        if (lockExecute.tryLock()) {  // 尝试获取锁
            try {
                    log.info("---------start FlowAnalysis数据抽取任务开始 Job----------");
                    // 使用 CompletableFuture 异步执行任务
                    CompletableFuture<Void> future1 = CompletableFuture.runAsync(() -> {
                        log.info("---------start FlowAnalysis数据抽取应用小时任务开始 Job----------");
                        long a = System.currentTimeMillis() / 1000;
                        flowAnalysisService.analysisDataAppCurrentDayHour(1, 0);
                        long b = System.currentTimeMillis() / 1000;
                        log.info("---------end FlowAnalysis数据抽取应用小时任务结束 Job----------开始时间:"+DateUtil.secondToDate(a)+"结束时间:"+DateUtil.secondToDate(a)+"相差:"+(b-a)/60+"分钟");
                        log.info("---------start FlowAnalysis数据抽取应用天任务开始 Job----------");
                        long c = System.currentTimeMillis() / 1000;
                        flowAnalysisService.analysisDataAppOldDay(0, 1);
                        long d = System.currentTimeMillis() / 1000;
                        log.info("---------end FlowAnalysis数据抽取应用天任务结束 Job----------开始时间:"+DateUtil.secondToDate(c)+"结束时间:"+DateUtil.secondToDate(d)+"相差:"+(d-c)/60+"分钟");
                    }, executor);
                    CompletableFuture<Void> future2 = CompletableFuture.runAsync(() -> {
                        log.info("---------start FlowAnalysis数据抽取ip节点对小时任务开始 Job----------");
                        long e = System.currentTimeMillis() / 1000;
                        flowAnalysisService.analysisDataIpCurrentDayHour(3, 2);
                        long f = System.currentTimeMillis() / 1000;
                        log.info("---------end FlowAnalysis数据抽取ip节点对小时任务结束 Job----------开始时间:"+DateUtil.secondToDate(e)+"结束时间:"+DateUtil.secondToDate(f)+"相差:"+(f-e)/60+"分钟");
                        log.info("---------start FlowAnalysis数据抽取ip节点对天任务开始 Job----------");
                        long g = System.currentTimeMillis() / 1000;
                        flowAnalysisService.analysisDataIpOldDay(2, 3);
                        long h = System.currentTimeMillis() / 1000;
                        log.info("---------end FlowAnalysis数据抽取ip节点对天任务结束 Job----------开始时间:"+DateUtil.secondToDate(g)+"结束时间:"+DateUtil.secondToDate(h)+"相差:"+(h-g)/60+"分钟");
                    }, executor);
                    // 等待所有任务完成
                    CompletableFuture.allOf(future1, future2).join();
                    log.info("---------end FlowAnalysis数据抽取结束任务 Job----------");
            } catch (Exception e) {
                e.printStackTrace();
                log.error("流量分析抽取-报错"+e.getMessage());
            } finally {
                lockExecute.unlock();  // 释放锁
                log.info("---------end FlowAnalysis数据抽取结束任务 Job----------");
            }
        } else {
            log.info("流量分析抽取-上一个任务还未完成，跳过本次执行");
        }
    }

    @PreDestroy
    public void destroy() {
        log.info("关闭线程池...");
        executor.shutdown(); // 优雅关闭线程池
    }

}
