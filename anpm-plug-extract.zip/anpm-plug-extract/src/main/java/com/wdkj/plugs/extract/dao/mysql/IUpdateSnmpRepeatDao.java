package com.wdkj.plugs.extract.dao.mysql;

import com.wdkj.plugs.model.po.SnmpRepeat;
import com.wdkj.plugs.model.po.SpecialData;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @ClassName IUpdateSnmpRepeatDao
 * @Description TODO
 * @Author Mr.xie
 * @Date 2021/5/26 10:09
 */
@Mapper
@Component
public interface IUpdateSnmpRepeatDao {
    List<SnmpRepeat> getSnmpRepeat();

    List<SpecialData> getSpecialData();

    void updateSnmpRepeatOperator(SnmpRepeat snmpRepeat);
}
