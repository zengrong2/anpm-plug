package com.wdkj.plugs.extract.schedule;

import com.wdkj.plugs.extract.service.ISysDialConfigDestIpNameServer;
import com.wdkj.plugs.systemlog.service.ISystemLogService;
import com.wdkj.plugs.utils.enu.LogLevelEnum;
import com.wdkj.plugs.utils.enu.LogTypeEnum;
import com.wdkj.plugs.utils.enu.ServiceTypeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;

import javax.annotation.Resource;

/***
 *   定时抽取拨测任务的目标名称，并存放到数据库。
 *   2024年9月19日10:09:14 修改： 现在不放在抽取里面，直接放在平台程序里面，防止内存占用过高。
 * @author zxq(956607644 @ qq.com)
 * @date 2024/9/12 16:17
 */
//@Component
@Deprecated
public class UpdateTaskDestIpNameSchdeule implements DisposableBean {

    private static Logger log = LoggerFactory.getLogger(UpdateTaskDestIpNameSchdeule.class);

    @Resource
    private ISysDialConfigDestIpNameServer sysDialConfigDestIpNameServer;
    @Resource
    private ISystemLogService systemLogService;

    /**
     * 任务执行频率，1分钟执行一次
     */
//    @Scheduled(cron = "0 0/1 * * * ? ")
//    @Async
    @Deprecated
    public void updateTaskDestIpName() {
        try {
            sysDialConfigDestIpNameServer.updateTaskDestIpName();
        } catch (Exception e) {
            log.error("执行报错->", e);
            systemLogService.saveLog(LogLevelEnum.LEVEL1.code(), e.getMessage(), ServiceTypeEnum.EXTRACT.lable(), LogTypeEnum.LOG_TYPE_ERROR.lable(), "用户检查登录状态定时任务", this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

    @Override
    @Deprecated
    public void destroy() throws Exception {
        log.error("执行销毁逻辑");
        sysDialConfigDestIpNameServer.destroy();
    }
}
