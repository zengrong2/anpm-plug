package com.wdkj.plugs.extract.service;

import com.wdkj.plugs.model.po.SysDialConfigDestIpNamePo;

import java.util.List;

/**
 * @author 郑兴泉 956607644@qq.com
 * @data 2024/9/12
 * 描述：
 */
@Deprecated
public interface ISysDialConfigDestIpNameServer {
    @Deprecated
    void updateTaskDestIpName();
    @Deprecated
    void addOrUpdate(List<SysDialConfigDestIpNamePo> dataList);
    @Deprecated
    void add(List<SysDialConfigDestIpNamePo> dataList);
    @Deprecated
    void update(List<SysDialConfigDestIpNamePo> dataList);
    @Deprecated
    void destroy();

}
