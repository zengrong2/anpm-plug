package com.wdkj.plugs.extract.service;

import javax.sql.DataSource;

public interface IFlowAnalysisService {

    void analysisDataAppOldDay(Integer type,Integer hourType);

    void analysisDataAppCurrentDayHour(Integer type,Integer dayType);


    void analysisDataIpOldDay(Integer type,Integer hourType);

    void analysisDataIpCurrentDayHour(Integer type,Integer dayType);

//    void setDataSource(DataSource clickHouseDataSource);
}
