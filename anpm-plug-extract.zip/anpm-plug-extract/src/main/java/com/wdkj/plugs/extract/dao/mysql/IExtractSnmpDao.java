package com.wdkj.plugs.extract.dao.mysql;

import com.wdkj.plugs.model.po.ExtractSnmpData;
import org.apache.ibatis.annotations.Param;
import org.mapstruct.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

/**
 * @ClassName ExtractSnmpDao
 * @Description TODO
 * @Author Mr.xie
 * @Date 2021/10/13 17:00
 */
@Mapper
@Repository
public interface IExtractSnmpDao {
    List<ExtractSnmpData> getRepeatListByLinkId(@Param("linkIds") Set<Integer> linkId);
}
