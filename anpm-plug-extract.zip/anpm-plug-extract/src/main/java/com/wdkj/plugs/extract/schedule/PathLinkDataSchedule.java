package com.wdkj.plugs.extract.schedule;


import com.wdkj.plugs.core.i18n.LocaleMessage;
import com.wdkj.plugs.extract.service.PathLinkDataService;
import com.wdkj.plugs.systemlog.service.ISystemLogService;
import com.wdkj.plugs.utils.enu.LogLevelEnum;
import com.wdkj.plugs.utils.enu.LogTypeEnum;

import com.wdkj.plugs.utils.enu.ServiceTypeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;


import cn.hutool.core.date.StopWatch;


/**
 * @author lp
 */
@Component
public class PathLinkDataSchedule {
    @Autowired
    private LocaleMessage localeMessage;

    private static Logger logger = LoggerFactory.getLogger(PathLinkDataSchedule.class);
    @Autowired
    private PathLinkDataService pathLinkDataService;
    @Autowired
    private ISystemLogService systemLogService;

    @Value("${delayLossQueryMinute:480}")
    private Integer delayLossQueryMinute;

    @Scheduled(cron = "0 */5 * * * *")
//    @Async
    public void handleLinkData() {
        try {
            logger.info("-----开始执行路径拓扑节点对的时延，丢包数据更新-----");
            StopWatch stopWatch = new StopWatch();
            stopWatch.start(localeMessage.getMessage("anpmReportServer.TotalPathTime"));
            pathLinkDataService.handleLinkData(delayLossQueryMinute);
            stopWatch.stop();
            logger.info("-----结束执行路径拓扑节点对的时延，丢包数据更新,耗时"+stopWatch.getLastTaskTimeMillis()+"ms-----");
            systemLogService.saveLog(LogLevelEnum.LEVEL3.code(),localeMessage.getMessage("anpmReportServer.TDIETEPTNPPLDUT")+stopWatch.getLastTaskTimeMillis()+"ms", ServiceTypeEnum.REPORT.lable(),LogTypeEnum.LOG_TYPE_INFO.lable(), localeMessage.getMessage("anpmReportServer.SEODPLD"), this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName());
        }catch (Exception e) {
            e.printStackTrace();
            logger.error("执行路径拓扑节点对的时延丢包数据更新异常："+e.getMessage());
            systemLogService.saveLog(LogLevelEnum.LEVEL1.code(),e.getMessage(),ServiceTypeEnum.REPORT.lable(),LogTypeEnum.LOG_TYPE_ERROR.lable(),localeMessage.getMessage("anpmReportServer.SEODPLD"), this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

}
