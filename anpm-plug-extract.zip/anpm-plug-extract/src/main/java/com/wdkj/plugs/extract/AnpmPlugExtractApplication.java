package com.wdkj.plugs.extract;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Properties;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.wdkj.plugs.extract.util.DateUtil;
import com.wdkj.plugs.extract.web.OperationToolController;


@EnableScheduling
@SpringBootApplication
@ComponentScan(basePackages ={ "com.wdkj.plugs.*" })
@EnableAsync
public class AnpmPlugExtractApplication {
	public static Properties main_properties = null; 
	public static final int getProcessID() {  
        RuntimeMXBean runtimeMXBean = ManagementFactory.getRuntimeMXBean();
        System.out.println(runtimeMXBean.getName());
        return Integer.valueOf(runtimeMXBean.getName().split("@")[0])  
                .intValue();  
    }
	public static String GetServerInfo() {
        try {
        	StringBuilder sb = new StringBuilder();
        	sb.append("Start at ").append(DateUtil.getNowDateTimeString()).append(", pid=").append(getProcessID()).append(", ips=");
            Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            while (networkInterfaces.hasMoreElements()) {
                NetworkInterface networkInterface = networkInterfaces.nextElement();
                Enumeration<InetAddress> inetAddresses = networkInterface.getInetAddresses();
                while (inetAddresses.hasMoreElements()) {
                    InetAddress inetAddress = inetAddresses.nextElement();
                    if (!inetAddress.isLoopbackAddress() && inetAddress.isSiteLocalAddress()) {
                        String ipAddress = inetAddress.getHostAddress();
                        sb.append(ipAddress).append(", ");
//                        System.out.println("本机IP地址：" + ipAddress);
                    }
                }
            }
            return sb.toString();
        } catch (SocketException e) {
            e.printStackTrace();
            return e.getMessage();
        }
    }
	public static String dbgMsg = "";
	public static void getManifestProperty() {
        JarFile jarFile = null;
        try {
            // 获取jar的运行路径，因linux下jar的路径为”file:/app/.../test.jar!/BOOT-INF/class!/“这种格式，所以需要去掉”file:“和”!/BOOT-INF/class!/“
            String jarFilePath = new AnpmPlugExtractApplication().getClass().getProtectionDomain().getCodeSource().getLocation().getPath();
            System.out.println("jarFilePath="+jarFilePath);
            //dbgMsg += "\njarFilePath1="+jarFilePath;
            if (jarFilePath.startsWith("file")) {
                jarFilePath = jarFilePath.substring(5);
            }
            if(jarFilePath.contains("!")) {
            	jarFilePath = jarFilePath.substring(0, jarFilePath.indexOf("!"));
            }
            dbgMsg += "\njarFilePath2="+jarFilePath;
            // 通过JarFile的getJarEntry方法读取META-INF/MANIFEST.MF
            jarFile = new JarFile(jarFilePath);
            JarEntry entry = jarFile.getJarEntry("META-INF/MANIFEST.MF");
            // 如果读取到MANIFEST.MF文件内容，则转换为string
            if (entry != null) {
            	main_properties = new Properties();
            	main_properties.load(jarFile.getInputStream(entry));            
            } else
            	dbgMsg += "\n entry !== null";
        } catch(java.io.FileNotFoundException nex) {
        	System.err.println(nex.getMessage());
        	dbgMsg += "\n error "+OperationToolController.getStackTrace(nex);
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (jarFile != null) {
                    jarFile.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
	public static long StringToTs(String str) {
		try {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = simpleDateFormat.parse(str);
			return date.getTime();			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	public static String runInfo = "";
	public static void main(String[] args) {
		if(args.length>0)
			dbgMsg+="\n"+args[0];
		runInfo = GetServerInfo();
		getManifestProperty();
		if(main_properties!=null) {
			try {
				runInfo  += ", Build Directory="+main_properties.getProperty("Build-Dir")+"," + "Build Time="+DateUtil.formatter.format(new Date(StringToTs(main_properties.getProperty("Build-Time-GMT")) + 3600000*8))+",";
			} catch(Exception e) {
				dbgMsg += "\nerror="+OperationToolController.getStackTrace(e);
				e.printStackTrace();
			}
		}
		SpringApplication.run(AnpmPlugExtractApplication.class, args);
		dbgMsg+= "\n启动成功";
	}

}
