package com.wdkj.plugs.extract.service;

/**
 * @ClassName IUpdateSnmpRepeatService
 * @Description TODO
 * @Author Mr.xie
 * @Date 2021/5/26 9:59
 */
public interface IUpdateSnmpRepeatService {
    void updateSnmpRepeat();
}
