package com.wdkj.plugs.extract.dao.mysql;

import com.wdkj.plugs.model.po.SysGether;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;


@Mapper
@Repository
public interface ISysGetherDao {

    List<SysGether> getList();

	void updateByIds(@Param("ids")List<Integer> ids);

	Integer getGetherAlarmCount();

	List<SysGether> getSflowList();

	Integer getSflowGetherAlarmCount();

	void updateSflowByIds(@Param("ids")List<Integer> ids);
}
