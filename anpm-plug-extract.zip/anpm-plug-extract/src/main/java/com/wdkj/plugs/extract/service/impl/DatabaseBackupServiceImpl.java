package com.wdkj.plugs.extract.service.impl;

import cn.hutool.core.util.ZipUtil;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.Session;
import com.wdkj.plugs.core.model.to.Result;
import com.wdkj.plugs.core.service.ISecretKeyService;
import com.wdkj.plugs.extract.dao.mysql.IDatabaseBackupDao;
import com.wdkj.plugs.extract.dao.mysql.IIndexSyncDao;
import com.wdkj.plugs.extract.service.IDatabaseBackupService;
import com.wdkj.plugs.extract.util.ClickHouseUtil;
import com.wdkj.plugs.extract.util.MysqlUtil;
import com.wdkj.plugs.extract.util.OpenGaussUtil;
import com.wdkj.plugs.extract.util.ShellUtil;
import com.wdkj.plugs.model.po.BackupTableConfig;
import com.wdkj.plugs.model.po.DBConfigPo;
import com.wdkj.plugs.model.po.DatabaseBackup;
import com.wdkj.plugs.model.vo.BackupDefaultValue;
import com.wdkj.plugs.utils.constant.BaseConstant;
import com.wdkj.plugs.utils.date.DateUtil;
import com.wdkj.plugs.utils.enu.MessageEnum;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.yandex.clickhouse.response.ClickHouseResultSet;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.io.*;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.*;

/**
 * @ClassName DatabaseBackupServiceImpl
 * @Description TODO
 * @Author Mr.xie
 * @Date 2021/10/20 10:04
 */
@Service
public class DatabaseBackupServiceImpl implements IDatabaseBackupService {

    private static Logger logger = LoggerFactory.getLogger(DatabaseBackupServiceImpl.class);

    @Autowired
    private IDatabaseBackupDao databaseBackupDao;
    @Autowired
    private IIndexSyncDao indexSyncDao;

    private static final String BACK_SERVER_IP = "BACK_SERVER_IP";
    private static final String BACK_SERVER_USERNAME = "BACK_SERVER_USERNAME";
    private static final String BACK_SERVER_PASSWORD = "BACK_SERVER_PASSWORD";
    private static final String BACK_SERVER_DESTDIR = "BACK_SERVER_DESTDIR";
    private static final String BACK_PATH = "BACK_PATH";
    private static final String BACK_CYCLE = "BACK_CYCLE";

    //    @Value("${spring.datasource.mysql.jdbcUrl}")
//    public String MYSQL_URL = null;
//    @Value("${spring.datasource.mysql.username}")
//    public String MYSQL_USERNAME = null;
//    @Value("${spring.datasource.mysql.password}")
//    public String MYSQL_PASSWORD = null;
    @Value("${spring.datasource.click.jdbcUrl}")
    public String CLICKHOUSE_URL = null;
    @Value("${spring.datasource.click.username}")
    public String CLICKHOUSE_USERNAME = null;
    @Value("${spring.datasource.click.password}")
    public String CLICKHOUSE_PASSWORD = null;

    @Resource(name = "clickDataSource")
    private DataSource clickDataSource;

    @Resource(name = "gaussDataSource")
    private DataSource mysqlDataSource;

    // gauss相关配置
    @Value("${spring.datasource.gauss.jdbcUrl}")
    public String GAUSS_URL = null;
    @Value("${spring.datasource.gauss.username}")
    public String GAUSS_USERNAME = null;
    @Value("${spring.datasource.gauss.password}")
    public String GAUSS_PASSWORD = null;

    @Value("${anpm.backup.data.clickhouse.export-time:#{500000}}")
    private Integer backupDataExportTime;

    @Value("${anpm.backup.data.mysql.export-time:#{100000}}")
    private Integer backupDataMysqlExportTime;

    @Value("${anpm.monitor-timeout: 360000}")
    private int timeout;

    // 文件存储目录
    @Value("${anpm.backup-path:/web/backup-path}")
    public String backupPath = "";

    @Resource
    private ISecretKeyService secretKeyService;

    private Statement mysqlStatement;
    private Statement clickStatement;
    private String mysqlDatabase;
    private List<String> clickHouseTableNameList = null;
    private String mysqlFileName = "";
    private String zipFileName = "";
    private File generatedZipFile;

    @Override
    public List<BackupDefaultValue> getBackupDefaultValue() {
        return databaseBackupDao.getBackupDefaultValue();
    }

    @Override
    public void dataSourceBackup(LocalDateTime queryEndTime, Boolean isFirstExtract, Map<String, String> map) {
        Session conn = null;
        FileOutputStream mysqlOutputStream = null;
        FileOutputStream clickHouseOutputStream = null;
        long time = System.currentTimeMillis();
        String taskId = time + "";
        //判断
        try {
            //获取自动备份默认值
            Long backCycle = Long.parseLong(map.get(BACK_CYCLE));
            String backType = map.get(BACK_PATH);
            String backServerIp = map.get(BACK_SERVER_IP);
            String backServerUsername = map.get(BACK_SERVER_USERNAME);
            String backServerPassword = map.get(BACK_SERVER_PASSWORD);
            String backServerDestdir = map.get(BACK_SERVER_DESTDIR);
            if (!backServerDestdir.startsWith(BaseConstant.SLASH)) {
                backServerDestdir = BaseConstant.SLASH + backServerDestdir;
            }
            if (!backServerDestdir.endsWith(BaseConstant.SLASH)) {
                backServerDestdir = backServerDestdir + BaseConstant.SLASH;
            }
            String backupPath = backServerDestdir;
            backupPath = backupPath.replaceAll(":", "/").replaceAll("：", "/");
            //处理查询开始和结束时间
            DateTimeFormatter df = DateTimeFormatter.ofPattern(DateUtil.YYYYMMDDHHMMSS);
            String startTime = queryEndTime.minusDays(backCycle).format(df);
            String endTime = queryEndTime.format(df);

            String dirName = backupPath;
            logger.info("save backupPath =: " + dirName);
            File file = new File(dirName);
            if (!file.exists()) {
                boolean res = file.mkdirs();
                if (!res) {
                    logger.info("Unable to create temp dir: " + file.getAbsolutePath());
                    throw new IOException("Unable to create temp dir: " + file.getAbsolutePath());
                }
            }
            String dateTimeStr = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
            File sqlFolder = new File(backupPath + "/" + dateTimeStr);
            if (!sqlFolder.exists()) {
                boolean res = sqlFolder.mkdirs();
                if (!res) {
                    throw new IOException(": Unable to create temp dir: " + sqlFolder.getAbsolutePath());
                }
            }
            DatabaseBackup backup = new DatabaseBackup();
            backup.setCreateTime(new Date());
            backup.setTaskId(taskId);
            // String path = filePath + fileName;
            backup.setServerIp(backServerIp);
            backup.setServerUserName(backServerUsername);
            backup.setServerDestdir(backServerDestdir);
            backup.setType(0);
            //保存clickhouse文件
            File clickHouseSqlFolder = new File(backupPath + "/" + dateTimeStr + "/clickHouse");
            if (!clickHouseSqlFolder.exists()) {
                boolean res = clickHouseSqlFolder.mkdirs();
                if (!res) {
                    throw new IOException(": Unable to create temp dir: " + clickHouseSqlFolder.getAbsolutePath());
                }
            }
            //保存mysql文件
            File mysqlSqlFolder = new File(backupPath + "/" + dateTimeStr + "/openGauss");
            if (!mysqlSqlFolder.exists()) {
                boolean res = mysqlSqlFolder.mkdirs();
                if (!res) {
                    throw new IOException(": Unable to create temp dir: " + mysqlSqlFolder.getAbsolutePath());
                }
            }
            //获得clickHouse所有的表名
            Result<?> tabResult = getClickHouseTabNameList();
            if (tabResult.getCode() != MessageEnum.SUCCESS.code()) {
                logger.error(tabResult.getMsg());
            }
            //创建clickHouse的脚本
            Result<?> clickResult = createClickHouseSql(startTime, endTime, clickHouseSqlFolder, dateTimeStr);
            if (clickResult.getCode() != MessageEnum.SUCCESS.code()) {
                logger.error(clickResult.getMsg());
            }
            // 创建mysql的脚本
            Result<?> mysqlResult = createMysql(startTime, endTime, mysqlSqlFolder, dateTimeStr);
            if (mysqlResult.getCode() != MessageEnum.SUCCESS.code()) {
                logger.error(mysqlResult.getMsg());
            }
            // zip the file
            zipFileName = dirName + BaseConstant.SLASH + dateTimeStr + "_anpm.zip";
//            generatedZipFile = new File(zipFileName);
            String absolutePath = sqlFolder.getAbsolutePath();
            ZipUtil.zip(absolutePath, zipFileName, true);
            // clear the generated temp files
            clearTempFiles(true, dirName + "/" + dateTimeStr);
            backup.setFilePath(zipFileName);
            backup.setServerPassword(map.get(BACK_SERVER_PASSWORD));
            File file2 = new File(zipFileName);
            if (file2.exists()) {
                backup.setFileSize(file2.length());
                if (BaseConstant.DATA_BACKUP_REMOTE_TYPE.equals(backType)) {
                    backup.setType(1);
                    backup.setFilePath(backServerDestdir + File.separator + dateTimeStr + "_anpm.zip");
                    //表示备份到远程服务器
                    /*conn = new ch.ethz.ssh2.Connection(backServerIp);
                    conn.connect();
                    boolean isAuthenticated = conn.authenticateWithPassword(backServerUsername, AESUtil.aesDecrypt(backServerPassword,AESUtil.key_pwd));
                    if (isAuthenticated == false){
                       logger.error("Authentication failed.连接服务器失败！");
                       return;
                    }
                    logger.info("Authentication success.连接服务器成功！");
                    session = conn.openSession();
                    session.execCommand("mkdir -p "+backServerDestdir);
                    SCPClient client = new SCPClient(conn);
                    //本地文件scp到远程目录
                    client.put(zipFileName, backServerDestdir);*/
                    // 用户名和密码都加密了,这里需要解密。
                    String realServerPassword = secretKeyService.enAnddeByServer(backServerPassword, 2);
                    String realServerUsername = secretKeyService.enAnddeByServer(backServerUsername, 2);
//                    String realServerPassword = AESUtil.aesDecrypt(backServerPassword, AESUtil.key_pwd);
//                    String realServerUsername = AESUtil.aesDecrypt(backServerUsername, AESUtil.key_pwd);
//                    String newRealServerPassword =  AESUtil.aesDecrypt(realServerPassword,AESUtil.key_pwd);
                    logger.error("Authentication 连接服务器 userName:{} , password:{}", realServerUsername, realServerPassword);
                    ShellUtil shell = new ShellUtil(backServerIp, realServerUsername, realServerPassword, 22, timeout);
                    conn = shell.connect();
                    if (conn == null) {
                        logger.error("Authentication failed.连接服务器失败！");
                        return;
                    }
                    shell.execCommand(conn, "mkdir -p " + backServerDestdir);
                    uploadFile(absolutePath + "_anpm.zip", backServerDestdir, conn);
                    logger.error("Authentication 连接服务器 file2:{} ", file2.getAbsolutePath());
                    //删除本地文件
                    file2.delete();
                }
            }
            backup.setStatus("1"); //备份成功
            databaseBackupDao.delBackRecord();
            databaseBackupDao.saveBackRecord(backup);
            Map<String, String> paramMap = new HashMap<>(2);
            paramMap.put("table", "database_backup");
            paramMap.put("syncTime", endTime);
            // 保存或更新抽取时间
            if (isFirstExtract) {
                indexSyncDao.saveSyncDate(paramMap);
            } else {
                indexSyncDao.updateSyncDate(paramMap);
            }
            File unzipFile = new File(dirName + BaseConstant.SLASH + dateTimeStr);
            if (unzipFile.exists()) {
                logger.error("文件存在 ， 删除文件：{}", unzipFile.getAbsolutePath());
                // 获取目录中的所有文件和子目录
                deleteDirectory(unzipFile);
            }
        } catch (Exception e) {
            logger.error("#备份错误## Export error=>", e);
//            Integer baseBackupsById = databaseBackupDao.getBaseBackupsById(taskId);
            DatabaseBackup databaseBackup = new DatabaseBackup();
            databaseBackup.setTaskId(taskId);
            databaseBackup.setMessage(e.getMessage());
            databaseBackup.setStatus("2"); //失败
            databaseBackupDao.delBackRecord();
            databaseBackupDao.saveBackRecord(databaseBackup);
//            if (Objects.isNull(baseBackupsById) || baseBackupsById == 0) {
//
//            } else {
//                databaseBackupDao.updateBaseBackupsById(databaseBackup);
//            }
        } finally {
            if (null != conn) {
                try {
                    conn.disconnect();
                } catch (Exception e) {
                    logger.error("Session 关闭连接 失败！");
                }
            }
            /*if (null!=session){
                try {
                    session.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }*/
            if (null != mysqlOutputStream) {
                try {
                    mysqlOutputStream.close();
                } catch (IOException e) {
                    logger.error("mysqlOutputStream 关闭连接 失败！");
                }
            }
            if (null != clickHouseOutputStream) {
                try {
                    clickHouseOutputStream.close();
                } catch (IOException e) {
                    logger.error("clickHouseOutputStream 关闭连接 失败！");
                }
            }
        }

    }

    /**
     * 删除目录中的所有文件和子目录
     *
     * @param directory
     * @return
     */
    public boolean deleteDirectory(File directory) {
        if (!directory.exists()) {
            return true;
        }
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    deleteDirectory(file); // 递归删除子目录
                } else {
                    file.delete(); // 删除文件
                }
            }
        }
        return directory.delete(); // 删除目录本身
    }

    public void uploadFile(String directory, String uploadFile, com.jcraft.jsch.Session session) {
        ChannelSftp channelSftp = null;
        try {
            // 打开channelSftp
            channelSftp = (ChannelSftp) session.openChannel("sftp");
            // 远程连接
            channelSftp.connect();
            // 创建一个文件名称问uploadFile的文件
//            File file = new File(directory);
            // 将文件进行上传(sftp协议)
            // 将本地文件名为src的文件上传到目标服务器,目标文件名为dst,若dst为目录,则目标文件名将与src文件名相同.
            // 采用默认的传输模式:OVERWRITE
            /*channelSftp.put(new FileInputStream(file),uploadFile, ChannelSftp.OVERWRITE);*/
            channelSftp.put(directory, uploadFile);
            logger.error("2、directory : {} ,uploadFile:{} 文件上传成功.....", directory, uploadFile);
        } catch (Exception e) {
            logger.error("2、file : {} 文件上传失败 ， error => ", directory, e);
            throw new RuntimeException(e);
        } finally {
            // 切断远程连接
            if (channelSftp != null) {
                channelSftp.exit();
            }
        }

    }

    // 创建mysql的脚本
    public Result<?> createMysql(String startTime, String endTime, File sqlFolder, String dateTimeStr) {
        Connection connection = null;
        Result<?> sqlResult = null;
        try {
            mysqlDatabase = findMysqlDBName(GAUSS_URL);// 获得数据库名称和地址
            String driverName = "";
            connection = OpenGaussUtil.connectWithURL(GAUSS_USERNAME, GAUSS_PASSWORD, GAUSS_URL, driverName);
            mysqlStatement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            // 获得导出mysql的脚本
            sqlResult = exportMysqlToSql(startTime, endTime, sqlFolder, dateTimeStr);
        } catch (Exception e) {
            logger.error("### createMysql error={}", e.getMessage());
            return new Result<>(MessageEnum.FAIL, "createMysql is error:" + e.getMessage());
        } finally {
            if (null != mysqlStatement) {
                try {
                    mysqlStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (null != connection) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return sqlResult;
    }

    /**
     * 导出mysql所有表的结构和数据
     *
     * @return String
     * @throws SQLException exception
     */
    private Result<?> exportMysqlToSql(String startTime, String endTime, File sqlFolder, String dateTimeStr) throws SQLException {
        String dirName = backupPath;
        logger.info("save backupPath =: " + dirName);
        //直接写入文件
        if (!sqlFolder.exists()) {
            boolean res = sqlFolder.mkdir();
            if (!res) {
                try {
                    throw new IOException(": Unable to create temp dir: " + sqlFolder.getAbsolutePath());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        /*String mysqlFileName = getMySqlFilename(dateTimeStr);// 获得clickhouse文件名
        File file = new File(sqlFolder + "/" + mysqlFileName);

        try (FileOutputStream mysqlOutputStream = new FileOutputStream(file, true);
             OutputStreamWriter osw = new OutputStreamWriter(mysqlOutputStream, "UTF-8");) {
            StringBuilder sql = new StringBuilder();*/
        List<BackupTableConfig> tables = databaseBackupDao.list(); // MysqlUtil.getAllTables(database,statement);
        for (BackupTableConfig s : tables) {
            String tabName = s.getName();
            try {
                Long tableDataCunt = getDataCountInsertStatement(s, startTime, endTime);
                logger.info("myqsql表名" + s.getName() + "数量" + tableDataCunt);
                if (tableDataCunt > 0) {
                    long baseNum = backupDataMysqlExportTime.longValue();
                    long multiple = tableDataCunt / baseNum;
                    long remainder = tableDataCunt % baseNum;
                    long startNum = 0;
                    if (multiple > 0) {
                        for (long i = 0; i < multiple; i++) {
                            String mysqlFileName = getNewMySqlFilename(dateTimeStr, tabName, i);// 获得clickhouse文件名
                            //生成对应表clickHouse文件
                            File file = new File(sqlFolder + "/" + mysqlFileName);
                            try (FileOutputStream clickHouseOutputStream = new FileOutputStream(file, true); OutputStreamWriter osw = new OutputStreamWriter(clickHouseOutputStream, "UTF-8");) {
                                StringBuilder sql = new StringBuilder();
                                osw.write(sql.toString());
                                StringBuilder sbTable = new StringBuilder();
                                /*sbTable.append(getClickCreateTableSql(tabName));*/
                                sbTable.append(getTableInsertStatement(s.getName(), osw));
                                osw.write(sbTable.toString());

                                StringBuilder sb = new StringBuilder();
                                startNum = (i) * baseNum;
                                /*sb.append(handleClickHouseData(tabName, startTime, endTime,startNum,baseNum));*/
                                sb.append(getDataInsertStatement(s, startTime, endTime, osw, startNum, baseNum));
                                /*logger.info("myqsql表名"+tabName + "数量开始"+startNum+"导出数量"+baseNum);*/
                                osw.write(sb.toString());
                            } catch (FileNotFoundException e) {
                                e.printStackTrace();
                                return new Result<>(MessageEnum.FAIL, MessageEnum.FAIL.lable());
                            } catch (IOException e) {
                                e.printStackTrace();
                                return new Result<>(MessageEnum.FAIL, MessageEnum.FAIL.lable());
                            }
                        }
                    }
                    if (remainder > 0) {
                        String mysqlFileName = getNewMySqlFilename(dateTimeStr, tabName, multiple);// 获得clickhouse文件名
                        //生成对应表clickHouse文件
                        File file = new File(sqlFolder + "/" + mysqlFileName);
                        try (FileOutputStream clickHouseOutputStream = new FileOutputStream(file, true); OutputStreamWriter osw = new OutputStreamWriter(clickHouseOutputStream, "UTF-8");) {
                            StringBuilder sql = new StringBuilder();
                            osw.write(sql.toString());
                            StringBuilder sbTable = new StringBuilder();
                            /*sbTable.append(getClickCreateTableSql(tabName));*/
                            sbTable.append(getTableInsertStatement(s.getName(), osw));
                            osw.write(sbTable.toString());

                            startNum = multiple * baseNum;
                            StringBuilder sb = new StringBuilder();
                            sb.append(getDataInsertStatement(s, startTime, endTime, osw, startNum, remainder));
                            /*sb.append(handleClickHouseData(tabName, startTime, endTime,startNum,remainder));*/
                            /*logger.info("myqsql表名"+tabName + "数量开始"+startNum+"导出数量"+remainder);*/
                            osw.write(sb.toString());
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                            return new Result<>(MessageEnum.FAIL, MessageEnum.FAIL.lable());
                        } catch (IOException e) {
                            e.printStackTrace();
                            return new Result<>(MessageEnum.FAIL, MessageEnum.FAIL.lable());
                        }
                    }
                } else {
                    String mysqlFileName = getNewMySqlFilename(dateTimeStr, tabName, 0L);// 获得clickhouse文件名
                    //生成对应表clickHouse文件
                    File file = new File(sqlFolder + "/" + mysqlFileName);
                    try (FileOutputStream clickHouseOutputStream = new FileOutputStream(file, true); OutputStreamWriter osw = new OutputStreamWriter(clickHouseOutputStream, "UTF-8");) {
                        StringBuilder sql = new StringBuilder();
                        osw.write(sql.toString());
                        /*logger.info("myqsql表名"+tabName + "导出数量0");*/
                        StringBuilder sbTable = new StringBuilder();
                        /*sbTable.append(getClickCreateTableSql(tabName));*/
                        sbTable.append(getTableInsertStatement(s.getName(), osw));
                        osw.write(sbTable.toString());
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                        return new Result<>(MessageEnum.FAIL, MessageEnum.FAIL.lable());
                    } catch (IOException e) {
                        e.printStackTrace();
                        return new Result<>(MessageEnum.FAIL, MessageEnum.FAIL.lable());
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                return new Result<>(MessageEnum.FAIL, "exportMysqlToSql is error:" + e.getMessage());
            }
        }
        return new Result<>(MessageEnum.SUCCESS, sqlFolder);

    }

    /**
     * 生成insert语句
     *
     * @return String generated SQL insert
     * @throws SQLException   exception
     * @throws ParseException
     */
    /**
     * 生成insert语句
     *
     * @return String generated SQL insert
     * @throws SQLException   exception
     * @throws ParseException
     */
    private String getDataInsertStatement(BackupTableConfig backup, String startTime, String endTime, OutputStreamWriter osw, Long startNum, Long limitNum)
            throws SQLException, ParseException {

        // 1:timeStamp 2：datetime 3:noTime
        String table = backup.getName();
        StringBuilder tableColumn = new StringBuilder();
        StringBuffer sqlScript = new StringBuffer();
        Integer configType = backup.getConfigType();
        if (configType == null) {
            configType = 2;
        }

        sqlScript.append("select * from ").append(table).append(" ");

        if (!StringUtils.isEmpty(startTime) && !StringUtils.isEmpty(endTime)
                && !StringUtils.isEmpty(backup.getTimeFormat())) {
            if (configType == 2) {
                if ("timeStamp".equalsIgnoreCase(backup.getTimeFormat())) {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    Date tempStartTime = sdf.parse(startTime);
                    Date tempEndTime = sdf.parse(endTime);
                    if ("stat_link_day".equals(table)) {
                        sqlScript.append(" where ").append("day").append(" >= ").append(startTime.substring(0, 10).replace("-", ""));
                        sqlScript.append(" and  ").append("day").append(" <= ").append(endTime.substring(0, 10).replace("-", ""));
                        sqlScript.append(" order by  ").append("day").append(" desc limit " + startNum + "," + limitNum + " ");
                    } else if ("log_broken_event".equals(table)
                            || "log_degradation_event".equals(table)
                            || "log_lose_de_event".equals(table)) {
                        sqlScript.append(" where ").append("last_active_ts").append(" >= ").append(tempStartTime.getTime() / 1000);
                        sqlScript.append(" and  ").append("start_ts").append(" <= ").append(tempEndTime.getTime() / 1000);
                        sqlScript.append(" order by  ").append(backup.getOrderBy()).append(" desc limit " + startNum + "," + limitNum + " ");
                    } else {
                        sqlScript.append(" where ").append(backup.getOrderBy()).append(" >= ").append(tempStartTime.getTime() / 1000);
                        sqlScript.append(" and  ").append(backup.getOrderBy()).append(" <= ").append(tempEndTime.getTime() / 1000);
                        sqlScript.append(" order by  ").append(backup.getOrderBy()).append(" desc limit " + startNum + "," + limitNum + " ");
                    }

                } else if ("datetime".equals(backup.getTimeFormat())) {
                    sqlScript.append(" where ").append(backup.getOrderBy()).append(" >= '").append(startTime);
                    sqlScript.append("' and  ").append(backup.getOrderBy()).append(" <= '").append(endTime);
                    sqlScript.append("' order by  ").append(backup.getOrderBy()).append(" desc limit " + startNum + "," + limitNum + " ");
                }
            } else {
                sqlScript.append(" order by  ").append(backup.getOrderBy()).append(" desc limit " + startNum + "," + limitNum + " ");
            }

        } else {
            sqlScript.append(" order by  ").append(backup.getOrderBy()).append(" desc limit " + startNum + "," + limitNum + " ");
        }
        StringBuffer sql = new StringBuffer();
        try {

            ResultSet rs = mysqlStatement.executeQuery(sqlScript.toString());
            rs.last();
            long rowCount = rs.getRow();
            if (rowCount <= 0) {
                return tableColumn.toString();
            }
//			tableColumn.append("\n--").append("\n-- Inserts of ").append(table).append("\n--\n\n");
//			tableColumn.append("\n/*!40000 ALTER TABLE `").append(table).append("` DISABLE KEYS */;\n");
//			tableColumn.append("\n--\n").append(MysqlUtil.SQL_START_PATTERN);
//			tableColumn.append(" table insert : ").append(table).append("\n--\n");
            tableColumn.append("INSERT INTO \"").append(table).append("\"(");
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            for (int i = 0; i < columnCount; i++) {
                tableColumn.append("\"").append(metaData.getColumnName(i + 1)).append("\", ");
            }
            tableColumn.deleteCharAt(tableColumn.length() - 1).deleteCharAt(tableColumn.length() - 1).append(") VALUES \n");
            rs.beforeFirst();
            StringBuffer tableValue = new StringBuffer();

            int row = 0;
            while (rs.next()) {

                tableValue.append("(");
                for (int i = 0; i < columnCount; i++) {

                    int columnType = metaData.getColumnType(i + 1);
                    int columnIndex = i + 1;

                    if (Objects.isNull(rs.getObject(columnIndex))) {
                        tableValue.append("").append(rs.getObject(columnIndex)).append(", ");
                    } else if (columnType == Types.INTEGER || columnType == Types.TINYINT || columnType == Types.BIGINT) {
                        tableValue.append(rs.getLong(columnIndex)).append(", ");
                    } else if (columnType == Types.BIT) {
                        tableValue.append(rs.getBoolean(columnIndex) ? 1 : 0).append(", ");
                    } else {
                        String val = rs.getString(columnIndex);
                        val = val.replace("'", "\\'");
                        tableValue.append("'").append(val).append("', ");
                    }
                }
                tableValue.deleteCharAt(tableValue.length() - 1).deleteCharAt(tableValue.length() - 1);
                if (rs.isLast()) {
                    //tableValue.append(")");
                    StringBuffer sb = new StringBuffer();
                    tableValue.append(");\n");
                    sb.append(tableColumn.toString()).append(tableValue.toString());
                    tableValue.setLength(0);
                    osw.append(sb);
                } else {
                    if (++row % 4000 == 0) {
                        StringBuffer sqlContent = new StringBuffer();
                        tableValue.append(");\n");
                        sqlContent.append(tableColumn.toString()).append(tableValue.toString());
                        logger.info(tableColumn.toString() + tableValue.toString());
                        //tableValue = new StringBuffer();
                        tableValue.setLength(0);
                        osw.append(sqlContent.toString());
                        sqlContent = null;
                    } else {
                        tableValue.append("),\n");
                    }

                }

            }
            //sql.append(";");
            StringBuffer endSql = new StringBuffer();
//			endSql.append("\n--\n").append(MysqlUtil.SQL_END_PATTERN);
//			endSql.append(" table insert : ").append(table).append("\n--\n");
//			// enable FK constraint
//			endSql.append("\n/*!40000 ALTER TABLE `").append(table).append("` ENABLE KEYS */;\n");
            osw.append(endSql);
        } catch (Exception e) {
            logger.error("GetDataInsertStatement error={},sql={}", e, sqlScript.toString());
        }
        return "";
    }

    /**
     * 生成create语句
     *
     * @param table the table concerned
     * @return String
     * @throws SQLException exception
     */
    private String getTableInsertStatement(String table, OutputStreamWriter osw) throws SQLException {
        StringBuilder sql = new StringBuilder();
        ResultSet rs = null;
        boolean addIfNotExists = true;
        String seqSqlTemplate = "\t\tDROP SEQUENCE IF EXISTS \"anpm\".\"{seqName}\" CASCADE;\n" +
                "\t\tCREATE SEQUENCE \"anpm\".\"{seqName}\"\n" +
                "\t\tINCREMENT 1\n" +
                "\t\tMINVALUE  1\n" +
                "\t\tMAXVALUE 9223372036854775807\n" +
                "\t\tSTART {startValue}\n" +
                "\t\tCACHE 1;";
        if (table != null && !table.isEmpty()) {
            /*rs = statement.executeQuery("SHOW CREATE TABLE " + "`" + table + "`;");*/
            rs = mysqlStatement.executeQuery("SELECT PG_CATALOG.PG_GET_TABLEDEF(" + "'" + table + "');");
            while (rs.next()) {
                /*String qtbl = rs.getString(1);*/
                String query = rs.getString(1);
//				sql.append("\n\n--");
//				sql.append("\n").append(MysqlUtil.SQL_START_PATTERN).append("  table dump : ").append(qtbl);
//				sql.append("\n--\n\n");
                if (addIfNotExists) {
                    query = query.trim().replace("CREATE TABLE", "CREATE TABLE IF NOT EXISTS");
                }
                sql.append(query).append(";\n\n");
            }
            String seqName = getSeqNameForTableSql(sql.toString());
            if (seqName != null) {
                String lastValue = "";
                rs = mysqlStatement.executeQuery("SELECT \"last_value\" FROM " + seqName + " ;");
                while (rs.next()) {
                    lastValue = rs.getString(1);
                }
                //
                String seqSql = seqSqlTemplate.replace("{seqName}", seqName).replace("{startValue}", lastValue);
                try {
                    osw.append(seqSql);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

//			sql.append("\n\n--");
//			sql.append("\n").append(MysqlUtil.SQL_END_PATTERN).append("  table dump : ").append(table);
//			sql.append("\n--\n\n");
        }
        try {
            osw.append(sql.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }

    private String getSeqNameForTableSql(String sql) {
        for (String line : sql.split("\\r?\\n")
        ) {
            try {
                if (line.contains("DEFAULT nextval")) {
                    return line.split("DEFAULT nextval")[1].split("'")[1];
                }
            } catch (Exception e) {
                return null;
            }
        }
        return null;
    }

    /**
     * 生成insert语句
     *
     * @return String generated SQL insert
     * @throws SQLException   exception
     * @throws ParseException
     */
    private Long getDataCountInsertStatement(BackupTableConfig backup, String startTime, String endTime)
            throws SQLException, ParseException {
        Long totalCount = 0L;
        // 1:timeStamp 2：datetime 3:noTime
        String table = backup.getName();
        StringBuilder tableColumn = new StringBuilder();
        StringBuffer sqlScript = new StringBuffer();
        Integer configType = backup.getConfigType();
        if (configType == null) {
            configType = 2;
        }

        sqlScript.append("select count(*) from ").append(table).append(" ");

        if (!StringUtils.isEmpty(startTime) && !StringUtils.isEmpty(endTime)
                && !StringUtils.isEmpty(backup.getTimeFormat())) {
            if (configType == 2) {
                if ("timeStamp".equalsIgnoreCase(backup.getTimeFormat())) {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    Date tempStartTime = sdf.parse(startTime);
                    Date tempEndTime = sdf.parse(endTime);
                    if ("stat_link_day".equals(table)) {
                        sqlScript.append(" where ").append("day").append(" >= ").append(startTime.substring(0, 10).replace("-", ""));
                        sqlScript.append(" and  ").append("day").append(" <= ").append(endTime.substring(0, 10).replace("-", ""));
                        /*sqlScript.append(" order by  ").append("day").append(" desc");*/
                    } else if ("log_broken_event".equals(table)
                            || "log_degradation_event".equals(table)
                            || "log_lose_de_event".equals(table)) {
                        sqlScript.append(" where ").append("last_active_ts").append(" >= ").append(tempStartTime.getTime() / 1000);
                        sqlScript.append(" and  ").append("start_ts").append(" <= ").append(tempEndTime.getTime() / 1000);
                        /*sqlScript.append(" order by  ").append(backup.getOrderBy()).append(" desc");*/
                    } else {
                        sqlScript.append(" where ").append(backup.getOrderBy()).append(" >= ").append(tempStartTime.getTime() / 1000);
                        sqlScript.append(" and  ").append(backup.getOrderBy()).append(" <= ").append(tempEndTime.getTime() / 1000);
                        /*sqlScript.append(" order by  ").append(backup.getOrderBy()).append(" desc");*/
                    }

                } else if ("datetime".equals(backup.getTimeFormat())) {
                    sqlScript.append(" where ").append(backup.getOrderBy()).append(" >= '").append(startTime);
                    sqlScript.append("' and  ").append(backup.getOrderBy()).append(" <= '").append(endTime);
                    sqlScript.append("' ");
                }
            } /*else {
                sqlScript.append(" order by  ").append(backup.getOrderBy()).append(" desc");
            }*/

        } /*else {
            sqlScript.append(" order by  ").append(backup.getOrderBy()).append(" desc");
        }*/
        StringBuffer sql = new StringBuffer();
        ResultSet rs = null;
        try {
            rs = mysqlStatement.executeQuery(sqlScript.toString());
            boolean flag = false;
            while (rs.next()) {
                flag = true;
                break;
            }
            if (!flag) {
                return totalCount;
            }
            ResultSetMetaData metaData = rs.getMetaData();
            int columnType = metaData.getColumnType(1);
            int columnIndex = 1;
            if (Objects.isNull(rs.getObject(columnIndex))) {
                totalCount = rs.getLong(String.valueOf(rs.getObject(columnIndex)));
            } else if (columnType == Types.INTEGER || columnType == Types.TINYINT || columnType == Types.BIGINT) {
                totalCount = rs.getLong(columnIndex);
            } else {
                String val = rs.getString(columnIndex);
                val = val.replace("'", "\\'");
                totalCount = Long.parseLong(val);
            }
        } catch (Exception e) {
            logger.error("getMySqlInsertSql error={},sql={}", e, sqlScript.toString());
            e.printStackTrace();
        } finally {
            if (null != rs) {
                rs.close();
            }
        }
        return totalCount;
    }

    //创建mysql的脚本
//    public Result<?> createMysql(String startTime, String endTime) {
//        java.sql.Connection connection = null;
//        Result<?> sqlResult = null;
//        try {
//            mysqlDatabase = findMysqlDBName(MYSQL_URL);//获得数据库名称和地址
////            String driverName = "";
////            connection = MysqlUtil.connectWithURL(MYSQL_USERNAME, MYSQL_PASSWORD, MYSQL_URL, driverName);
//            connection = mysqlDataSource.getConnection();
//            mysqlStatement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
//            // 获得导出mysql的脚本
//            sqlResult = exportMysqlToSql(startTime, endTime);
//        } catch (Exception e) {
//            logger.error("### createMysql error={}", e.getMessage());
//            return new Result<>(MessageEnum.FAIL, "createMysql is error:" + e.getMessage());
//        } finally {
//            if (null != mysqlStatement) {
//                try {
//                    mysqlStatement.close();
//                } catch (SQLException e) {
//                    e.printStackTrace();
//                }
//            }
//            if (null != connection) {
//                try {
//                    connection.close();
//                } catch (SQLException e) {
//                    e.printStackTrace();
//                }
//            }
//        }
//        return sqlResult;
//    }
    //创建clickHouse的脚本
    @SuppressWarnings("deprecation")
    public Result<?> createClickHouseSql(String startTime, String endTime, File sqlFolder, String dateTimeStr) {
        Connection connection = null;
        Result<?> sqlResult = null;
        try {
            DBConfigPo dbConfig = getClickHouseConfig();
            connection = ClickHouseUtil.connect(dbConfig.getUser(), dbConfig.getPassword(), dbConfig.getDataBase(), dbConfig.getDbUrl());
//            connection = clickDataSource.getConnection();
            clickStatement = connection.createStatement();
            // 获得导出mysql的脚本
            sqlResult = exportClickHouseToSql(startTime, endTime, sqlFolder, dateTimeStr);
        } catch (Exception e) {
            logger.error("### createClickHouseSql erro={}", e.getMessage());
            return new Result<>(MessageEnum.FAIL, "createClickHouseSql is error:" + e.getMessage());
        } finally {
            if (null != clickStatement) {
                try {
                    clickStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (null != connection) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return sqlResult;
    }


    //获得clickHouse所有的表名
    private Result<?> getClickHouseTabNameList() {
        Connection connection = null;
        try {
            DBConfigPo dbConfig = getClickHouseConfig();
            connection = ClickHouseUtil.connect(dbConfig.getUser(), dbConfig.getPassword(), dbConfig.getDataBase(), dbConfig.getDbUrl());
//            connection = clickDataSource.getConnection();
            mysqlStatement = connection.createStatement();
            ResultSet rs = mysqlStatement.executeQuery("select table as \"tableName\" from system.parts where `table` not like '%_log'  group by table order by `table`  ASC ");
            clickHouseTableNameList = new ArrayList<String>();
            while (rs.next()) {
                if (!rs.getString(1).contains(".inner_id.")) {
                    clickHouseTableNameList.add(rs.getString(1));
                }
            }
            //因为如果clickhouse的表没有数据，表名查询不出来，所以暂时把没有用的表默认加进去
//            clickHouseTableNameList.add("snmp_day");
//            clickHouseTableNameList.add("snmp_delay_loss");
//            clickHouseTableNameList.add("snmp_delay_loss_day");
//            clickHouseTableNameList.add("snmp_memory");
        } catch (Exception e) {
            logger.error("### getClickHouseTabNameList erro={}", e.getMessage());
            return new Result<>(MessageEnum.FAIL, "createMysql is error:" + e.getMessage());
        } finally {
            if (null != mysqlStatement) {
                try {
                    mysqlStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (null != connection) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return new Result<>(MessageEnum.SUCCESS);
    }

    /**
     * 从jdbcUrl中提取数据库名
     *
     * @param jdbcUrl
     * @return
     */
    private String findMysqlDBName(String jdbcUrl) {
        String dbName = "";
        if (jdbcUrl.indexOf("?") < 0) {
            int s = jdbcUrl.lastIndexOf("/") + 1;
            int e = jdbcUrl.length() - 1;
            dbName = jdbcUrl.substring(s, e);
        } else {
            String tempUrl = jdbcUrl.substring(0, jdbcUrl.lastIndexOf("?"));
            int s = tempUrl.lastIndexOf("/") + 1;
            int e = tempUrl.length();
            dbName = tempUrl.substring(s, e);
        }


        return dbName;
    }

    private DBConfigPo getClickHouseConfig() {
        DBConfigPo db = new DBConfigPo();
        String dbUrl = CLICKHOUSE_URL;
        int index = dbUrl.lastIndexOf("/");
        db.setDbUrl(dbUrl.substring(0, index));
        db.setDataBase(dbUrl.substring(index + 1, dbUrl.length()));
        db.setUser(CLICKHOUSE_USERNAME);
        db.setPassword(CLICKHOUSE_PASSWORD);
        return db;
    }

    /**
     * 导出mysql所有表的结构和数据
     *
     * @return String
     * @throws SQLException exception
     */
//    private Result<?> exportMysqlToSql(String startTime, String endTime) throws SQLException {
//        StringBuilder sql = new StringBuilder();
//        sql.append("--");
//        sql.append("\n-- Generated by admin");
//        sql.append("\n-- Date: ").append(new SimpleDateFormat("d-M-Y H:m:s").format(new Date()));
//        sql.append("\n--");
//
//        // these declarations are extracted from HeidiSQL
//        sql.append("\n\n/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;");
//        sql.append("\n/*!40101 SET NAMES utf8 */;");
//        sql.append("\n/*!50503 SET NAMES utf8mb4 */;");
//        sql.append("\n/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;");
//        sql.append("\n/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;");
//
//        List<BackupTableConfig> tables = databaseBackupDao.getBackTabConfig(); // MysqlUtil.getAllTables(database,statement);
//        for (BackupTableConfig s : tables) {
//            try {
//                String createSql = "";
//                try {
//                    createSql = getTableInsertStatement(s.getName());
//                } catch (SQLException e) {
//                    logger.error("mysql【{}】表不存在！",s.getName());
//                    continue;
//                }
//
//                sql.append(createSql);
//                if ("spring_session".equals(s.getName())||"spring_session_attributes".equals(s.getName())){
//                    continue;
//                }
//                sql.append(getDataInsertStatement(s, startTime, endTime));
//            } catch (Exception e) {
//                e.printStackTrace();
//                return new Result<>(MessageEnum.FAIL, "exportMysqlToSql is error:" + e.getMessage());
//            }
//        }
//
//        sql.append("\n/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;");
//        sql.append(
//                "\n/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;");
//        sql.append("\n/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;");
//
//        return new Result<>(MessageEnum.SUCCESS, null, sql.toString());
//    }

    /**
     * 导出clickHouse所有表的结构和数据
     *
     * @param startTime
     * @param endTime
     * @return
     */
    /*private Result<?> exportClickHouseToSql(String startTime, String endTime) {
        StringBuilder sql = new StringBuilder();
        for (String tabName : clickHouseTableNameList) {
            try {
                sql.append(getClickCreateTableSql(tabName));
                sql.append(getClickInsertSql(tabName, startTime, endTime));
            } catch (Exception e) {
                e.printStackTrace();
                return new Result<>(MessageEnum.FAIL, "exportClickHouseToSql is error:" + e.getMessage());
            }
        }
        return new Result<>(MessageEnum.SUCCESS, null, sql);
    }*/
    private Result<?> exportClickHouseToSql(String startTime, String endTime, File sqlFolder, String dateTimeStr) {
        String dirName = backupPath;
        logger.info("save backupPath =: " + dirName);
        //直接写入文件
        if (!sqlFolder.exists()) {
            boolean res = sqlFolder.mkdir();
            if (!res) {
                try {
                    throw new IOException(": Unable to create temp dir: " + sqlFolder.getAbsolutePath());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        for (String tabName : clickHouseTableNameList) {
            if (StringUtils.contains(tabName, ".")) {
                tabName = StringUtils.split(tabName, ".")[1];
            }
            try {
                Thread.sleep(1000);
                Long tableDataCunt = getTableDataCunt(tabName, startTime, endTime);
                logger.info("表名" + tabName + "数量" + tableDataCunt);
                if (tableDataCunt > 0) {
                    long baseNum = backupDataExportTime.longValue();
                    long multiple = tableDataCunt / baseNum;
                    long remainder = tableDataCunt % baseNum;
                    long startNum = 0;
                    if (multiple > 0) {
                        for (long i = 0; i < multiple; i++) {
                            /*if (handleExportClickHouseData(startTime, endTime, sqlFolder, dateTimeStr, tabName, baseNum, i))
                                return new Result<>(MessageEnum.FAIL, MessageEnum.FAIL.lable());*/
                            handleExportClickHouseDataOne(startTime, endTime, sqlFolder, dateTimeStr, tabName, baseNum, i);
                        }
                    }
                    if (remainder > 0) {
                        /*if (handleExportClickHouseDataTwo(startTime, endTime, sqlFolder, dateTimeStr, tabName, baseNum, multiple, remainder))
                            return new Result<>(MessageEnum.FAIL, MessageEnum.FAIL.lable());*/
                        handleExportClickHouseDataTwo(startTime, endTime, sqlFolder, dateTimeStr, tabName, baseNum, multiple, remainder);
                    }
                } else {
                    /*if (handleExportClickHouseDataThree(sqlFolder, dateTimeStr, tabName))
                        return new Result<>(MessageEnum.FAIL, MessageEnum.FAIL.lable());*/
                    handleExportClickHouseDataThree(sqlFolder, dateTimeStr, tabName);
                }
            } catch (Exception e) {
                e.printStackTrace();
                return new Result<>(MessageEnum.FAIL, "exportClickHouseToSql is error:" + e.getMessage());
            }
        }
        return new Result<>(MessageEnum.SUCCESS, sqlFolder);
    }

    /**
     * 计算每张表总数量
     *
     * @return
     */
    public Long getTableDataCunt(String tableName, String startTime, String endTime)
            throws SQLException, ParseException {

        if ("system_log".equals(tableName)) {
            return 0L;
        }
        StringBuilder sql = new StringBuilder();
        Long totalCount = 0L;
        StringBuffer sqlScript = new StringBuffer();
        if ("link_event_data_sublist".equals(tableName) && !StringUtils.isEmpty(startTime)
                && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select count(*) as count from ").append(tableName);
            sqlScript.append(" where ").append("toDateTime(report_end_ts)").append(" >= ")
                    .append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(report_end_ts)").append(" <= ").append("'" + endTime + "'");
        } else if ("link_run_time".equals(tableName) && !StringUtils.isEmpty(startTime)
                && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select count(*) as count from ").append(tableName).append(" ");
            sqlScript.append(" where ").append("toDateTime(report_ts)").append(" >= ").append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(report_ts)").append(" <= ").append("'" + endTime + "'");
        } else if ("link_event_data".equals(tableName) && !StringUtils.isEmpty(startTime)
                && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select count(*) as count from ").append(tableName).append(" ");
            sqlScript.append(" where ").append("toDateTime(report_end_ts)").append(" >= ")
                    .append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(report_end_ts)").append(" <= ").append("'" + endTime + "'");
        } else if ("node_event_data".equals(tableName) && !StringUtils.isEmpty(startTime)
                && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select count(*) as count from ").append(tableName).append(" ");
            sqlScript.append(" where ").append("toDateTime(report_end_ts)").append(" >= ").append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(report_end_ts)").append(" <= ").append("'" + endTime + "'");
        } else if ("node_event_data_count".equals(tableName) && !StringUtils.isEmpty(startTime)
                && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select count(*) as count from ").append(tableName).append(" ");
            sqlScript.append(" where ").append("toDateTime(report_end_ts)").append(" >= ").append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(report_end_ts)").append(" <= ").append("'" + endTime + "'");
        } else if ("task_run_time".equals(tableName) && !StringUtils.isEmpty(startTime)
                && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select count(*) as count from ").append(tableName).append(" ");
            sqlScript.append(" where ").append("toDateTime(report_ts)").append(" >= ").append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(report_ts)").append(" <= ").append("'" + endTime + "'");
        } else if ("link_run_time_data".equals(tableName) && !StringUtils.isEmpty(startTime)
                && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select count(*) as count from ").append(tableName).append(" ");
            sqlScript.append(" where ").append("toDateTime(report_ts)").append(" >= ").append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(report_ts)").append(" <= ").append("'" + endTime + "'");
        } else if (tableName.startsWith("sflow_data_") && !StringUtils.isEmpty(startTime) && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select count(*) as count from ").append(tableName).append(" ");
            sqlScript.append(" where ").append("toDateTime(report_ts)").append(" >= ").append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(report_ts)").append(" <= ").append("'" + endTime + "'");
        } else if ("flow_interface_speed_and_rate".equals(tableName) && !StringUtils.isEmpty(startTime) && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select count(*) as count from ").append(tableName).append(" ");
            sqlScript.append(" where ").append("toDateTime(report_ts)").append(" >= ").append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(report_ts)").append(" <= ").append("'" + endTime + "'");
        } else if (!StringUtils.isEmpty(startTime) && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select count(*) as count from ").append(tableName).append(" ");
            sqlScript.append(" where ").append("toDateTime(create_ts)").append(" >= ").append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(create_ts)").append(" <= ").append("'" + endTime + "'");
        } else {
            sqlScript.append("select count(*) as count from ").append(tableName).append(" ");
        }
        StringBuffer tableColumn = new StringBuffer();
        StringBuffer tableValue = new StringBuffer();
        ClickHouseResultSet rs = null;
        try {
            rs = (ClickHouseResultSet) clickStatement.executeQuery(sqlScript.toString());
            boolean flag = false;
            while (rs.next()) {
                flag = true;
                break;
            }
            if (!flag) {
                return totalCount;
            }
            ResultSetMetaData metaData = rs.getMetaData();
            int columnType = metaData.getColumnType(1);
            int columnIndex = 1;
            if (Objects.isNull(rs.getObject(columnIndex))) {
                totalCount = rs.getLong(String.valueOf(rs.getObject(columnIndex)));
            } else if (columnType == Types.INTEGER || columnType == Types.TINYINT || columnType == Types.BIGINT) {
                totalCount = rs.getLong(columnIndex);
            } else {
                String val = rs.getString(columnIndex);
                val = val.replace("'", "\\'");
                totalCount = Long.parseLong(val);
            }
        } catch (Exception e) {
            logger.error("getClickInsertSql error={},sql={}", e, sqlScript.toString());
            e.printStackTrace();
        } finally {
            if (null != rs) {
                rs.close();
            }
        }
        return totalCount;
    }

    private boolean handleExportClickHouseDataThree(File sqlFolder, String dateTimeStr, String tabName) throws SQLException {
        String clickHouseFileName = getLastNewClickHouseFilename(dateTimeStr, tabName, 0L);// 获得clickhouse文件名
        //生成对应表clickHouse文件
        File file = new File(sqlFolder + "/" + clickHouseFileName);
        try (FileOutputStream clickHouseOutputStream = new FileOutputStream(file, true); OutputStreamWriter osw = new OutputStreamWriter(clickHouseOutputStream, "UTF-8");) {
            StringBuilder sql = new StringBuilder();
            osw.write(sql.toString());
            /*logger.info("表名"+tabName + "导出数量0");*/
            StringBuilder sbTable = new StringBuilder();
            sbTable.append(getClickCreateTableSql(tabName));
            osw.write(sbTable.toString());
            return true;
        } catch (FileNotFoundException e) {
            /*e.printStackTrace();
            return true;*/
            handleExportClickHouseDataThree(sqlFolder, dateTimeStr, tabName);
        } catch (IOException e) {
            /*e.printStackTrace();
            return true;*/
            handleExportClickHouseDataThree(sqlFolder, dateTimeStr, tabName);
        }
        return false;
    }

    private boolean handleExportClickHouseDataTwo(String startTime, String endTime, File sqlFolder, String dateTimeStr, String tabName, long baseNum, long multiple, long remainder) throws SQLException {
        long startNum;
        String clickHouseFileName = getLastNewClickHouseFilename(dateTimeStr, tabName, multiple);// 获得clickhouse文件名
        //生成对应表clickHouse文件
        File file = new File(sqlFolder + "/" + clickHouseFileName);
        try (FileOutputStream clickHouseOutputStream = new FileOutputStream(file, true); OutputStreamWriter osw = new OutputStreamWriter(clickHouseOutputStream, "UTF-8");) {
            StringBuilder sql = new StringBuilder();
            osw.write(sql.toString());
            StringBuilder sbTable = new StringBuilder();
            sbTable.append(getClickCreateTableSql(tabName));
            osw.write(sbTable.toString());

            startNum = multiple * baseNum;
            StringBuilder sb = new StringBuilder();
            sb.append(handleClickHouseData(tabName, startTime, endTime, startNum, remainder));
            /*logger.info("表名"+tabName + "数量开始"+startNum+"导出数量"+remainder);*/
            osw.write(sb.toString());
            return true;
        } catch (FileNotFoundException e) {
            /*e.printStackTrace();
            return true;*/
            handleExportClickHouseDataTwo(startTime, endTime, sqlFolder, dateTimeStr, tabName, baseNum, multiple, remainder);
        } catch (IOException e) {
            /*e.printStackTrace();
            return true;*/
            handleExportClickHouseDataTwo(startTime, endTime, sqlFolder, dateTimeStr, tabName, baseNum, multiple, remainder);
        }
        return false;
    }

    private String handleClickHouseData(String tableName, String startTime, String endTime, Long startNum, Long limitNum) throws SQLException {
        if ("system_log".equals(tableName)) {
            return "";
        }
        StringBuilder sql = new StringBuilder();
        StringBuilder sqlScript = new StringBuilder();
        if ("link_event_data_sublist".equals(tableName) && !StringUtils.isEmpty(startTime)
                && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select * from ").append(tableName);
            sqlScript.append(" where ").append("toDateTime(report_end_ts)").append(" >= ")
                    .append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(report_end_ts)").append(" <= ").append("'" + endTime + "'");
            sqlScript.append(" order by  ").append("report_end_ts").append(" desc limit " + startNum + "," + limitNum + " ");
        } else if ("link_run_time".equals(tableName) && !StringUtils.isEmpty(startTime)
                && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select * from ").append(tableName).append(" ");
            sqlScript.append(" where ").append("toDateTime(report_ts)").append(" >= ").append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(report_ts)").append(" <= ").append("'" + endTime + "'");
            sqlScript.append(" order by  ").append("report_ts").append(" desc limit " + startNum + "," + limitNum + " ");
        } else if ("link_event_data".equals(tableName) && !StringUtils.isEmpty(startTime)
                && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select * from ").append(tableName).append(" ");
            sqlScript.append(" where ").append("toDateTime(report_end_ts)").append(" >= ")
                    .append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(report_end_ts)").append(" <= ").append("'" + endTime + "'");
            sqlScript.append(" order by  ").append("report_end_ts").append(" desc limit " + startNum + "," + limitNum + " ");
        } else if ("node_event_data".equals(tableName) && !StringUtils.isEmpty(startTime)
                && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select * from ").append(tableName).append(" ");
            sqlScript.append(" where ").append("toDateTime(report_end_ts)").append(" >= ").append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(report_end_ts)").append(" <= ").append("'" + endTime + "'");
            sqlScript.append(" order by  ").append("report_end_ts").append(" desc limit  " + startNum + "," + limitNum + " ");
        } else if ("node_event_data_count".equals(tableName) && !StringUtils.isEmpty(startTime)
                && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select * from ").append(tableName).append(" ");
            sqlScript.append(" where ").append("toDateTime(report_end_ts)").append(" >= ").append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(report_end_ts)").append(" <= ").append("'" + endTime + "'");
            sqlScript.append(" order by  ").append("report_end_ts").append(" desc limit  " + startNum + "," + limitNum + " ");
        } else if ("task_run_time".equals(tableName) && !StringUtils.isEmpty(startTime)
                && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select * from ").append(tableName).append(" ");
            sqlScript.append(" where ").append("toDateTime(report_ts)").append(" >= ").append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(report_ts)").append(" <= ").append("'" + endTime + "'");
            sqlScript.append(" order by  ").append("report_ts").append(" desc limit  " + startNum + "," + limitNum + " ");
        } else if ("link_run_time_data".equals(tableName) && !StringUtils.isEmpty(startTime)
                && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select * from ").append(tableName).append(" ");
            sqlScript.append(" where ").append("toDateTime(report_ts)").append(" >= ").append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(report_ts)").append(" <= ").append("'" + endTime + "'");
            sqlScript.append(" order by  ").append("report_ts").append(" desc limit  " + startNum + "," + limitNum + " ");
        } else if (tableName.startsWith("sflow_data_") && !StringUtils.isEmpty(startTime) && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select * from ").append(tableName).append(" ");
            sqlScript.append(" where ").append("toDateTime(report_ts)").append(" >= ").append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(report_ts)").append(" <= ").append("'" + endTime + "'");
            sqlScript.append(" order by  ").append("report_ts").append(" desc limit  " + startNum + "," + limitNum + " ");
        } else if ("flow_interface_speed_and_rate".equals(tableName) && !StringUtils.isEmpty(startTime) && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select * from ").append(tableName).append(" ");
            sqlScript.append(" where ").append("toDateTime(report_ts)").append(" >= ").append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(report_ts)").append(" <= ").append("'" + endTime + "'");
            sqlScript.append(" order by  ").append("report_ts").append(" desc limit  " + startNum + "," + limitNum + " ");
        } else if (!StringUtils.isEmpty(startTime) && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select * from ").append(tableName).append(" ");
            sqlScript.append(" where ").append("toDateTime(create_ts)").append(" >= ").append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(create_ts)").append(" <= ").append("'" + endTime + "'");
            sqlScript.append(" order by  ").append("create_ts").append(" desc limit " + startNum + "," + limitNum + " ");
        } else {
            sqlScript.append("select * from ").append(tableName).append(" ");
            sqlScript.append(" order by  ").append("create_ts").append(" desc limit " + startNum + "," + limitNum + " ");
        }
        StringBuffer tableColumn = new StringBuffer();
        StringBuffer tableValue = new StringBuffer();
        ClickHouseResultSet rs = null;
        try {

            rs = (ClickHouseResultSet) clickStatement.executeQuery(sqlScript.toString());
            boolean flag = false;
            while (rs.next()) {
                flag = true;
                break;
            }
            if (!flag) {
                return tableColumn.toString();
            }
//			tableColumn.append("\n--").append("\n-- Inserts of ").append(tableName).append("\n--\n\n");
//			tableColumn.append("\n/*!40000 ALTER TABLE `").append(tableName).append("` DISABLE KEYS */;\n");
//			tableColumn.append("\n--\n").append(MysqlUtil.SQL_START_PATTERN);
//			tableColumn.append(" table insert : ").append(tableName).append("\n--\n");
            tableColumn.append("INSERT INTO `").append(tableName).append("`(");
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            for (int i = 0; i < columnCount; i++) {
                tableColumn.append("`").append(metaData.getColumnName(i + 1)).append("`, ");
            }
            tableColumn.deleteCharAt(tableColumn.length() - 1).deleteCharAt(tableColumn.length() - 1).append(") VALUES \n");
            // rs.beforeFirst();
            int row = 0;
            while (rs.next()) {
                tableValue.append("(");
                for (int i = 0; i < columnCount; i++) {

                    int columnType = metaData.getColumnType(i + 1);
                    int columnIndex = i + 1;

                    if (Objects.isNull(rs.getObject(columnIndex))) {
                        tableValue.append("").append(rs.getObject(columnIndex)).append(", ");
                    } else if (columnType == Types.INTEGER || columnType == Types.TINYINT || columnType == Types.BIGINT) {
                        tableValue.append(rs.getLong(columnIndex)).append(", ");
                    } else if (columnType == Types.BIT) {
                        tableValue.append(rs.getBoolean(columnIndex) ? 1 : 0).append(", ");
                    } else {
                        String val = rs.getString(columnIndex);
                        val = val.replace("'", "\\'");
                        tableValue.append("'").append(val).append("', ");
                    }
                }
                tableValue.deleteCharAt(tableValue.length() - 1).deleteCharAt(tableValue.length() - 1);
                if (rs.isLast()) {
                    //tableValue.append(")");
                    tableValue.append(")\n;");
                    sql.append(tableColumn.toString()).append(tableValue.toString());
                    /*logger.info(tableColumn.toString() + tableValue.toString());*/
                    tableValue.setLength(0);
                } else {
                    if (++row % 4000 == 0) {
                        tableValue.append(")\n;");
                        sql.append(tableColumn.toString()).append(tableValue.toString());
                        /*logger.info(tableColumn.toString() + tableValue.toString());*/
                        tableValue.setLength(0);
                        //= new StringBuffer();
                    } else {
                        tableValue.append("),");
                    }
                }
            }

            //	sql.append(";");
//			sql.append("\n--\n").append(MysqlUtil.SQL_END_PATTERN);
//			sql.append(" table insert : ").append(tableName).append("\n--\n");
//			sql.append("\n/*!40000 ALTER TABLE `").append(tableName).append("` ENABLE KEYS */;\n");
        } catch (Exception e) {
            logger.error("getClickInsertSql error={},sql={}", e, sqlScript.toString());
            e.printStackTrace();
        } finally {
            rs.close();
        }
        return sql.toString();
    }

    private boolean handleExportClickHouseDataOne(String startTime, String endTime, File sqlFolder, String dateTimeStr, String tabName, long baseNum, long i) throws SQLException {
        long startNum;
        String clickHouseFileName = getLastNewClickHouseFilename(dateTimeStr, tabName, i);// 获得clickhouse文件名
        //生成对应表clickHouse文件
        File file = new File(sqlFolder + "/" + clickHouseFileName);
        try (FileOutputStream clickHouseOutputStream = new FileOutputStream(file, true); OutputStreamWriter osw = new OutputStreamWriter(clickHouseOutputStream, "UTF-8");) {
            StringBuilder sql = new StringBuilder();
            osw.write(sql.toString());
            StringBuilder sbTable = new StringBuilder();
            sbTable.append(getClickCreateTableSql(tabName));
            osw.write(sbTable.toString());

            StringBuilder sb = new StringBuilder();
            startNum = (i) * baseNum;
            sb.append(handleClickHouseData(tabName, startTime, endTime, startNum, baseNum));
            /*logger.info("表名"+tabName + "数量开始"+startNum+"导出数量"+baseNum);*/
            osw.write(sb.toString());
            return true;
        } catch (FileNotFoundException e) {
            /*e.printStackTrace();*/
            handleExportClickHouseDataOne(startTime, endTime, sqlFolder, dateTimeStr, tabName, baseNum, i);
            /*return true;*/
        } catch (IOException e) {
            handleExportClickHouseDataOne(startTime, endTime, sqlFolder, dateTimeStr, tabName, baseNum, i);
            /*e.printStackTrace();
            return true;*/
        }
        return false;
    }

    private Object getClickCreateTableSql(String tabName) throws SQLException {
        StringBuilder sql = new StringBuilder();
        ResultSet rs = null;
        boolean addIfNotExists = true;
        if (tabName != null && !tabName.isEmpty()) {
            rs = clickStatement.executeQuery("SHOW CREATE TABLE " + tabName);
            while (rs.next()) {
                String query = rs.getString(1);
                if (addIfNotExists) {
                    query = query.trim().replace("CREATE TABLE", "CREATE TABLE IF NOT EXISTS");
                }
                String s = StringUtils.substring(query, StringUtils.lastIndexOf(query, "EXISTS") + "EXISTS".length(), StringUtils.indexOf(query, "("));
                String createTableSql = StringUtils.replace(query, s, " " + tabName);

                sql.append(createTableSql).append(";\n\n");
            }

        }
        rs.close();
        return sql.toString();
    }

    /**
     * 生成clickHouse的insert语句
     *
     * @param tableName
     * @param startTime
     * @param endTime
     * @return
     * @throws SQLException
     * @throws ParseException
     */
    private String getClickInsertSql(String tableName, String startTime, String endTime)
            throws SQLException, ParseException {
        StringBuilder sql = new StringBuilder();
        StringBuffer sqlScript = new StringBuffer();


        int limit = 100000;
        if ("link_event_data_sublist".equals(tableName) && !StringUtils.isEmpty(startTime)
                && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select * from ").append(tableName);
//					.append(" leds LEFT JOIN link_event_data AS led ON leds.event_data_id = led.id");
            sqlScript.append(" where ").append("toDateTime(report_end_ts)").append(" >= ")
                    .append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(report_end_ts)").append(" <= ").append("'" + endTime + "'");
            sqlScript.append(" order by  ").append("report_end_ts").append(" desc limit " + limit);
        } else if ("link_run_time".equals(tableName) && !StringUtils.isEmpty(startTime)
                && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select * from ").append(tableName).append(" ");
            sqlScript.append(" where ").append("toDateTime(report_ts)").append(" >= ").append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(report_ts)").append(" <= ").append("'" + endTime + "'");
            sqlScript.append(" order by  ").append("report_ts").append(" desc limit  " + limit);
        } else if ("link_event_data".equals(tableName) && !StringUtils.isEmpty(startTime)
                && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select * from ").append(tableName).append(" ");
            sqlScript.append(" where ").append("toDateTime(report_end_ts)").append(" >= ")
                    .append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(report_end_ts)").append(" <= ").append("'" + endTime + "'");
            sqlScript.append(" order by  ").append("report_end_ts").append(" desc limit  " + limit);
        } else if (!StringUtils.isEmpty(startTime) && !StringUtils.isEmpty(endTime)) {
            sqlScript.append("select * from ").append(tableName).append(" ");
            sqlScript.append(" where ").append("toDateTime(create_ts)").append(" >= ").append("'" + startTime + "'");
            sqlScript.append(" and  ").append("toDateTime(create_ts)").append(" <= ").append("'" + endTime + "'");
            sqlScript.append(" order by  ").append("create_ts").append(" desc limit  " + limit);
        } else {
            sqlScript.append("select * from ").append(tableName).append(" ");
            sqlScript.append(" order by  ").append("create_ts").append(" desc limit  " + limit);
        }
        StringBuffer tableColumn = new StringBuffer();
        StringBuffer tableValue = new StringBuffer();
        ClickHouseResultSet rs = null;
        try {

            rs = (ClickHouseResultSet) clickStatement.executeQuery(sqlScript.toString());
            boolean flag = false;
            while (rs.next()) {
                flag = true;
                break;
            }
            if (!flag) {
                return tableColumn.toString();
            }
            tableColumn.append("INSERT INTO `").append(tableName).append("`(");
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            for (int i = 0; i < columnCount; i++) {
                tableColumn.append("`").append(metaData.getColumnName(i + 1)).append("`, ");
            }
            tableColumn.deleteCharAt(tableColumn.length() - 1).deleteCharAt(tableColumn.length() - 1).append(") VALUES \n");
            // rs.beforeFirst();
            int row = 0;
            while (rs.next()) {
                tableValue.append("(");
                for (int i = 0; i < columnCount; i++) {

                    int columnType = metaData.getColumnType(i + 1);
                    int columnIndex = i + 1;

                    if (Objects.isNull(rs.getObject(columnIndex))) {
                        tableValue.append("").append(rs.getObject(columnIndex)).append(", ");
                    } else if (columnType == Types.INTEGER || columnType == Types.TINYINT || columnType == Types.BIGINT) {
                        tableValue.append(rs.getLong(columnIndex)).append(", ");
                    } else if (columnType == Types.BIT) {
                        tableValue.append(rs.getBoolean(columnIndex) ? 1 : 0).append(", ");
                    } else {
                        String val = rs.getString(columnIndex);
                        val = val.replace("'", "\\'");
                        tableValue.append("'").append(val).append("', ");
                    }
                }
                tableValue.deleteCharAt(tableValue.length() - 1).deleteCharAt(tableValue.length() - 1);
                if (rs.isLast()) {
                    //tableValue.append(")");
                    tableValue.append(")\n;");
                    sql.append(tableColumn.toString()).append(tableValue.toString());
                    logger.info(tableColumn.toString() + tableValue.toString());
                    tableValue.setLength(0);
                } else {
                    if (++row % 4000 == 0) {
                        tableValue.append(")\n;");
                        sql.append(tableColumn.toString()).append(tableValue.toString());
                        logger.info(tableColumn.toString() + tableValue.toString());
                        tableValue.setLength(0);
                        //= new StringBuffer();
                    } else {
                        tableValue.append("),");
                    }
                }
            }

        } catch (Exception e) {
            logger.error("getClickInsertSql error={},sql={}", e, sqlScript.toString());
            e.printStackTrace();
        } finally {
            rs.close();
        }
        String finalSql = sql.toString();
        return finalSql;
    }


    /**
     * 生成create语句
     *
     * @param table the table concerned
     * @return String
     * @throws SQLException exception
     */
    private String getTableInsertStatement(String table) throws SQLException {
        StringBuilder sql = new StringBuilder();
        ResultSet rs = null;
        boolean addIfNotExists = true;
        if (table != null && !table.isEmpty()) {
            rs = mysqlStatement.executeQuery("SHOW CREATE TABLE " + "`" + table + "`;");
            while (rs.next()) {
                String qtbl = rs.getString(1);
                String query = rs.getString(2);
                sql.append("\n\n--");
                sql.append("\n").append(MysqlUtil.SQL_START_PATTERN).append("  table dump : ").append(qtbl);
                sql.append("\n--\n\n");
                if (addIfNotExists) {
                    query = query.trim().replace("CREATE TABLE", "CREATE TABLE IF NOT EXISTS");
                }
                sql.append(query).append(";\n\n");
            }

            sql.append("\n\n--");
            sql.append("\n").append(MysqlUtil.SQL_END_PATTERN).append("  table dump : ").append(table);
            sql.append("\n--\n\n");
        }

        return sql.toString();
    }

    /**
     * 生成insert语句
     *
     * @return String generated SQL insert
     * @throws SQLException   exception
     * @throws ParseException
     */
//    private String getDataInsertStatement(BackupTableConfig backup, String startTime, String endTime)
//            throws SQLException, ParseException {
//
//        // 1:timeStamp 2：datetime 3:noTime
//        String table = backup.getName();
//        StringBuilder sql = new StringBuilder();
//        StringBuffer sqlScript = new StringBuffer();
//        sqlScript.append("select * from ").append(table).append(" ");
//
//        if (!StringUtils.isEmpty(startTime) && !StringUtils.isEmpty(endTime)
//                && !StringUtils.isEmpty(backup.getTimeFormat())) {
//            if ("timeStamp".equalsIgnoreCase(backup.getTimeFormat())) {
//                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//                Date tempStartTime = sdf.parse(startTime);
//                Date tempEndTime = sdf.parse(endTime);
//
//                sqlScript.append(" where ").append(backup.getOrderBy()).append(" >= ").append(tempStartTime.getTime());
//                sqlScript.append(" and  ").append(backup.getOrderBy()).append(" <= ").append(tempEndTime.getTime());
//                sqlScript.append(" order by  ").append(backup.getOrderBy()).append(" desc limit 100000");
//
//            } else if ("datetime".equals(backup.getTimeFormat())) {
//                sqlScript.append(" where ").append(backup.getOrderBy()).append(" >= '").append(startTime);
//                sqlScript.append("' and  ").append(backup.getOrderBy()).append(" <= '").append(endTime);
//                sqlScript.append("' order by  ").append(backup.getOrderBy()).append(" desc limit 100000");
//            }
//        } else {
//            sqlScript.append(" order by  ").append(backup.getOrderBy()).append(" desc limit 100000");
//        }
//
//        try {
//
//            ResultSet rs = mysqlStatement.executeQuery(sqlScript.toString());
//            rs.last();
//            long rowCount = rs.getRow();
//            if (rowCount <= 0) {
//                return sql.toString();
//            }
//            sql.append("\n--").append("\n-- Inserts of ").append(table).append("\n--\n\n");
//            sql.append("\n/*!40000 ALTER TABLE `").append(table).append("` DISABLE KEYS */;\n");
//            sql.append("\n--\n").append(MysqlUtil.SQL_START_PATTERN);
//            sql.append(" table insert : ").append(table).append("\n--\n");
//            sql.append("INSERT INTO `").append(table).append("`(");
//            ResultSetMetaData metaData = rs.getMetaData();
//            int columnCount = metaData.getColumnCount();
//            for (int i = 0; i < columnCount; i++) {
//                sql.append("`").append(metaData.getColumnName(i + 1)).append("`, ");
//            }
//            sql.deleteCharAt(sql.length() - 1).deleteCharAt(sql.length() - 1).append(") VALUES \n");
//            rs.beforeFirst();
//            while (rs.next()) {
//                sql.append("(");
//                for (int i = 0; i < columnCount; i++) {
//
//                    int columnType = metaData.getColumnType(i + 1);
//                    int columnIndex = i + 1;
//
//                    if (Objects.isNull(rs.getObject(columnIndex))) {
//                        sql.append("").append(rs.getObject(columnIndex)).append(", ");
//                    } else if (columnType == Types.INTEGER || columnType == Types.TINYINT || columnType == Types.BIT) {
//                        sql.append(rs.getLong(columnIndex)).append(", ");
//                    } else {
//                        String val = rs.getString(columnIndex);
//                        val = val.replace("'", "\\'");
//                        sql.append("'").append(val).append("', ");
//                    }
//                }
//
//                sql.deleteCharAt(sql.length() - 1).deleteCharAt(sql.length() - 1);
//                if (rs.isLast()) {
//                    sql.append(")");
//                } else {
//                    sql.append("),\n");
//                }
//            }
//            sql.append(";");
//            sql.append("\n--\n").append(MysqlUtil.SQL_END_PATTERN);
//            sql.append(" table insert : ").append(table).append("\n--\n");
//            // enable FK constraint
//            sql.append("\n/*!40000 ALTER TABLE `").append(table).append("` ENABLE KEYS */;\n");
//        } catch (Exception e) {
//            logger.error("GetDataInsertStatement error={},sql={}", e, sqlScript.toString());
//        }
//        return sql.toString();
//    }

    /**
     * 清理临时文件
     *
     * @param preserveZipFile bool
     */
    public void clearTempFiles(boolean preserveZipFile, String backupPath) {

        deleteDir(new File(backupPath));

        // delete the temp sql file
        File sqlFile = new File(backupPath + "/sql/" + mysqlFileName);
        if (sqlFile.exists()) {
            boolean res = sqlFile.delete();
            logger.info(": " + sqlFile.getAbsolutePath() + " deleted successfully? " + (res ? " TRUE " : " FALSE "));
        } else {
            logger.info(": " + sqlFile.getAbsolutePath() + " DOES NOT EXIST while clearing Temp Files");
        }

        File sqlFolder = new File(backupPath + "/sql");
        if (sqlFolder.exists()) {
            boolean res = sqlFolder.delete();
            logger.info(": " + sqlFolder.getAbsolutePath() + " deleted successfully? " + (res ? " TRUE " : " FALSE "));
        } else {
            logger.info(": " + sqlFolder.getAbsolutePath() + " DOES NOT EXIST while clearing Temp Files");
        }

        if (!preserveZipFile) {

            // delete the zipFile
            File zipFile = new File(zipFileName);
            if (zipFile.exists()) {
                boolean res = zipFile.delete();
                logger.info(
                        ": " + zipFile.getAbsolutePath() + " deleted successfully? " + (res ? " TRUE " : " FALSE "));
            } else {
                logger.info(": " + zipFile.getAbsolutePath() + " DOES NOT EXIST while clearing Temp Files");
            }

            // delete the temp folder
            File folder = new File(backupPath);
            if (folder.exists()) {
                boolean res = folder.delete();
                logger.info(": " + folder.getAbsolutePath() + " deleted successfully? " + (res ? " TRUE " : " FALSE "));

            } else {
                logger.info(": " + folder.getAbsolutePath() + " DOES NOT EXIST while clearing Temp Files");
            }
        }

        logger.info("generated temp files cleared successfully");
    }

    /**
     * 生成文件名 sql file name.
     *
     * @return String
     */
    public String getMySqlFilename(String dateTimeStr) {
        return dateTimeStr + "_" + mysqlDatabase + "_database_mysql.sql";
    }

    public String getNewMySqlFilename(String dateTimeStr, String tableName, Long index) {
        return dateTimeStr + "_" + mysqlDatabase + "_" + tableName + "_" + index + "_database_opengauss.sql";
    }

    public String getClickHouseFilename(String dateTimeStr) {
        DBConfigPo dbConfig = getClickHouseConfig();
        return dateTimeStr + "_" + dbConfig.getDataBase() + "_database_click.sql";
    }

    public String getLastNewClickHouseFilename(String dateTimeStr, String tableName, Long index) {
        DBConfigPo dbConfig = getClickHouseConfig();
        return dateTimeStr + "_" + dbConfig.getDataBase() + "_" + tableName + "_" + index + "_database_click.sql";
    }

    private static boolean deleteDir(File dir) {
        if (dir.isDirectory()) {
            String[] children = dir.list();
            //递归删除目录中的子目录下
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
        }
        // 目录此时为空，可以删除
        return dir.delete();
    }

}
