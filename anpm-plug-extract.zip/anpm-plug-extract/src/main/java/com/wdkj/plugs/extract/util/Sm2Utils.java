package com.wdkj.plugs.extract.util;

import cn.hutool.core.util.HexUtil;
import cn.hutool.crypto.BCUtil;
import cn.hutool.crypto.SecureUtil;
import cn.hutool.crypto.SmUtil;
import cn.hutool.crypto.asymmetric.KeyType;
import cn.hutool.crypto.asymmetric.SM2;
import org.apache.commons.lang3.StringUtils;
import org.bouncycastle.crypto.engines.SM2Engine;
import org.bouncycastle.jcajce.provider.asymmetric.ec.BCECPublicKey;

import java.nio.charset.Charset;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;

/**
 * Sm2国密加解密
 */
public class Sm2Utils {

//	public final static String privateKey = "00e7b2c4ee0fde539b5edd401032e1df70885c5f2831211caca3cea3549d59be32";
//	public final static String publicKey = "047d6d03c6dc9d812f0f5178a0e037adf834d968ebefcbf97a97c24233927130fde6398b8436c18f38210b0cbf8313f081dbbe764d26807549faa2536c27f9f4ef";


	/**
	 * 根据公钥和私钥进行加密
	 * @param text
	 * @param privateKey
	 * @param publicKey
	 * @return
	 */
	public static String encryptHexKey(String text,String privateKey, String publicKey) {
		String encryptStr=null;
		try {
			if(StringUtils.isEmpty(text)|| StringUtils.isEmpty(privateKey)|| StringUtils.isEmpty(publicKey)) {
				return null;
			}
			SM2 sm2 = SmUtil.sm2(privateKey, publicKey);
			encryptStr = sm2.encryptHex(new String(text), Charset.forName("utf-8"), KeyType.PublicKey);
			encryptStr = encryptStr.startsWith("04") ? encryptStr.substring(2) : encryptStr;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return encryptStr;
	}
	
	/**
	 * 根据公钥和私钥进行解密
	 * @param encryptStr
	 * @param privateKey web加密private key
	 * @param publicKey web加密public key
	 * @return
	 */
	public static String decryptKey(String encryptStr,String privateKey, String publicKey) {
		String decryptStr=null;
		try {
			 SM2 sm2 = SmUtil.sm2(privateKey, publicKey);
			 decryptStr = sm2.decryptStr("04"+encryptStr, KeyType.PrivateKey);
		} catch (Exception e) {
			System.out.println("sm2解密失败,"+e.getMessage());
		}
		return decryptStr;
	}



	
	
	//服务端生成公钥和私钥方法2
	public static void  getPublicKeyAndPrivateKey2() {
		KeyPair pair = SecureUtil.generateKeyPair("SM2");
        PrivateKey aPrivate = pair.getPrivate();
        byte[] privateKeyByte = aPrivate.getEncoded();//解密时需要用到
        PublicKey aPublic = pair.getPublic();
        //将q值提取出来并且转成16进制
        String publicKey = HexUtil.encodeHexStr(((BCECPublicKey)aPublic).getQ().getEncoded(false));
		System.out.println("privateKey：" + HexUtil.encodeHexStr(privateKeyByte));
		System.out.println("publicKey：" + publicKey);  
	}
	
	/**
	 * 服务端生成公钥和私钥(推荐)
	 */
	public static void  getPublicKeyAndPrivateKey() {
		SM2 sm2 = SmUtil.sm2();
        sm2.setMode(SM2Engine.Mode.C1C3C2);// sm2的加解密时有两种方式即 C1C2C3、 C1C3C2，
        String privateKey = HexUtil.encodeHexStr(BCUtil.encodeECPrivateKey(sm2.getPrivateKey())); // 生成私钥
        String publicKey = HexUtil.encodeHexStr(((BCECPublicKey) sm2.getPublicKey()).getQ().getEncoded(false)); // 生成公钥
        System.out.println("privateKey：" + privateKey);  
		System.out.println("publicKey：" + publicKey);  
	}


	
	public static void main(String[] args) {
//		getPublicKeyAndPrivateKey();//获取密匙对
		
//		//根据前端的密文进行sm2解密
//		String privateKey1="069eaca522d39e7b5f4f6bef7164a241e3e624288d69efec0a486fb44bcf274b";
//		String publicKey1="047fc238aaaf1ef1e0e334ca4244e3d9fc41f40dcd515aa1dd23f2365999d835caa810481aba795b99462c630a3ed8567d960a4fb735041b2bda1ff3c361273519";
//		String encryptStr="0447ce84ac1cf93c52ec7016c4e93b8a1345a2530f35509a01861882191d63bb009cca13e3ac198637c7a2ed29d181c66e94459fabae124643884172e3eebca1ec7d16a14e1c676c2cf4ffb365b43dd9bdd1f77700715549e2d578495fef88d9bbef197ea779299405e171c44b9759c944887d2434811ed37bbd09b91ed109ff0a7bec6ac01abafaaf844489a8e3eabed1d50465547e9dfc88d5c2243a6da546cc0c42242fea3829e1d8bbf18e317614ab5623";
//		System.out.println("sm2解密："+decryptKey(encryptStr,privateKey1,publicKey1));
//
		//根据密码和公钥进行加密,前端根据私钥（publicKey2）进行解密
		String pass="349402571@qq.com";
		String privateKey2="7e667c234cd50ea243989090d15d8ac4c4fa312d8087a3efb0e9157096feb18b";
		String publicKey2="046780e58f326c0dccfb750a50e6218c8505bea3fa18b51dfa6015d8bacec641e561f24dac8b0255f5262d3e273e303e4c11999feb8351ffc2f603b78c69691578";
		String ss=encryptHexKey(pass,privateKey2,publicKey2);
		System.out.println("sm2加密："+ss);
		System.out.println("sm2解密："+decryptKey("4dc7766668ee1e130ef90253f1953fb2286cd21bf92a38ca85ee85c5b9af6e0e14cd1fcc6337797c203d1fb7b67bed4b5b2cd942af2e9e5d487048a3d776bdea097a78f9dd76debfd4de1652324c1f483fc34acd82cde56536d02413a67133e19c79b93f7b3710b42cd2c5221950c10b3d1d6bb0",privateKey2,publicKey2));




		//后端 pubserver
	}
}
