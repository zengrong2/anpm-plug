package com.wdkj.plugs.extract.service.impl;

import com.wdkj.plugs.core.model.to.Result;
import com.wdkj.plugs.extract.dao.mysql.IIndexSyncDao;
import com.wdkj.plugs.extract.dao.mysql.ISysAuditLogBackupDao;
import com.wdkj.plugs.extract.service.ISysAuditLogBackupService;
import com.wdkj.plugs.extract.util.MysqlUtil;
import com.wdkj.plugs.model.po.BackupTableConfig;
import com.wdkj.plugs.model.po.DBConfigPo;
import com.wdkj.plugs.model.vo.SysAuditLogBackupDefaultValue;
import com.wdkj.plugs.utils.enu.MessageEnum;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.zeroturnaround.zip.ZipUtil;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.*;

/**
 * @ClassName SysAuditLogBackupServiceImpl
 * @Description TODO
 * @Author lan
 * @Date 2022/04/06
 */
@Service
public class SysAuditLogBackupServiceImpl implements ISysAuditLogBackupService {

    private static Logger logger = LoggerFactory.getLogger(SysAuditLogBackupServiceImpl.class);

    @Autowired
    private ISysAuditLogBackupDao sysAuditLogBackupDao;
    @Autowired
    private IIndexSyncDao indexSyncDao;

    private static final String SYSTEM_CONFIG_AUDIT_ONE = "SYSTEM_CONFIG_AUDIT_ONE";
    private static final String TABLE_NAME = "sys_audit_log";

    @Value("${spring.datasource.gauss.jdbcUrl}")
    public String GAUSS_URL = null;
    @Value("${spring.datasource.gauss.username}")
    public String GAUSS_USERNAME = null;
    @Value("${spring.datasource.gauss.password}")
    public String GAUSS_PASSWORD = null;
    @Value("${spring.datasource.click.jdbcUrl}")
    public String CLICKHOUSE_URL = null;
    @Value("${spring.datasource.click.username}")
    public String CLICKHOUSE_USERNAME = null;
    @Value("${spring.datasource.click.password}")
    public String CLICKHOUSE_PASSWORD = null;
    @Value("${anpm.backup-path:/web/backup-path}")
    public String BACK_SERVER_DESTDIR = null;

    @Resource(name = "gaussDataSource")
    private DataSource gaussDataSource;

    private Statement mysqlStatement;
    private String mysqlDatabase;
    private String mysqlFileName = "";
    private String zipFileName = "";
    private File generatedZipFile;
    @Override
    public List<SysAuditLogBackupDefaultValue> getBackupDefaultValue() {
        return sysAuditLogBackupDao.getBackupDefaultValue();
    }

    @Override
    public void dataSourceBackup(LocalDateTime queryEndTime, Boolean isFirstExtract, Map<String, String> map) {
        FileOutputStream mysqlOutputStream = null;
        //判断
        try {
            // 获取自动备份默认值
            Long backCycle = Long.parseLong(map.get(SYSTEM_CONFIG_AUDIT_ONE));
            String backServerDestdir = BACK_SERVER_DESTDIR;
            if (backServerDestdir.endsWith("/")){
                backServerDestdir = backServerDestdir + "logBackUp";
            } else {
                backServerDestdir = backServerDestdir + "/logBackUp";
            }
            String backupPath = backServerDestdir;
            // 处理查询开始和结束时间
            DateTimeFormatter sdf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            String startTime = queryEndTime.minusDays(backCycle).format(sdf);
            String endTime = queryEndTime.format(sdf);
            // 创建mysql的脚本
            String mysqlSql = "";
            Result<?> mysqlResult = createMysql(startTime, endTime);
            if (mysqlResult.getCode() != MessageEnum.SUCCESS.code()) {
                logger.error(mysqlResult.getMsg());
            }
            mysqlSql = mysqlResult.getInfo().toString();
            String dirName = backupPath;
            logger.info("save backupPath =: " + dirName);
            File file = new File(dirName);
            if (!file.exists()) {
                boolean res = file.mkdirs();
                if (!res) {
                    logger.info("Unable to create temp dir: " + file.getAbsolutePath());
                    throw new IOException("Unable to create temp dir: " + file.getAbsolutePath());
                }
            }
            // write the sql file out
            String dateTimeStr = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
            File sqlFolder = new File(dirName + "/" + dateTimeStr);
            if (!sqlFolder.exists()) {
                boolean res = sqlFolder.mkdir();
                if (!res) {
                    throw new IOException(": Unable to create temp dir: " + file.getAbsolutePath());
                }
            }
            // 生成mysql脚本文件
            mysqlFileName = getMySqlFilename(dateTimeStr);//获得mysql文件名
            mysqlOutputStream = new FileOutputStream(sqlFolder + "/" + mysqlFileName);
            mysqlOutputStream.write(mysqlSql.getBytes());
            mysqlOutputStream.close();
            // zip the file
            zipFileName = dirName + "/" + dateTimeStr + "_anmp.zip";
            generatedZipFile = new File(zipFileName);
            ZipUtil.pack(sqlFolder, generatedZipFile);
            // clear the generated temp files
            clearTempFiles(true,dirName + "/" + dateTimeStr);
            Map<String, String> paramMap = new HashMap<>(2);
            DateTimeFormatter sd = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            paramMap.put("table", TABLE_NAME);
            paramMap.put("syncTime", queryEndTime.format(sd));
            // 保存或更新抽取时间
            if (isFirstExtract) {
                indexSyncDao.saveSyncDate(paramMap);
            } else {
                indexSyncDao.updateSyncDate(paramMap);
            }
            //  备份成功后写入一条日志到日志表
            Map<String,Object> param = new HashMap<>(12);
            param.put("user_id",2);
            param.put("user_name","sys_gly");
            param.put("description","审计日志备份");
            param.put("org_id",1);
            param.put("create_date",queryEndTime);
            param.put("event_type","审计日志备份");
            param.put("operate_type","日志备份");
            param.put("module","审计日志");
            sysAuditLogBackupDao.saveSysOperationLog(param);
        } catch (Exception e) {
            logger.error("#备份错误## Export erro={}", e);
        } finally {
            if (null != mysqlOutputStream) {
                try {
                    mysqlOutputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    //创建mysql的脚本
    public Result<?> createMysql(String startTime, String endTime) {
        Connection connection = null;
        Result<?> sqlResult = null;
        try {
            mysqlDatabase = findMysqlDBName(GAUSS_URL);//获得数据库名称和地址
            connection = gaussDataSource.getConnection();
            mysqlStatement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            // 获得导出mysql的脚本
            sqlResult = exportMysqlToSql(startTime, endTime);
        } catch (Exception e) {
            logger.error("### createMysql error={}", e.getMessage());
            return new Result<>(MessageEnum.FAIL, "createMysql is error");
        } finally {
            if (null != mysqlStatement) {
                try {
                    mysqlStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (null != connection) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return sqlResult;
    }


    /**
     * 从jdbcUrl中提取数据库名
     *
     * @param jdbcUrl
     * @return
     */
    private String findMysqlDBName(String jdbcUrl) {
        String dbName = "";
        if (jdbcUrl.indexOf("?") < 0) {
            int s = jdbcUrl.lastIndexOf("/") + 1;
            int e = jdbcUrl.length() - 1;
            dbName = jdbcUrl.substring(s, e);
        } else {
            String tempUrl = jdbcUrl.substring(0, jdbcUrl.lastIndexOf("?"));
            int s = tempUrl.lastIndexOf("/") + 1;
            int e = tempUrl.length();
            dbName = tempUrl.substring(s, e);
        }


        return dbName;
    }

    private DBConfigPo getClickHouseConfig() {
        DBConfigPo db = new DBConfigPo();
        String dbUrl = CLICKHOUSE_URL;
        int index = dbUrl.lastIndexOf("/");
        db.setDbUrl(dbUrl.substring(0, index));
        db.setDataBase(dbUrl.substring(index + 1, dbUrl.length()));
        db.setUser(CLICKHOUSE_USERNAME);
        db.setPassword(CLICKHOUSE_PASSWORD);
        return db;
    }

    /**
     * 导出mysql所有表的结构和数据
     *
     * @return String
     * @throws SQLException exception
     */
    private Result<?> exportMysqlToSql(String startTime, String endTime) throws SQLException {
        StringBuilder sql = new StringBuilder();
            try {
//                try {
//                    createSql = getTableInsertStatement(TABLE_NAME);
//                } catch (SQLException e) {
//                	e.printStackTrace();
//                    logger.error("mysql【{}】表不存在！",TABLE_NAME);
//                }
                sql.append(getDataInsertStatement(startTime, endTime));
            } catch (Exception e) {
                e.printStackTrace();
                return new Result<>(MessageEnum.FAIL, "exportMysqlToSql is error="+e.getMessage() );
            }
        return new Result<>(MessageEnum.SUCCESS, null, sql.toString());
    }


    /**
     * 生成create语句
     *
     * @param table the table concerned
     * @return String
     * @throws SQLException exception
     */
    private String getTableInsertStatement(String table) throws SQLException {
        StringBuilder sql = new StringBuilder();
        ResultSet rs = null;
        boolean addIfNotExists = true;
        if (table != null && !table.isEmpty()) {
            rs = mysqlStatement.executeQuery("select showcreatetable('public','sys_audit_log')");
            while (rs.next()) {
                String qtbl = rs.getString(1);
                sql.append("\n\n--");
                sql.append("\n").append(MysqlUtil.SQL_START_PATTERN).append("  table dump : ").append(qtbl);
                sql.append("\n--\n\n");
            }

            sql.append("\n\n--");
            sql.append("\n").append(MysqlUtil.SQL_END_PATTERN).append("  table dump : ").append(table);
            sql.append("\n--\n\n");
        }

        return sql.toString();
    }

    /**
     * 生成insert语句
     *
     * @return String generated SQL insert
     * @throws SQLException   exception
     * @throws ParseException
     */
    private String getDataInsertStatement(String startTime, String endTime)
            throws SQLException, ParseException {

        StringBuilder sql = new StringBuilder();
        StringBuffer sqlScript = new StringBuffer();
        sqlScript.append("select * from ").append(TABLE_NAME).append(" ");

        if (!StringUtils.isEmpty(startTime) && !StringUtils.isEmpty(endTime)) {
//            sqlScript.append(" where '").append(startTime).append("' <= DATE_FORMAT(create_date, '%Y-%m-%d')");
//            sqlScript.append(" and  DATE_FORMAT(create_date, '%Y-%m-%d') < '").append(endTime);
            sqlScript.append(" where '").append(startTime).append("' <= create_date");
            sqlScript.append(" and  create_date < '").append(endTime);
            sqlScript.append("' order by  create_date");
        } else {
            sqlScript.append(" order by create_date");
        }
        try {
            ResultSet rs = mysqlStatement.executeQuery(sqlScript.toString());
            rs.last();
            long rowCount = rs.getRow();
            if (rowCount <= 0) {
                return sql.toString();
            }
            sql.append("\n--").append("\n-- Inserts of ").append(TABLE_NAME).append("\n--\n\n");
            sql.append("\n/*!40000 ALTER TABLE ").append(TABLE_NAME).append(" DISABLE KEYS */;\n");
            sql.append("\n--\n").append(MysqlUtil.SQL_START_PATTERN);
            sql.append(" table insert : ").append(TABLE_NAME).append("\n--\n");
            sql.append("INSERT INTO ").append(TABLE_NAME).append("(");
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            for (int i = 0; i < columnCount; i++) {
                sql.append("").append(metaData.getColumnName(i + 1)).append(", ");
            }
            sql.deleteCharAt(sql.length() - 1).deleteCharAt(sql.length() - 1).append(") VALUES \n");
            rs.beforeFirst();
            while (rs.next()) {
                sql.append("(");
                for (int i = 0; i < columnCount; i++) {

                    int columnType = metaData.getColumnType(i + 1);
                    int columnIndex = i + 1;

                    if (Objects.isNull(rs.getObject(columnIndex))) {
                        sql.append("").append(rs.getObject(columnIndex)).append(", ");
                    } else if (columnType == Types.INTEGER || columnType == Types.TINYINT || columnType == Types.BIT) {
                        sql.append(rs.getLong(columnIndex)).append(", ");
                    } else {
                        String val = rs.getString(columnIndex);
                        val = val.replace("'", "\\'");
                        sql.append("'").append(val).append("', ");
                    }
                }

                sql.deleteCharAt(sql.length() - 1).deleteCharAt(sql.length() - 1);
                if (rs.isLast()) {
                    sql.append(")");
                } else {
                    sql.append("),\n");
                }
            }
            sql.append(";");
            sql.append("\n--\n").append(MysqlUtil.SQL_END_PATTERN);
            sql.append(" table insert : ").append(TABLE_NAME).append("\n--\n");
            // enable FK constraint
            sql.append("\n/*!40000 ALTER TABLE ").append(TABLE_NAME).append(" ENABLE KEYS */;\n");
        } catch (Exception e) {
            logger.error("GetDataInsertStatement error={},sql={}", e, sqlScript.toString());
        }
        return sql.toString();
    }

    /**
     * 清理临时文件
     *
     * @param preserveZipFile bool
     */
    public void clearTempFiles(boolean preserveZipFile,String backupPath) {

        deleteDir(new File(backupPath));

        // delete the temp sql file
        File sqlFile = new File(backupPath + "/sql/" + mysqlFileName);
        if (sqlFile.exists()) {
            boolean res = sqlFile.delete();
            logger.info(": " + sqlFile.getAbsolutePath() + " deleted successfully? " + (res ? " TRUE " : " FALSE "));
        } else {
            logger.info(": " + sqlFile.getAbsolutePath() + " DOES NOT EXIST while clearing Temp Files");
        }

        File sqlFolder = new File(backupPath + "/sql");
        if (sqlFolder.exists()) {
            boolean res = sqlFolder.delete();
            logger.info(": " + sqlFolder.getAbsolutePath() + " deleted successfully? " + (res ? " TRUE " : " FALSE "));
        } else {
            logger.info(": " + sqlFolder.getAbsolutePath() + " DOES NOT EXIST while clearing Temp Files");
        }

        if (!preserveZipFile) {

            // delete the zipFile
            File zipFile = new File(zipFileName);
            if (zipFile.exists()) {
                boolean res = zipFile.delete();
                logger.info(
                        ": " + zipFile.getAbsolutePath() + " deleted successfully? " + (res ? " TRUE " : " FALSE "));
            } else {
                logger.info(": " + zipFile.getAbsolutePath() + " DOES NOT EXIST while clearing Temp Files");
            }

            // delete the temp folder
            File folder = new File(backupPath);
            if (folder.exists()) {
                boolean res = folder.delete();
                logger.info(": " + folder.getAbsolutePath() + " deleted successfully? " + (res ? " TRUE " : " FALSE "));

            } else {
                logger.info(": " + folder.getAbsolutePath() + " DOES NOT EXIST while clearing Temp Files");
            }
        }

        logger.info("generated temp files cleared successfully");
    }

    /**
     * 生成文件名 sql file name.
     *
     * @return String
     */
    public String getMySqlFilename(String dateTimeStr) {
        System.out.println("********************** 生成文件名 ***************************");
        System.out.println(dateTimeStr + "_" + mysqlDatabase + "_sys_audit_log_mysql.sql");
        System.out.println("********************** 生成文件名 ***************************");
        return dateTimeStr + "_" + mysqlDatabase + "_sys_audit_log_mysql.sql";
    }


    private static boolean deleteDir(File dir) {
        if (dir.isDirectory()) {
            String[] children = dir.list();
            //递归删除目录中的子目录下
            for (int i=0; i<children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
        }
        // 目录此时为空，可以删除
        return dir.delete();
    }

}
