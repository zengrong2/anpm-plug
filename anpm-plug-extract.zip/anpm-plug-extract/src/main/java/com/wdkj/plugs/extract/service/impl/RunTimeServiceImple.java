package com.wdkj.plugs.extract.service.impl;

import com.wdkj.plugs.extract.dao.click.IRunTimeClickDao;
import com.wdkj.plugs.extract.dao.mysql.IRunTimeDao;
import com.wdkj.plugs.extract.service.IRunTimeService;
import com.wdkj.plugs.model.po.RunTimeDataPo;
import com.wdkj.plugs.model.po.RunTimeRecordPo;
import com.wdkj.plugs.model.vo.RunTimeDataVo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional(rollbackFor = Exception.class)
public class RunTimeServiceImple implements IRunTimeService {

	private static Logger log = LoggerFactory.getLogger(RunTimeServiceImple.class);

	@Autowired
	private IRunTimeClickDao runTimeClickDao;

	@Autowired
	private IRunTimeDao runTimeDao;

	//检查范围
	private Integer dayCount = 30 ;

	@Override
	public void analysisData(Integer type) {
		//获取范围开始的时间
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		List<Long> endTimeList = new ArrayList<>();
		try {
			Calendar cal = Calendar.getInstance();
			cal.setTime(sdf.parse(sdf.format(new Date())));
			cal.add(Calendar.DAY_OF_YEAR,-dayCount);
			//根据开始时间，获取数据库中的记录
			List<RunTimeRecordPo> poList = runTimeDao.findRecordList(cal.getTimeInMillis()/1000,type);
			List<Long> poTimeList = poList.stream().map(RunTimeRecordPo::getTime).collect(Collectors.toList());
			for (int i = 0; i < dayCount-2; i++) {
				cal.add(Calendar.DAY_OF_YEAR,1);
				if(!poTimeList.contains(cal.getTimeInMillis()/1000)){
					endTimeList.add(cal.getTimeInMillis()/1000);
				}
			}
		} catch (Exception e){
			e.printStackTrace();
			log.error("获取时间列表错误！error={}",e.getMessage());
		}
		for (Long endTime : endTimeList) {
			Long startTime = endTime - (60*60*24);
			Map<Integer, RunTimeDataPo> upMap = new HashMap<>();
			List<RunTimeDataVo> allDataList = new ArrayList<>();
			if(type == 3){//链路质差
				//事件维度数据
				allDataList.addAll(runTimeClickDao.findLinkData(startTime,endTime,1));
				//告警维度数据
				allDataList.addAll(runTimeClickDao.findLinkData(startTime,endTime,2));
			} else {
				//事件维度数据
				allDataList.addAll(runTimeClickDao.findTaskData(startTime,endTime,1,type));
				//告警维度数据
				allDataList.addAll(runTimeClickDao.findTaskData(startTime,endTime,2,type));
			}
			if(allDataList.size() == 0){
				log.info("时间段：{}-{}无{}质差数据，已记录",startTime,endTime,type == 0 ? "链路" : "拨测");
			} else {
				//组合数据为一条
				Map<Integer,List<RunTimeDataVo>> allDataMap = allDataList.stream().collect(Collectors.groupingBy(RunTimeDataVo::getDataId));
				for (Integer dataId : allDataMap.keySet()) {
					if(!upMap.containsKey(dataId)){
						RunTimeDataPo po = new RunTimeDataPo();
						po.setDataId(dataId);
						po.setEndTime(endTime);
						po.setType(type);
						upMap.put(dataId,po);
					}
					for (RunTimeDataVo vo : allDataMap.get(dataId)) {
						if(vo.getType() == 1){
							upMap.get(dataId).setEventIds(vo.getEventIds());
							upMap.get(dataId).setDegradationDuration(vo.getDegradationDuration());
							upMap.get(dataId).setDelayDuration(vo.getDelayDuration());
							upMap.get(dataId).setPackLossDuration(vo.getPackLossDuration());
							upMap.get(dataId).setBrokenDuration(vo.getBrokenDuration());
						} else {
							upMap.get(dataId).setAlarmIds(vo.getEventIds());
							upMap.get(dataId).setAlarmDegradationDuration(vo.getDegradationDuration());
							upMap.get(dataId).setAlarmBrokenDuration(vo.getBrokenDuration());
							upMap.get(dataId).setAlarmDelayDuration(vo.getDelayDuration());
							upMap.get(dataId).setAlarmPackLossDuration(vo.getPackLossDuration());
						}
					}
				}
				int batchSize = 500;
				List<RunTimeDataPo> handleList = new ArrayList<>(upMap.values());
				int dataSize = handleList.size();

				for (int i = 0; i < dataSize; i += batchSize) {
					int end = Math.min(dataSize, i + batchSize);
					List<RunTimeDataPo> batch = handleList.subList(i, end);
					runTimeDao.insertData(batch);
				}
			}
			//新增记录
			RunTimeRecordPo recordPo = new RunTimeRecordPo();
			recordPo.setCreateTime(System.currentTimeMillis()/1000);
			recordPo.setTime(endTime);
			recordPo.setType(type);
			runTimeDao.insertRecord(recordPo);
		}
	}
}