package com.wdkj.plugs.extract.dao.mysql;

import com.wdkj.plugs.model.po.SnmpInterfaceInfo;
import com.wdkj.plugs.model.po.SpecialMatchFlow;
import com.wdkj.plugs.model.vo.VSpecialMatchVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @ClassName ISpecialMatchFlowDao
 * @Description TODO
 * @Author Mr.xie
 * @Date 2022/4/19 14:29
 */
@Repository
@Mapper
public interface ISpecialMatchFlowDao {

    List<VSpecialMatchVo> getUnSpecialList();

    List<SnmpInterfaceInfo> getInterfaceInfo();

    List<Integer> getOrgSectionById(@Param("orgId")Integer orgId);

    void saveMatchFlow(List<SpecialMatchFlow> flows);

    int existsSpecialMatchFlow(@Param("entity") SpecialMatchFlow specialMatchFlow);
}
