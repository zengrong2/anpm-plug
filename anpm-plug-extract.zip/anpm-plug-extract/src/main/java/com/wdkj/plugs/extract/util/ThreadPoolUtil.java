package com.wdkj.plugs.extract.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.concurrent.*;

@Component
public class ThreadPoolUtil {
    /**
     * 根据cpu的数量动态的配置核心线程数和最大线程数
     */
    private static final int CPU_COUNT = Runtime.getRuntime().availableProcessors();
    /**
     * 核心线程数 = CPU核心数 + 1
     */
//    private static final int CORE_POOL_SIZE = CPU_COUNT + 1;
    private static int CORE_POOL_SIZE = 10;

    @Value("${executor.corePoolSize:5}")
    public void setCorePoolSize(int corePoolSize) {
        CORE_POOL_SIZE = corePoolSize;
    }

    /**
     * 线程池最大线程数 = CPU核心数 * 2 + 1
     */
//    private static final int MAXIMUM_POOL_SIZE = CPU_COUNT * 2 + 1;
    private static int MAXIMUM_POOL_SIZE = 15;


    /**
     * 非核心线程闲置时超时1s
     */
//    private static final int KEEP_ALIVE = 1;
    private static final int KEEP_ALIVE = 60;
    /**
     * 线程池的对象
     */
    private static ThreadPoolExecutor threadPool;
    /**
     * 无返回值直接执行
     * @param runnable
     */
    public  static void execute(Runnable runnable){
        getThreadPool().execute(runnable);
    }

    /**
     * 返回值直接执行
     * @param callable
     */
    public  static <T> Future<T> submit(Callable<T> callable){
        return   getThreadPool().submit(callable);
    }


    /**
     * dcs获取线程池
     * @return 线程池对象
     */
    public static ThreadPoolExecutor getThreadPool() {
        if (threadPool != null) {
            return threadPool;
        } else {
            synchronized (ThreadPoolUtil.class) {
                if (threadPool == null) {
                    threadPool = new ThreadPoolExecutor(CORE_POOL_SIZE, CORE_POOL_SIZE+2, KEEP_ALIVE, TimeUnit.SECONDS,
                            new LinkedBlockingQueue<>(5000), new ThreadPoolExecutor.CallerRunsPolicy());

                }
                return threadPool;
            }
        }
    }

}
