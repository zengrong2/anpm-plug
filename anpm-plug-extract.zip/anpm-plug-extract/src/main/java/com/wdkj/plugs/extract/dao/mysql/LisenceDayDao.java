package com.wdkj.plugs.extract.dao.mysql;

import com.wdkj.plugs.model.po.CheckReportData;
import com.wdkj.plugs.model.po.LisencePo;
import org.apache.ibatis.annotations.Param;
import org.mapstruct.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @ClassName ExtractSnmpDao
 * @Description TODO
 * @Author Mr.xie
 * @Date 2021/10/13 17:00
 */
@Mapper
@Repository
public interface LisenceDayDao {

    void insertLisenceDay();

    String getLisenceDay(@Param("buyDate") String buyDate);

    Integer selectByDay(String curDate);
}
