package com.wdkj.plugs.extract.dao.click;

import com.wdkj.plugs.model.po.*;
import com.wdkj.plugs.model.vo.VRunTime;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * @ClassName ExtractSpecialMapper
 * @Description TODO
 * @Author Mr.xie
 * @Date 2020/11/12 11:38
 */
@Mapper
@Repository
public interface IExtractSpecialClickDao {

    void save(List<ExtractSpecialData> list);

    DelayLossData getDelayLoss(@Param("tableName") String tableName,@Param("linkId") Integer linkId,@Param("startTimeSecond") Long startTimeSecond,@Param("endTimeSecond") Long endTimeSecond);

    List<DelaySpecialData> getDelayList(@Param("tableName") String tableName, @Param("linkIds") List<Integer> linkId, @Param("startTimeSecond") Long startTimeSecond, @Param("endTimeSecond") Long endTimeSecond);

    List<Map<String, Object>> devFlowSpeed(@Param("startTimeSecond") Long startTimeSecond, @Param("endTimeSecond") Long endTimeSecond,@Param("specialAIp") String specialAIp,@Param("specialZIp") String specialZIp,@Param("orgIdList") List<Integer> orgIdList);

    List<VRunTime> getRunTimeList(@Param("startTimeSecond")Long startTimeSecond,@Param("endTimeSecond") Long endTimeSecond);

    List<VRunTime> getRepairRunTimeList(@Param("startTimeSecond")Long startTimeSecond,@Param("endTimeSecond") Long endTimeSecond);

    Map<String, Object> getSpecialFlow(@Param("startTimeSecond") Long startTimeSecond, @Param("endTimeSecond") Long endTimeSecond, @Param("specialId")Integer specialId);

    List<DelaySpecialFlowData> getSpecialFlowList(@Param("startTimeSecond") Long startTimeSecond, @Param("endTimeSecond") Long endTimeSecond, @Param("specialIds") List<Integer> specialIds);

    void deleteSpecialBandwidthRateMonthByTime(@Param("startTime")Long startTime, @Param("endTime")Long endTime);

    SpecialBandwidthRateMonth getNinetyEightMaxBandwithBySpecialId(@Param("specialId")Integer specialId, @Param("startTime")Long startTime, @Param("endTime")Long endTime);

    SpecialBandwidthRateMonth getSpecialMaxAvgBandwidthRateMonth(@Param("specialId")Integer specialId,@Param("startTime")Long startTime, @Param("endTime")Long endTime);

    SpecialBandwidthRateMonth getSpecialBandwidthRateMonthBySpecialId(@Param("specialId")Integer specialId, @Param("startTime")Long startTime, @Param("endTime")Long endTime);

    SpecialBandwidthRateMonth getSpecialBandwidthRateNineEightCountBySpecialId(@Param("specialId")Integer specialId, @Param("startTime")Long startTime, @Param("endTime")Long endTime);

    SpecialBandwidthRateMonth getIntoBandwidthRateNineEightBySpecialId(@Param("specialId")Integer specialId, @Param("startTime")Long startTime, @Param("endTime")Long endTime,@Param("nineEightCount")Integer nineEightCount);

    SpecialBandwidthRateMonth getOutBandwidthRateNineEightBySpecialId(@Param("specialId")Integer specialId, @Param("startTime")Long startTime, @Param("endTime")Long endTime,@Param("nineEightCount")Integer nineEightCount);


    List<SpecialBandwidthRateMonth> findSpecialBandwidthRateMonthBySpecialIds(@Param("specialIds")List<Integer> specialIds, @Param("startTime")Long startTime, @Param("endTime")Long endTime,@Param("workingHoursOnly")Boolean workingHoursOnly);

    List<SpecialBandwidthRateMonth> findSpecialBandwidthRateNineEightCountBySpecialIds(@Param("specialIds")List<Integer> specialIds, @Param("startTime")Long startTime, @Param("endTime")Long endTime,@Param("workingHoursOnly")Boolean workingHoursOnly);

    List<SpecialBandwidthRateMonth> findIntoBandwidthRateNineEightBySpecialIds(@Param("nineEightCounts")List<SpecialBandwidthRateMonth> nineEightCounts, @Param("startTime")Long startTime, @Param("endTime")Long endTime,@Param("workingHoursOnly")Boolean workingHoursOnly);

    List<SpecialBandwidthRateMonth> findOutBandwidthRateNineEightBySpecialIds(@Param("nineEightCounts")List<SpecialBandwidthRateMonth> nineEightCounts, @Param("startTime")Long startTime, @Param("endTime")Long endTime,@Param("workingHoursOnly")Boolean workingHoursOnly);

}
