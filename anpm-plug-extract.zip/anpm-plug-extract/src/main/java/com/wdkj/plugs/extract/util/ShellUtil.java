package com.wdkj.plugs.extract.util;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.wdkj.plugs.extract.bean.MessageEnum;
import com.wdkj.plugs.extract.bean.Result;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * @description:
 * @author: qianghaohao
 * @time: 2021/3/28
 */
public class ShellUtil {
    private String host;
    private String username;
    private String password;
    private int port = 22;
    private int timeout = 60 * 60 * 1000;

    public ShellUtil(String host, String username, String password, int port, int timeout) {
        this.host = host;
        this.username = username;
        this.password = password;
        this.port = port;
        this.timeout = timeout;
    }

    public ShellUtil(String host, String username, String password) {
        this.host = host;
        this.username = username;
        this.password = password;
    }

    @SuppressWarnings("unused")
	public Session connect() {
        JSch jSch = new JSch();
        Session session = null;
        try {
            // 1. 获取 ssh session
            session = jSch.getSession(username, host, port);
            session.setPassword(password);
            session.setTimeout(timeout);
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();  // 获取到 ssh session
            if (null == session) {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
        return session;
    }


    /**
     * 如果需要后台执行某个命令，不能直接 <命令> + & 的方式执行，这样在 JSch 中不生效，需要写成这样的格式：<命令> > /dev/null 2>&1 &。
     * 比如要后台执行 sleep 60，需要写成 sleep 60 > /dev/null 2>&1
     *
     * @param cmd
     * @return
     */
    public Result execCommand(Session session, String cmd) {
        ChannelExec channelExec = null;
        BufferedReader inputStreamReader = null;
        BufferedReader errInputStreamReader = null;
        StringBuilder runLog = new StringBuilder("");
        StringBuilder errLog = new StringBuilder("");
        try {
            // 1. 获取 ssh session
            // 2. 通过 exec 方式执行 shell 命令
            channelExec = (ChannelExec) session.openChannel("exec");
            channelExec.setCommand(cmd);
//            channelExec.setPty(true);
//            channelExec.setPtySize(80, 24, 1024, 768);
            channelExec.connect();  // 执行命令
            // 3. 获取标准输入流
            inputStreamReader = new BufferedReader(new InputStreamReader(channelExec.getInputStream()));
            // 4. 获取标准错误输入流
            errInputStreamReader = new BufferedReader(new InputStreamReader(channelExec.getErrStream()));
            // 5. 记录命令执行 log
            String line = null;
            while ((line = inputStreamReader.readLine()) != null) {
                runLog.append(line).append("\n");
            }
            // 6. 记录命令执行错误 log
            String errLine = null;
            while ((errLine = errInputStreamReader.readLine()) != null) {
                errLog.append(errLine).append("\n");
            }
            // 7. 输出 shell 命令执行日志
//            System.out.println("exitStatus=" + channelExec.getExitStatus() + ", openChannel.isClosed="
//                    + channelExec.isClosed());
//            System.out.println("命令执行完成，执行日志如下:");
//            System.out.println(runLog.toString());
//            System.out.println("命令执行完成，执行错误日志如下:");
//            System.out.println(errLog.toString());
        } catch (Exception e) {
            return new Result(MessageEnum.FAIL, "服务器" + host + "获取命令失败");
        } finally {
            try {
                if (inputStreamReader != null) {
                    inputStreamReader.close();
                }
                if (errInputStreamReader != null) {
                    errInputStreamReader.close();
                }
                if (channelExec != null) {
                    channelExec.disconnect();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return new Result(MessageEnum.SUCCESS, "执行状态为" + (channelExec.getExitStatus() == 0 ? "成功" : "失败"), runLog.toString());
    }

    public static void main(String[] args) {

    }
}
