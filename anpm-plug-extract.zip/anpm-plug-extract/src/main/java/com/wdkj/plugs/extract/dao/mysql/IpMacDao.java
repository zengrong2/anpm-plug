package com.wdkj.plugs.extract.dao.mysql;

import com.alibaba.fastjson.JSONObject;
import com.wdkj.plugs.model.po.SysDialConfig;
import com.wdkj.plugs.model.po.SysGether;
import com.wdkj.plugs.model.po.device.DevArp;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface IpMacDao {
    List<SysDialConfig> getDynamicIpProbeTask();

    JSONObject getIpAndMacRelation(@Param("ip") String destIp, @Param("mac") String destMac);

    void updateTaskInfo(SysDialConfig task);

    JSONObject getIpAndMacRelationByMac(@Param("mac") String destMac);

    SysGether getGetherByCode(@Param("code") String getherCode);

    List<Integer> getSnmpTasksDevIdByProbeId(@Param("probeId") Integer id);

    List<DevArp> queryIPandMACByDevId(@Param("devIds") List<Integer> devIds, @Param("ip") String ip, @Param("mac") String mac);
}
