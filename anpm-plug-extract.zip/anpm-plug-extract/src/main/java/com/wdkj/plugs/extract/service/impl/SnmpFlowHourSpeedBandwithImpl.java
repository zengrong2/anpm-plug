package com.wdkj.plugs.extract.service.impl;

import com.alibaba.excel.util.StringUtils;
import com.wdkj.plugs.extract.dao.click.IExtractSnmpClickDao;
import com.wdkj.plugs.extract.dao.mysql.IIndexSyncDao;
import com.wdkj.plugs.extract.dao.mysql.ISysDialConfigSameReminderDao;
import com.wdkj.plugs.extract.service.ISnmpFlowHourSpeedBandwithService;
import com.wdkj.plugs.extract.service.ISysDialConfigSameReminderService;
import com.wdkj.plugs.model.po.RunTimeRecordPo;
import com.wdkj.plugs.model.vo.SflowDataApply;
import com.wdkj.plugs.model.vo.SnmpFlowVo;
import com.wdkj.plugs.utils.date.DateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.sql.DataSource;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * @author zr
 */
@Service
public class SnmpFlowHourSpeedBandwithImpl implements ISnmpFlowHourSpeedBandwithService {

    private static Logger log = LoggerFactory.getLogger(SnmpFlowHourSpeedBandwithImpl.class);

    @Autowired
    private IExtractSnmpClickDao extractSnmpClickDao;

    @Autowired
    private IIndexSyncDao indexSyncDao;


    private String tableName="snmp_flow_hour_speed_bandwith";

    //检查抽取范围默认92天
    @Value("${extract-snmpFlowHourSpeedBandwith-checkDays:92}")
    private Integer dayCount;

    //一次性插入数据库条数默认20w
    @Value("${extract-snmpFlowHourSpeedBandwith-saveCount:200000}")
    public Integer extractSflowAnalysisSaveCount;

    //插入数据库线程数量默认2个
    @Value("${extract-snmpFlowHourSpeedBandwith-insertDataThreadPool:1}")
    private Integer insertDataThreadPool;


    private JdbcTemplate jdbcTemplate;
    @Autowired
    public void setJdbcTemplate(@Qualifier("clickDataSource") DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public void analysisDataSnmpFlowHour(){
        try {
        Boolean isFirstExtract = true;
        String syncTime = indexSyncDao.getLastDateByName(tableName);
        if(StringUtils.isNotBlank(syncTime)){
            isFirstExtract = false;
        }
        // 获取当前时间范围的结束时间列表
        List<Long> endTimeList = new ArrayList<>();
        //获取62天内所有没有抽取的所有小时
        handelSyncTimeToHourCurrTimeAllHours(syncTime, endTimeList);

        endTimeList = endTimeList.stream().distinct().sorted().collect(Collectors.toList());
        // 异步处理每个时间段的数据
        if (!CollectionUtils.isEmpty(endTimeList)) {
            //创建插入数据库线程数
            ExecutorService insertDataExecutorService = Executors.newFixedThreadPool(insertDataThreadPool);
            try {
            for (Long endTime : endTimeList) {
                Long startTime = endTime - (60 * 60);  // 计算每个时间段的起始时间
                extractSnmpClickDao.deleteSnmpFlowHourSpeedBandwithByTime(startTime, endTime);
                List<SnmpFlowVo> snmpFlowVos = extractSnmpClickDao.findSpeedBandwithByStartAndEndTime(startTime, endTime);
                // 批量插入数据
                if (snmpFlowVos.size() > 0) {
                    int batchSize = extractSflowAnalysisSaveCount;  // 优化批次大小
                    List<CompletableFuture<Void>> insertDataFutures = newInsertSflowDataApplyDayData(snmpFlowVos, batchSize, tableName, insertDataExecutorService, jdbcTemplate);
                    // 等待所有插入数据任务完成
                    CompletableFuture.allOf(insertDataFutures.toArray(new CompletableFuture[0])).join();
                }
                Map<String, String> paramMap = new HashMap<>(2);
                String endTimeStr = DateUtil.timeStampToDateStr(endTime*1000l,DateUtil.YYYYMMDDHH0000);
                paramMap.put("table", tableName);
                paramMap.put("syncTime", endTimeStr);
                // 保存或更新抽取时间
                if (isFirstExtract) {
                    indexSyncDao.saveSyncDate(paramMap);
                    isFirstExtract = false;
                } else {
                    indexSyncDao.updateSyncDate(paramMap);
                }

            }
            } catch (Exception e) {
                e.printStackTrace();
                log.error("SnmpFlowHourSpeedBandwith数据抽取小时执行失败: {}", e.getMessage(), e);
            } finally {
                // 关闭插入数据线程池
                insertDataExecutorService.shutdown();
            }

        }
        } catch (Exception e) {
            e.printStackTrace();
            log.error("SnmpFlowHourSpeedBandwith数据抽取小时执行失败: {}", e.getMessage(), e);
        }
    }

    /**
     * 插入数据
     * @param resSflowDataVos
     * @param batchSize
     * @param tableName
     * @param insertDateexecutorService
     * @param jdbcTemplate
     * @return
     */
    private List<CompletableFuture<Void>> newInsertSflowDataApplyDayData(List<SnmpFlowVo> resSflowDataVos, int batchSize, String tableName, ExecutorService insertDateexecutorService, JdbcTemplate jdbcTemplate) {
        // 将任务分成多个批次
        List<CompletableFuture<Void>> futures =  IntStream.range(0, (resSflowDataVos.size() + batchSize - 1) / batchSize)
                .mapToObj(i -> {
                    int start = i * batchSize;
                    int end = Math.min(resSflowDataVos.size(), start + batchSize);
                    List<SnmpFlowVo> batch = resSflowDataVos.subList(start, end);
                    // 提交任务到线程池
                    return CompletableFuture.runAsync(() -> {
                        try {
                            String sql = "INSERT INTO "+tableName+" (dev_id, interface_id, flow_into_speed, flow_out_speed, into_bandwith_rate,out_bandwith_rate, create_ts) VALUES (?, ?, ?, ?, ?, ?,?)";
                            jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
                                @Override
                                public void setValues(PreparedStatement ps, int i) throws SQLException {
                                    SnmpFlowVo item = batch.get(i);
                                    ps.setInt(1, item.getDevId());
                                    ps.setInt(2, item.getInterfaceId());
                                    ps.setDouble(3, null != item.getFlowIntoSpeed()?item.getFlowIntoSpeed():-1);
                                    ps.setDouble(4, null != item.getFlowOutSpeed()?item.getFlowOutSpeed():-1);
                                    ps.setDouble(5, null != item.getIntoBandwithRate()?item.getIntoBandwithRate():-1);
                                    ps.setDouble(6, null != item.getOutBandwithRate()?item.getOutBandwithRate():-1);
                                    ps.setLong(7, DateUtil.dateToStampTwo(item.getCreateTsStr()));
                                }
                                @Override
                                public int getBatchSize() {
                                    return batch.size();
                                }
                            });
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }, insertDateexecutorService);
                }).collect(Collectors.toList());
        return futures;
    }
    /**
     * 获取没有抽取的所有小时
     * @param syncTime
     * @param endTimeList
     * @throws ParseException
     */
    private void handelSyncTimeToHourCurrTimeAllHours(String syncTime, List<Long> endTimeList) throws ParseException {
        if(StringUtils.isNotBlank(syncTime)){
            Date syncDate = DateUtil.str2DateTime(syncTime, DateUtil.YYYYMMDDHH0000);
            // 获取syncDate到当前时间的所有小时
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(syncDate);
            // 将分钟、秒、毫秒设置为0，确保时间整点
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            calendar.add(Calendar.HOUR_OF_DAY, 1); // 从下一个小时开始
            
            // 获取当前时间并设置为整点
            Calendar currentCalendar = Calendar.getInstance();
            currentCalendar.set(Calendar.MINUTE, 0);
            currentCalendar.set(Calendar.SECOND, 0);
            currentCalendar.set(Calendar.MILLISECOND, 0);
            
            // 遍历从syncDate到当前时间的每个小时
            while (calendar.getTimeInMillis() <= currentCalendar.getTimeInMillis()) {
                // 添加当前小时的结束时间戳（秒）
                endTimeList.add(calendar.getTimeInMillis() / 1000);
                // 移动到下一个小时
                calendar.add(Calendar.HOUR_OF_DAY, 1);
            }
        } else {
            // 获取当前时间往前推dayCount天的所有小时
            Calendar calendar = Calendar.getInstance();
            // 设置为当天的零点（0时0分0秒）
            calendar.set(Calendar.HOUR_OF_DAY, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            
            // 保存当前时间作为结束点
            Calendar endCalendar = Calendar.getInstance();
            // 同样设置为整点，但保留当前小时
            endCalendar.set(Calendar.MINUTE, 0);
            endCalendar.set(Calendar.SECOND, 0);
            endCalendar.set(Calendar.MILLISECOND, 0);
            
            // 往前推dayCount天
            calendar.add(Calendar.DAY_OF_MONTH, -dayCount);
            // 遍历从dayCount天前到当前的每个小时
            while (calendar.getTimeInMillis() <= endCalendar.getTimeInMillis()) {
                // 添加当前小时的结束时间戳（秒）
                endTimeList.add(calendar.getTimeInMillis() / 1000);
                // 移动到下一个小时
                calendar.add(Calendar.HOUR_OF_DAY, 1);
            }
        }
    }

//    public static void main(String[] args) throws ParseException {
//        List<Long> endTimeList = new ArrayList<>();
//        handelSyncTimeToHourCurrTimeAllHours("2025-05-12 02:00:00", endTimeList);
//        for (Long endTime:endTimeList) {
////            System.out.println("endTimeLong"+endTime);
//            System.out.println("endTime"+DateUtil.timeStampToDateStr(endTime*1000l,DateUtil.YYYYMMDDHH0000));
//        }
//    }
}
