package com.wdkj.plugs.extract.service;


/**
 *
 * @author lp
 *
 */
public interface PathLinkDataService {

    void handleLinkData(Integer delayLossQueryMinute);

}
