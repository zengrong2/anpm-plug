package com.wdkj.plugs.extract.service.impl;

import com.alibaba.fastjson.JSON;
import com.wdkj.plugs.extract.dao.mysql.IpMacDao;
import com.wdkj.plugs.extract.service.IpMacService;
import com.wdkj.plugs.model.po.SysDialConfig;
import com.wdkj.plugs.model.po.SysGether;
import com.wdkj.plugs.model.po.device.DevArp;
import com.wdkj.plugs.utils.ip.IpVerify;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;

/**
 * ipMac服务类
 */
@Service
public class IpMacServiceImpl implements IpMacService {
    private static Logger logger = LoggerFactory.getLogger(IpMacServiceImpl.class);

    @Resource
    private IpMacDao ipMacDao;

    @Override
    public void excute() {
//        查询当前的拨测任务  只查询配置为动态ip的  并且start_state 是3的表明是未匹配的
        logger.info("动态ip匹配开始");
        List<SysDialConfig> dialConfigs = ipMacDao.getDynamicIpProbeTask();
        if (null != dialConfigs && dialConfigs.size() > 0) {
            dialConfigs.forEach(task -> {
                SysGether getherByCode = ipMacDao.getGetherByCode(task.getGetherCode());
                if (null != getherByCode) {
                    List<Integer> devIds = ipMacDao.getSnmpTasksDevIdByProbeId(getherByCode.getId());
                    if (null != devIds && devIds.size() != 0) {
                        List<DevArp> arps = ipMacDao.queryIPandMACByDevId(devIds, task.getDestIp(), task.getDestMac());
                        if (!CollectionUtils.isEmpty(arps)) {
                            DevArp devArp = getDynamicIp(arps);
                            if (devArp == null) {
                                logger.error("动态ip匹配失败，没有匹配到动态IP：{}  ,mac:{}", JSON.toJSONString(task), task.getDestMac());
                                return;
                            }
                            updateTask(task.getId(), devArp.getToIp(), devArp.getToMac(), 1);
                            logger.info("动态ip匹配成功，任务数据：{}：", JSON.toJSONString(task));
                        } else {
                            logger.info("动态ip匹配失败,未找到匹配的数据,任务数据：{},设备id：{}", JSON.toJSONString(task), devIds.toString());
                        }
                    } else {
                        logger.info("动态ip匹配失败,探针未找到对应的设备，任务数据：{}，探针id：{}", JSON.toJSONString(task), getherByCode.getId());
                    }
                }
            });
            logger.info("动态ip匹配结束");
        } else {
            logger.info("动态ip匹配结束,没有需要匹配的任务");
        }
    }

    private DevArp getDynamicIp(List<DevArp> arpList) {
        if (CollectionUtils.isEmpty(arpList)) {
            return null;
        }
        DevArp devArp = null;
        for (DevArp drp : arpList) {
            String ip = drp.getToIp();
            if (StringUtils.isNotBlank(ip) && !isLocalPrivateIpv6(ip)) {
                devArp = drp;
                break;
            }
        }
        return devArp;
    }

    /**
     * 更新任务ip和mac地址和任务状态
     *
     * @param id
     * @param destIp
     * @param destMac
     * @param startStat
     */
    private void updateTask(Integer id, String destIp, String destMac, Integer startStat) {
        SysDialConfig sysDialConfig = new SysDialConfig();
        sysDialConfig.setId(id);
        sysDialConfig.setDestMac(destMac);
        sysDialConfig.setDestIp(destIp);
        sysDialConfig.setStartState(startStat);
        ipMacDao.updateTaskInfo(sysDialConfig);

    }

    /***
     *   排除本地链路的私有地址 fe80 开头的的ip地址
     *   这个逻辑和雷巡那边的逻辑保持一致。
     */
    public boolean isLocalPrivateIpv6(String ip) {
        return IpVerify.isLocalPrivateIpv6(ip);
    }
}
