package com.wdkj.plugs.extract.dao.mysql;

import com.wdkj.plugs.model.po.PcTestSpeedTask;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * pc测速DAO
 */
@Mapper
@Repository
public interface IPcTestSpeedDao {

    List<PcTestSpeedTask> getRunningPcTask();

    void updatePcTask(@Param("ids") List<Integer> taskIds);
}
