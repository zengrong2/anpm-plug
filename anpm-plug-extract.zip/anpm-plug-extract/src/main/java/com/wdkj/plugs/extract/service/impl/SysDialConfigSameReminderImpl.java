package com.wdkj.plugs.extract.service.impl;

import com.wdkj.plugs.extract.dao.mysql.ISysDialConfigSameReminderDao;
import com.wdkj.plugs.extract.service.ISysDialConfigSameReminderService;
import com.wdkj.plugs.model.vo.SysDialConfigSameReminderVo;
import com.wdkj.plugs.utils.constant.BaseConstant;
import com.wdkj.plugs.utils.enu.ConfigTypeEnum;
import com.wdkj.plugs.utils.enu.TypeEnum;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author zr
 */
@Service
public class SysDialConfigSameReminderImpl implements ISysDialConfigSameReminderService {

    private static Logger logger = LoggerFactory.getLogger(SysDialConfigSameReminderImpl.class);

    @Autowired
    private ISysDialConfigSameReminderDao sysDialConfigSameReminderDao;

    /**
     * 查询所有任务进行分组
     */
    @Override
    public void excuteSysDialConfigSameReminder() {
        Map<String, List<SysDialConfigSameReminderVo>> taskMap = new HashMap<>();
        List<SysDialConfigSameReminderVo> sysDialConfigSameReminderVos = sysDialConfigSameReminderDao.findSysDialConfigSameReminderVo();
        if (!CollectionUtils.isEmpty(sysDialConfigSameReminderVos)) {
            for (SysDialConfigSameReminderVo task : sysDialConfigSameReminderVos) {
                String keyDestMac = uniqueKey(task);//优先Mac
                String keyDestIp = uniqueKeyIp(task);//优先IP
                if(StringUtils.isNotBlank(keyDestMac)){
                    if(isTcpTask(task.getConfigType()) && isSessionPathTrackTask(task.getSessionPathTrack())){
                        keyDestMac = keyDestMac + "_" + uniqueSessionPathTrackKey(task);
                    }
                    if (!StringUtils.isEmpty(keyDestMac)) {
                        if (taskMap.containsKey(keyDestMac)) {
                            taskMap.get(keyDestMac).add(task);
                        } else {
                            taskMap.put(keyDestMac, new ArrayList<>(Collections.singletonList(task)));
                        }
                    }
                }
                if(StringUtils.isNotBlank(keyDestIp)){
                    if(isTcpTask(task.getConfigType()) && isSessionPathTrackTask(task.getSessionPathTrack())){
                        keyDestIp = keyDestIp + "_" + uniqueSessionPathTrackKey(task);
                    }
                    if (!StringUtils.isEmpty(keyDestIp)) {
                        if (taskMap.containsKey(keyDestIp)) {
                            taskMap.get(keyDestIp).add(task);
                        } else {
                            taskMap.put(keyDestIp, new ArrayList<>(Collections.singletonList(task)));
                        }
                    }
                }
            }
            if (!CollectionUtils.isEmpty(taskMap)) {
                for (Map.Entry<String, List<SysDialConfigSameReminderVo>> entry : taskMap.entrySet()) {
                    List<SysDialConfigSameReminderVo> taskSameReminderVos = entry.getValue();
                    //存在重复数据才：1暂停除id最小的任务的其他的状态，2被暂停的任务界面提示：与id最小任务编码为xxx的任务重复！
                    if (!CollectionUtils.isEmpty(taskSameReminderVos) && taskSameReminderVos.size() > 1) {
                        // 找到重复任务，处理逻辑
                        handleDuplicateTasks(taskSameReminderVos);
                    }
                }
            }
        }
    }


    private boolean isSessionPathTrackTask(Integer sessionPathTrack) {
        return Objects.nonNull(sessionPathTrack) && sessionPathTrack == TypeEnum.TYPE1.code();
    }

    private boolean isTcpTask(Integer configType) {
        return Objects.nonNull(configType) && configType == ConfigTypeEnum.TCP_TRACE_7.code();
    }

    /**
     * 根据任务拨测类型设置key值
     *
     * @param task
     * @return
     */
    private String generateTaskKey(SysDialConfigSameReminderVo task) {
        /**
         * UDP、TCP协议判断重复：4=UDP、7=TCP
         * 探针IP 探针端口 目标IP/MAC（优先使用MAC，无MAC使用IP） 目标端口 拨测协议，全部相同时视为重复任务，暂停除id最小的所有任务，界面提示：与编号为xxx的任务重复！
         * 注意：编号为xxx是id最小任务的编号
         */
        /**
         * ICMP协议判断重复：5=ICMP Trace、2=ICMP Ping
         * 探针IP 目标IP/MAC（优先使用MAC，无MAC使用IP） 拨测协议，全部相同时视为重复任务，暂停除id最小的所有任务，界面提示：与编号为xxx的任务重复！
         * 注意：编号为xxx是id最小任务的编号
         */
        if (null != task.getConfigType()) {
            if (task.getConfigType() == 4 || task.getConfigType() == 7) {
                return task.getSourceIp() + ":" + task.getSourcePort() + ":" +
                        (task.getDestMac() != null ? task.getDestMac() : task.getDestIp()) +
                        ":" + task.getDestPort() + ":" + task.getConfigType();
            } else if (task.getConfigType() == 5 || task.getConfigType() == 2) {
                return task.getSourceIp() + ":" +
                        (task.getDestMac() != null ? task.getDestMac() : task.getDestIp()) +
                        ":" + task.getConfigType();
            }
        }
        return "";
    }

    /**
     * 处理分组后：1暂停除id最小的所有任务，2增加界面提示：与编号为xxx的任务重复！
     * xxx是最小任务的编号
     *
     * @param existingTasks
     */
    private void handleDuplicateTasks(List<SysDialConfigSameReminderVo> existingTasks) {
        //找到id最小的那个任务
        SysDialConfigSameReminderVo minTask = existingTasks.stream().min(Comparator.comparing(SysDialConfigSameReminderVo::getId)).orElse(null); // 如果集合为空，则返回null
        if (null != minTask) {
            //找到除了id最小的所有任务id
            List<Integer> exceptMinTaskIds = existingTasks.stream().filter(task -> task.getId() != minTask.getId()).map(task -> task.getId()).collect(Collectors.toList());
            if (!CollectionUtils.isEmpty(exceptMinTaskIds)) {
                sysDialConfigSameReminderDao.updateTaskStatusAndRemarkByTaskIds(exceptMinTaskIds, 0, minTask.getTaskNum());
            }
        }

    }

    /***
     * 1、ICMP任务：三元组+TOS值不重复；
     *
     * 2、UDP任务（常规、SIP）：五元组+TOS值不重复；
     *
     * 3、TCP任务五元组不重复（包括会话路径跟踪和非会话路径跟踪）；
     *
     * 若为会话路径跟踪任务再进一步判断：五元组不重复，且源IP、目标IP、目标端口、协议、TOS值组合不重复；（注：允许路径会话跟踪和非会话路径跟踪任务只源端口不一样）
     */
    public String uniqueKey(SysDialConfigSameReminderVo task) {
        List<String> keys = new ArrayList<>(10);

        keys.add(task.getSourceIp());
        keys.add(String.valueOf(task.getConfigType()));

        /*if (StringUtils.isNotBlank(task.getDestIp()) && StringUtils.isBlank(task.getDestMac())) {
            keys.add(task.getDestIp());
        }
        if (StringUtils.isBlank(task.getDestIp()) && StringUtils.isNotBlank(task.getDestMac())) {
            keys.add(task.getDestMac());
        }
        if (StringUtils.isNotBlank(task.getDestIp()) && StringUtils.isNotBlank(task.getDestMac())) {
            keys.add(task.getDestMac());
        }*/
        if(StringUtils.isNotBlank(task.getDestMac())){
            keys.add(task.getDestMac());
        }else{
            return "";
        }
        // ICMP协议时不判断该项
        if (ConfigTypeEnum.ICMP_TRACE.code() == task.getConfigType() || ConfigTypeEnum.ICMP_PING.code() == task.getConfigType()) {
        } else {
            keys.add(String.valueOf(task.getDestPort()));
            keys.add(String.valueOf(task.getSourcePort()));
        }

        // TOS值
        if (ConfigTypeEnum.TCP_TRACE_7.code() != task.getConfigType()) {
            keys.add(String.valueOf(task.getTosValue()));
        }

        return StringUtils.join(keys, BaseConstant.UNDERLINE);
    }

    /***
     * 1、ICMP任务：三元组+TOS值不重复；
     *
     * 2、UDP任务（常规、SIP）：五元组+TOS值不重复；
     *
     * 3、TCP任务五元组不重复（包括会话路径跟踪和非会话路径跟踪）；
     *
     * 若为会话路径跟踪任务再进一步判断：五元组不重复，且源IP、目标IP、目标端口、协议、TOS值组合不重复；（注：允许路径会话跟踪和非会话路径跟踪任务只源端口不一样）
     */
    public String uniqueKeyIp(SysDialConfigSameReminderVo task) {
        List<String> keys = new ArrayList<>(10);

        keys.add(task.getSourceIp());
        keys.add(String.valueOf(task.getConfigType()));

        /*if (StringUtils.isNotBlank(task.getDestIp()) && StringUtils.isBlank(task.getDestMac())) {
            keys.add(task.getDestIp());
        }
        if (StringUtils.isBlank(task.getDestIp()) && StringUtils.isNotBlank(task.getDestMac())) {
            keys.add(task.getDestMac());
        }
        if (StringUtils.isNotBlank(task.getDestIp()) && StringUtils.isNotBlank(task.getDestMac())) {
            keys.add(task.getDestMac());
        }*/
        if(StringUtils.isNotBlank(task.getDestIp())){
            keys.add(task.getDestIp());
        }else{
            return "";
        }
        // ICMP协议时不判断该项
        if (ConfigTypeEnum.ICMP_TRACE.code() == task.getConfigType() || ConfigTypeEnum.ICMP_PING.code() == task.getConfigType()) {
        } else {
            keys.add(String.valueOf(task.getDestPort()));
            keys.add(String.valueOf(task.getSourcePort()));
        }

        // TOS值
        if (ConfigTypeEnum.TCP_TRACE_7.code() != task.getConfigType()) {
            keys.add(String.valueOf(task.getTosValue()));
        }

        return StringUtils.join(keys, BaseConstant.UNDERLINE);
    }

    /***
     *  TCP任务五元组不重复（包括会话路径跟踪和非会话路径跟踪）；
     *
     * 若为会话路径跟踪任务再进一步判断：五元组不重复，且源IP、目标IP、目标端口、协议、TOS值组合不重复
     */
    public String uniqueSessionPathTrackKey(SysDialConfigSameReminderVo task) {
        List<String> keys = new ArrayList<>(10);

        keys.add(task.getSourceIp());
        keys.add(String.valueOf(task.getConfigType()));

//        机构+探针IP+探针端口（ICMP协议时不判断该项）+拨测协议+目标IP+目标端口（ICMP协议时不判断该项）
        if (StringUtils.isNotBlank(task.getDestIp()) && StringUtils.isBlank(task.getDestMac())) {
            keys.add(task.getDestIp());
        }
        if (StringUtils.isBlank(task.getDestIp()) && StringUtils.isNotBlank(task.getDestMac())) {
            keys.add(task.getDestMac());
        }
        if (StringUtils.isNotBlank(task.getDestIp()) && StringUtils.isNotBlank(task.getDestMac())) {
            keys.add(task.getDestMac());
        }
        // ICMP协议时不判断该项
        if (ConfigTypeEnum.ICMP_TRACE.code() == task.getConfigType() || ConfigTypeEnum.ICMP_PING.code() == task.getConfigType()) {
        } else {
            keys.add(String.valueOf(task.getDestPort()));
        }
        // TOS值
        keys.add(String.valueOf(task.getTosValue()));

        return StringUtils.join(keys, BaseConstant.UNDERLINE);
    }

}
