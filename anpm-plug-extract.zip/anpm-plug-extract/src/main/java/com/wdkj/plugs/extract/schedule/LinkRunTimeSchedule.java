package com.wdkj.plugs.extract.schedule;

import com.wdkj.plugs.extract.service.IRunTimeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * @ClassName 链路质差
 * @Description 主要做链路质差数据抽取，新的一天抽取两天前的数据进行汇总
 * @Author yuy
 * @Date 2023/07/25
 */
@Component
public class LinkRunTimeSchedule {
    private static Logger log = LoggerFactory.getLogger(LinkRunTimeSchedule.class);


    @Autowired
    private IRunTimeService linkRunTimeService;

    private static int i = 0 ;

    /**
     * 任务执行频率，1分钟检查一次
     */
    @Scheduled(cron = "0 */1 * * * ?")
//    @Async
    public void execute() {
        try{
            if(i == 0){
                i = 1 ;
            } else {
                return ;
            }
            linkRunTimeService.analysisData(0);
            linkRunTimeService.analysisData(1);
            linkRunTimeService.analysisData(3);
            linkRunTimeService.analysisData(5);
        } catch (Exception e){
            e.printStackTrace();
        } finally {
            i = 0 ;
        }

    }
}
