package com.wdkj.plugs.extract.dao.mysql;

import com.wdkj.plugs.model.vo.SysDialConfigSameReminderVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;

@Mapper
@Component
public interface ISysDialConfigSameReminderDao {

    List<SysDialConfigSameReminderVo> findSysDialConfigSameReminderVo();

    void updateTaskStatusAndRemarkByTaskIds(@Param("exceptMinTaskIds")List<Integer> exceptMinTaskIds, @Param("startState")Integer startState,@Param("suspendRepeatTaskNum")String suspendRepeatTaskNum);
}
