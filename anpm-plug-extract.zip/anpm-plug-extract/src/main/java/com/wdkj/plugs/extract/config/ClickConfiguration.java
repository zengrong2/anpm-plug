package com.wdkj.plugs.extract.config;

import com.alibaba.druid.pool.DruidDataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;

@Configuration
@MapperScan(basePackages = "com.wdkj.plugs.extract.dao.click", sqlSessionFactoryRef = "clickSqlSessionFactory")
public class ClickConfiguration {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    /**
     * 数据库连接配置
     */
    @Value("${spring.datasource.click.jdbcUrl}")
    private String url;
    @Value("${spring.datasource.click.username}")
    private String user;
    @Value("${spring.datasource.click.password}")
    private String password;
    @Value("${spring.datasource.click.driver-class-name}")
    private String driverClass;

    @Value("${spring.datasource.click.type}")
    private String type;

    /**
     * druid配置
     */
    @Value("${spring.datasource.druid.maxActive}")
    private Integer maxActive;
    @Value("${spring.datasource.druid.minIdle}")
    private Integer minIdle;
    @Value("${spring.datasource.druid.initialSize}")
    private Integer initialSize;
    @Value("${spring.datasource.druid.maxWait}")
    private Long maxWait;
    @Value("${spring.datasource.druid.timeBetweenEvictionRunsMillis}")
    private Long timeBetweenEvictionRunsMillis;
    @Value("${spring.datasource.druid.minEvictableIdleTimeMillis}")
    private Long minEvictableIdleTimeMillis;
    @Value("${spring.datasource.druid.validationQuery}")
    private String validationQuery;
    @Value("${spring.datasource.druid.testWhileIdle}")
    private Boolean testWhileIdle;
    @Value("${spring.datasource.druid.testWhileIdle}")
    private Boolean testOnBorrow;
    @Value("${spring.datasource.druid.testOnBorrow}")
    private Boolean testOnReturn;
    @Value("${spring.datasource.druid.poolPreparedStatements}")
    private Boolean poolPreparedStatements;
    @Value("${spring.datasource.druid.maxPoolPreparedStatementPerConnectionSize}")
    private Integer maxPoolPreparedStatementPerConnectionSize;

    @Bean(name = "clickDataSource")
    public DataSource masterDataSource() {
        // return DataSourceBuilder.create().build();
        logger.info("#####  Init Click...");
        DruidDataSource dataSource = new DruidDataSource();
        dataSource.setDriverClassName(driverClass);
        dataSource.setDbType(type);
        dataSource.setUrl(url);

        if (this.user != null && !"".equals(this.user)) {
            dataSource.setUsername(user);
        }
        if (this.password != null && !"".equals(this.password)) {
            dataSource.setPassword(password);
        }
        // 连接池配置
        dataSource.setMaxActive(maxActive);
        dataSource.setMinIdle(minIdle);
        dataSource.setInitialSize(initialSize);
        dataSource.setMaxWait(maxWait);
        dataSource.setTimeBetweenEvictionRunsMillis(timeBetweenEvictionRunsMillis);
        dataSource.setMinEvictableIdleTimeMillis(minEvictableIdleTimeMillis);
        dataSource.setTestWhileIdle(testWhileIdle);
        dataSource.setTestOnBorrow(testOnBorrow);
        dataSource.setTestOnReturn(testOnReturn);
        //dataSource.setValidationQuery(validationQuery);

        dataSource.setPoolPreparedStatements(poolPreparedStatements);
        dataSource.setMaxPoolPreparedStatementPerConnectionSize(maxPoolPreparedStatementPerConnectionSize);

        return dataSource;
    }

    @Bean(name = "clickSqlSessionFactory")
    public SqlSessionFactory sqlSessionFactory(@Qualifier("clickDataSource") DataSource dataSource) throws Exception {
        SqlSessionFactoryBean sessionFactoryBean = new SqlSessionFactoryBean();
        sessionFactoryBean.setDataSource(dataSource);
        // 注意： com/example/mybatis_demo/mapper/click/ 下必须至少要有一个文件，否则启动会失败
        sessionFactoryBean.setMapperLocations(new PathMatchingResourcePatternResolver()
                .getResources("classpath:com/wdkj/plugs/extract/dao/click/*.xml"));
        return sessionFactoryBean.getObject();
    }


    @Bean("clickJdbcTemplate")
    public JdbcTemplate jdbcTemplate(@Qualifier("clickDataSource") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }


}
