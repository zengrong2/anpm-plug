package com.wdkj.plugs.extract.dao.mysql;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * 数据抽取记录DAO
 */
@Mapper
@Repository
public interface IIndexSyncDao {

    /**
     * 获取最后抽取的时间
     *
     * @return
     * @throws Exception
     */
    public List<Map<String, String>> getIndexSyncLastDate();

    /**
     * 保存数据抽取时间记录
     *
     * @param param
     * @throws Exception
     */
    public void saveSyncDate(Map<String, String> param);

    /**
     * 修改数据抽取时间记录
     *
     * @param param
     * @throws Exception
     */
    public void updateSyncDate(Map<String, String> param);

    String getLastDateByName(@Param("tableName") String tableName);
}
