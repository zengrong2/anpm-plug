package com.wdkj.plugs.extract.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.Thread.State;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wdkj.plugs.extract.AnpmPlugExtractApplication;
import com.wdkj.plugs.extract.schedule.ExtractPathSchedule;
import com.wdkj.plugs.extract.schedule.ExtractSnmpSchedule;
import com.wdkj.plugs.extract.schedule.ExtractSpecialSchedule;
import com.wdkj.plugs.extract.util.DateUtil;

/**
 * @ClassName OperationToolController
 * @Description 抽取运维工具，观察抽取运行状态
 */
@RestController
@RequestMapping("/oper")
public class OperationToolController {
	private static HashMap<String, String> oLog = new HashMap<>();
	public static void doLog(String cls, String log) {
		oLog.put(cls, DateUtil.getNowDateTimeString()+":"+log);
	}
//    private static Logger logger = LoggerFactory.getLogger(OperationToolController.class);
    @PostMapping("/index")
    @RequestMapping("index")
	public void index(HttpServletRequest request, HttpServletResponse response) {
    	String html = "<html>"
    			+ "<title>抽取运维工具[17:18 2025/6/25]</title><style>body,td,div{font-size:12px}\n"
				+ ".err{color:#f00}\n"
				+ ".alink{color:blue;cursor:pointer;}\n"
				+ ".alink:hover{text-decoration:underline}\n"
				+ ".c1{margin-left:24px;border:1px dashed #ccc}"
				+ "</style>"
				+ "<script>"
				+ "function use(devid){"
				+ "window.location='?act=gether&ip='+devid;"
				+ "}"
				+ "</script>"
				+ "<body><pre>[V04]"
				+ AnpmPlugExtractApplication.dbgMsg + "\n"
				+ AnpmPlugExtractApplication.runInfo + "\n"
				+ "Now="+DateUtil.getNowDateTimeString()+"\n"
				+ "ExtractPathSchedule: \n最新信息："+oLog.get(ExtractPathSchedule.class.getName())+"\n"+ExtractPathSchedule.sb.toString()+";\n线程："+getThreadStacktrace(ExtractPathSchedule.tid)+"\n</hr>"
				+ "ExtractSnmpSchedule: \n最新信息："+oLog.get(ExtractSnmpSchedule.class.getName())+"\n"+ExtractSnmpSchedule.sb.toString()+";\n线程："+getThreadStacktrace(ExtractSnmpSchedule.tid)+"\n</hr>"
				+ "ExtractSpecialSchedule: \n最新信息："+oLog.get(ExtractSpecialSchedule.class.getName())+"\n"+ExtractSpecialSchedule.sb.toString()+";\n线程："+getThreadStacktrace(ExtractSpecialSchedule.tid)+"\n</hr>"
				+ "</pre></body>";
    	html += "线程列表<br>";
		html += "<table border=1 cellspacing=0 cellspadding=0 style='width:720px'><tr style='background:#009;color:#fff;'><td>id</td><td>name</td><td>State</td><tr>\n";
		int[] counts = new int[] {0, 0, 0};
		try {
			Map<Thread, StackTraceElement[]>  map = Thread.getAllStackTraces();
			int count = 0;
			for(Thread th : map.keySet()) {				
				
				if(th.getState()==State.RUNNABLE)
					counts[0]++;
				else if(th.getState()==State.TIMED_WAITING || th.getState()==State.WAITING)
					counts[1]++;
				else if(th.getState()==State.BLOCKED) {
					counts[2]++;
					html += "<tr ><td>["+(++count)+"]"+th.getId()+"</td><td><font color=red>"+th.getName()+"</font></td><td>"+th.getState()
					+"<pre>"+
						getStackTrace(th.getStackTrace())		
					+"</pre>"
					+"</td></tr>\n";
				}

				if(count<100)
					html += "<tr ><td>["+(++count)+"]"+th.getId()+"</td><td>"+(th.getName())+"</td><td>"+th.getState()+"</td></tr>\n";
				else {
					if(count==100) {
						count ++;
						html += "<tr><td class='err' colspan='3'>省略100个以后的线程信息</td></tr>";
					}
				}
			}
		} catch(Exception e) {
			html += "<tr><td class='err' colspan='3'><pre>"+getStackTrace(e.getStackTrace())+"</pre></td></tr>";
		}
		html += "</table>";
		html += "线程统计，运行中="+counts[0]+", 等待中="+counts[1]+", 阻塞中="+counts[2]
				+ "</html>";
		
		outPrint(response, html);
    }
	public static String getThreadStacktrace(long tid) {
		try {
			String rtn = "线程"+tid+"没有找到";

			Map<Thread, StackTraceElement[]>  map = Thread.getAllStackTraces();
			for(Thread th : map.keySet()) {
				if(th.getId()==tid) {
					rtn = "State="+th.getState()+",name="+th.getName()+",id="+th.getId()+"\n"+getStackTrace(map.get(th));
				}
			}

			return rtn;
		} catch(Exception e) {
			return e.getMessage();
		}
	}

	public static String getStackTrace(StackTraceElement[] arr) {
		String str = "[java_error_getStackTrace Thread.id="+Thread.currentThread()+",name="+Thread.currentThread().getName()+"]: \n";
		for (int i = 0; i < arr.length; i++) {
			str += "	> [" + i + "] " + arr[i].getFileName() + "->" + arr[i].getLineNumber() + ": "
					+ arr[i].getClassName() + "->" + arr[i].getMethodName() + "()\n";
		}

		if (arr.length < 1) {
			str += "> No StackTrace, current thread statck: \n";
			str += getThreadStacktrace(Thread.currentThread().getId());
		}

		return str;
	}
    public static void outPrint(HttpServletResponse response, String result) {
    	if(response==null) return;
        response.setContentType("text/html;charset=utf-8");
        response.setCharacterEncoding("UTF-8");

        try {
            PrintWriter pw = response.getWriter();
            pw.write(result);
            pw.flush();
            pw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	public static String getStackTrace(Exception e) {
		String str = "error_msg=" + e.getMessage() + "\n";
		str += getStackTrace(e.getStackTrace());
		return str;
	}
}
