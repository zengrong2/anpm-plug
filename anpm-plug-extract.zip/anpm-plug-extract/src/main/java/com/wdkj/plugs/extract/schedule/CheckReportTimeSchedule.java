package com.wdkj.plugs.extract.schedule;

import com.wdkj.plugs.extract.service.ICheckReportTimeService;
import com.wdkj.plugs.extract.service.IExtractPathService;
import com.wdkj.plugs.extract.service.IIndexSyncService;
import com.wdkj.plugs.extract.util.DateUtil;
import com.wdkj.plugs.systemlog.service.ISystemLogService;
import com.wdkj.plugs.utils.enu.LogLevelEnum;
import com.wdkj.plugs.utils.enu.LogTypeEnum;
import com.wdkj.plugs.utils.enu.ServiceTypeEnum;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

@Component
public class CheckReportTimeSchedule {

	private static Logger log = LoggerFactory.getLogger(CheckReportTimeSchedule.class);
    @Autowired
    private ICheckReportTimeService iCheckReportTimeService;
    /**
     * 任务执行频率，默认5分钟执行一次
     */
    @Scheduled(cron = "0 0/1 * * * ? ")
    public void extractPathData(){
        try{
            iCheckReportTimeService.checkReportTime();
        } catch (Exception e){
            log.error("check report time error! error={}",e.getMessage());
        }
    }
}
