package com.wdkj.plugs.extract.schedule;

import com.wdkj.plugs.extract.service.ISpecialMatchFlowService;
import com.wdkj.plugs.systemlog.service.ISystemLogService;
import com.wdkj.plugs.utils.enu.LogLevelEnum;
import com.wdkj.plugs.utils.enu.LogTypeEnum;
import com.wdkj.plugs.utils.enu.ServiceTypeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * @ClassName SpecialMatchFlow
 * @Description TODO
 * @Author Mr.xie
 * @Date 2022/4/19 13:53
 */
@Component
public class SpecialMatchFlowSchedule {
    /**
     * 执行状态,0.未执行,1.正在执行
     */
    private static Integer MATCHFLOW_IS_EXECUTE = 0;

    private static Logger logger = LoggerFactory.getLogger(SpecialMatchFlowSchedule.class);

    @Autowired
    private ISpecialMatchFlowService specialMatchFlowService;
    @Autowired
    private ISystemLogService systemLogService;


//    @PostConstruct
//    public void init(){
//        specialDataSchedule();
//    }

    @Scheduled(cron = "0 1/1 * * * ? ")
    @Async
    public void specialDataSchedule(){
        try {
            if (MATCHFLOW_IS_EXECUTE == 1){
                logger.error("专线流量关联正在执行，本次任务中止！");
            }
            MATCHFLOW_IS_EXECUTE = 1;
            logger.info("-----专线流量关联开始-----");
            specialMatchFlowService.updatesJob();
            logger.info("-----专线流量关联结束-----");
        }catch (Exception e){
            logger.error("专线流量关联失败:{}",e.getMessage(),e);
            systemLogService.saveLog(LogLevelEnum.LEVEL1.code(),e.getMessage(), ServiceTypeEnum.EXTRACT.lable(), LogTypeEnum.LOG_TYPE_ERROR.lable(),"专线流量关联", this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName());
        }finally {
            MATCHFLOW_IS_EXECUTE = 0;
        }
    }
}
