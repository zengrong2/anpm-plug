package com.wdkj.plugs.extract.dao.click;

import com.wdkj.plugs.model.po.SnmpFlowExtraceInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Description:
 * Created by zoujian ON 2021/4/14.
 */
@Mapper
public interface IFlowExtractClickDao {

    //获取流量小时数据
    List<SnmpFlowExtraceInfo> extractFlowHourData(@Param("startTime") String startTime, @Param("endTime") String endTime);
    //删除小时流量数据
    void deleteFlowHourData(@Param("startTime") String startTime, @Param("endTime") String endTime);
    //新增流量小时数据
    int addFlowHourData(@Param("flowHourDataList") List<SnmpFlowExtraceInfo> flowHourDataList, @Param("createTime")Long createTime);

    //获取流量天数据
    List<SnmpFlowExtraceInfo> extractFlowDayData(@Param("startTime") String startTime, @Param("endTime") String endTime);
    //删除天流量数据
    void deleteFlowDayData(@Param("startTime") String startTime, @Param("endTime") String endTime);
    //新增流量天数据
    int addFlowDayData(@Param("flowDayDataList") List<SnmpFlowExtraceInfo> flowDayDataList, @Param("createTime")Long createTime);


}
