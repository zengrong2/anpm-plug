package com.wdkj.plugs.extract.schedule;

import com.wdkj.plugs.extract.service.IPcTestSpeedService;
import com.wdkj.plugs.model.po.PcTestSpeedTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
public class PcTestSpeedSchedule {

    @Autowired
    private IPcTestSpeedService service;

    private static Logger logger = LoggerFactory.getLogger(PcTestSpeedSchedule.class);

    @Value("${testSpeed.time}")
    private int execTime;

    /**
     * 暂时不用该方法
     */
    //@Scheduled(cron = "${testSpeed.execTime}")
    public void updatePcTaskStatus(){
        logger.info("-----PC测速任务状态检查更新开始-----");
        try {
            // 先获取进行中任务
            List<PcTestSpeedTask> pcTask = service.getRunningPcTask();
            if (pcTask != null && pcTask.size() > 0){
                long nowTime = System.currentTimeMillis();
                List<Integer> taskIds = new ArrayList<>();
                pcTask.forEach(task -> {
                    Date ct = task.getCreateTime();
                    long time = (nowTime - ct.getTime())/1000/60;
                    if (time > execTime){
                        taskIds.add(task.getId());
                    }
                });
                if (taskIds.size() > 0){
                    service.updatePcTask(taskIds);
                }
            }
            logger.info("-----PC测速任务状态检查更新结束-----");
        } catch (Exception e) {
            logger.error("PC测速任务状态检查更新失败:{}",e.getMessage(),e);
        }
    }
}
