package com.wdkj.plugs.extract.service;

import com.wdkj.plugs.model.po.PcTestSpeedTask;

import java.util.List;

/**
 * 检查更新pc测速任务状态service
 */
public interface IPcTestSpeedService {

    List<PcTestSpeedTask> getRunningPcTask();

    void updatePcTask(List<Integer> taskIds);
}
