package com.wdkj.plugs.extract.dao.mysql;

import com.wdkj.plugs.model.po.ExtractSpecialData;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @ClassName ExtractSpecialMapper
 * @Description TODO
 * @Author Mr.xie
 * @Date 2020/11/12 11:38
 */
@Mapper
@Repository
public interface IExtractSpecialDao {


    List<ExtractSpecialData> getSpecialList(@Param("startTimeSecond")Long startTimeSecond, @Param("endTimeSecond") Long endTimeSecond);

    List<Integer> getOrgSectionById(@Param("orgId") Integer orgId);

    ExtractSpecialData getRepairLinkList(@Param("linkId")Integer linkId);

    ExtractSpecialData getSpecialByLinkId(@Param("linkId")Integer linkId);

    List<ExtractSpecialData> getSpecialListByLinkId(@Param("linkIds") Set<Integer> linkId);

    /***
     * 没有运行时长，但是有时延、流量 等数据
     */  
    List<ExtractSpecialData> getSpecialListByNotEqLinkId(@Param("linkIds") Set<Integer> linkId);


    List<Integer> findAllSpecialIds();
}
