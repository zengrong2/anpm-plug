package com.wdkj.plugs.extract.dao.mysql;

import com.wdkj.plugs.model.po.BackupTableConfig;
import com.wdkj.plugs.model.vo.SysAuditLogBackupDefaultValue;
import org.mapstruct.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * @ClassName ISysAuditLogBackupDao
 * @Description TODO
 * @Author lan
 * @Date 2022/04/06
 */
@Repository
@Mapper
public interface ISysAuditLogBackupDao {
    List<SysAuditLogBackupDefaultValue> getBackupDefaultValue();

    BackupTableConfig getBackTabConfig(String name);

    void saveSysOperationLog(Map<String, Object> map);

}
