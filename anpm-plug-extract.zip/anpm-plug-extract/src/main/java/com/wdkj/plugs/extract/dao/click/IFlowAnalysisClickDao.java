package com.wdkj.plugs.extract.dao.click;

import com.wdkj.plugs.model.bo.FlowAnalysisFlowQuery;
import com.wdkj.plugs.model.bo.FlowAnalysisQuery;
import com.wdkj.plugs.model.po.RunTimeDataPo;
import com.wdkj.plugs.model.po.RunTimeRecordPo;
import com.wdkj.plugs.model.vo.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Collection;
import java.util.List;

/**
 * Description:
 * Created by zoujian ON 2020/6/23.
 */
@Mapper
public interface IFlowAnalysisClickDao {

    List<FlowAnalysisDevInfo> findFlowNumsGroupByDevId(FlowAnalysisQuery flowAnalysisQuery);

    List<FlowAnalysisDevInfo> findInterfaceNumsGroupByDevId(FlowAnalysisQuery flowAnalysisQuery);

    void deleteFlowAnalysisByDevIds(FlowAnalysisQuery flowAnalysisQuery);

    List<FlowInterfaceSpeedAndRate> findDevIdFlowByDevId(FlowAnalysisFlowQuery flowAnalysisFlowQuery);

    FlowAnalysisFlowSummaryVo getDevTotalFlowVosByDevId(FlowAnalysisFlowQuery flowAnalysisFlowQuery);

    List<FlowInterfaceSpeedAndRate> findDevIdFlowByDevIdAndInterfaceId(FlowAnalysisFlowQuery flowAnalysisFlowQuery);

    List<FlowAnalysisApplyVo> getPageApplyList(FlowAnalysisFlowQuery flowAnalysisFlowQuery);

    List<FlowAnalysisSourceVo> getPageSourceList(FlowAnalysisFlowQuery flowAnalysisFlowQuery);

    List<FlowAnalysisDestVo> getPageDestList(FlowAnalysisFlowQuery flowAnalysisFlowQuery);

    List<FlowAnalysisDialogVo> getPageDialogList(FlowAnalysisFlowQuery flowAnalysisFlowQuery);

    List<FlowAnalysisFlowVo> findApplyFlowSpendTrend(@Param("query")FlowAnalysisFlowQuery query,@Param("app")ApplicationMappingExpandedVo app);

    List<FlowAnalysisFlowVo> findSourceFlowSpendTrend(FlowAnalysisFlowQuery flowAnalysisFlowQuery);

    List<FlowAnalysisFlowVo> findDestFlowSpendTrend(FlowAnalysisFlowQuery flowAnalysisFlowQuery);

    List<FlowAnalysisFlowVo> findDialogFlowSpendTrend(@Param("query")FlowAnalysisFlowQuery query,@Param("apps")List<ApplicationMappingExpandedVo> apps);

    List<FlowAnalysisInterfaceVo> findInterfaceGroupByDevId(FlowAnalysisFlowQuery flowAnalysisFlowQuery);

    List<FlowAnalysisFlowVo> findOtherApplyFlowSpendTrend(@Param("query")FlowAnalysisFlowQuery query);


    List<SflowDataVo> findSflowDataVoData(@Param("tableName")String tableName,@Param("deviceId")Integer deviceId, @Param("startTime")Long startTime, @Param("endTime")Long endTime);


    void insertSflowDataDayData(List<SflowDataVo> dataList);

    void insertSflowDataHourData(List<SflowDataVo> dataList);

    void deleteSflowDataHourData();

    void deleteSflowDataHourByBeforeDayHour(@Param("reports")Long reports);

    void deleteDayDateByStartAndEndTime(@Param("deviceId")Integer deviceId, @Param("startTime")Long startTime, @Param("endTime")Long endTime);

    void deleteHourDateByStartAndEndTime(@Param("deviceId")Integer deviceId, @Param("startTime")Long startTime, @Param("endTime")Long endTime);

    List<SflowDataApply> findApplySflowDataVoData(@Param("tableName")String tableName,@Param("deviceId")Integer deviceId, @Param("startTime")Long startTime, @Param("endTime")Long endTime, @Param("pageNo")Integer pageNo, @Param("pageSize")Integer pageSize);

    Long findApplySflowDataVoDataCount(@Param("tableName")String tableName,@Param("deviceId")Integer deviceId, @Param("startTime")Long startTime, @Param("endTime")Long endTime);

    List<SflowDataApply> findApplyDaySflowDataVoData(@Param("tableName")String tableName,@Param("deviceId")Integer deviceId, @Param("startTime")Long startTime, @Param("endTime")Long endTime);

    void deleteSflowDataApplyDayByStartAndEndTime(@Param("deviceId")Integer deviceId, @Param("startTime")Long startTime, @Param("endTime")Long endTime);

    void deleteSflowDataApplyHourByStartAndEndTime(@Param("deviceId")Integer deviceId, @Param("startTime")Long startTime, @Param("endTime")Long endTime);

    void insertSflowDataApplyDayData(List<SflowDataApply> dataList);

    void insertSflowDataApplyHourData(List<SflowDataApply> dataList);



    List<SflowDataIpVo> findIpSflowDataVoData(@Param("tableName")String tableName,@Param("deviceId")Integer deviceId, @Param("startTime")Long startTime, @Param("endTime")Long endTime, @Param("pageNo")Integer pageNo, @Param("pageSize")Integer pageSize);

    List<SflowDataIpVo> findIpDaySflowDataVoData(@Param("tableName")String tableName,@Param("deviceId")Integer deviceId, @Param("startTime")Long startTime, @Param("endTime")Long endTime, @Param("pageNo")Integer pageNo, @Param("pageSize")Integer pageSize);

    Long findIpSflowDataVoDataCount(@Param("tableName")String tableName,@Param("deviceId")Integer deviceId, @Param("startTime")Long startTime, @Param("endTime")Long endTime);

    Long findIpDaySflowDataVoDataCount(@Param("tableName")String tableName,@Param("deviceId")Integer deviceId, @Param("startTime")Long startTime, @Param("endTime")Long endTime);

    void deleteSflowDataIpDayByStartAndEndTime(Integer deviceId, Long startTime, Long endTime);

    void deleteSflowDataIpHourByStartAndEndTime(Integer deviceId, Long startTime, Long endTime);


    void insertSflowDataIpDayData(List<SflowDataIpVo> dataList);

    void insertSflowDataIpHourData(List<SflowDataIpVo> dataList);

    void deleteSflowDataIpHourByBeforeDayHour(@Param("reports")Long reports);

    void deleteSflowDataAppHourByBeforeDayHour(@Param("reports")Long reports);

}
