package com.wdkj.plugs.extract.schedule;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import com.wdkj.plugs.extract.service.IExtractPathService;
import com.wdkj.plugs.extract.service.IIndexSyncService;
import com.wdkj.plugs.extract.util.DateUtil;
import com.wdkj.plugs.extract.web.OperationToolController;
import com.wdkj.plugs.systemlog.service.ISystemLogService;
import com.wdkj.plugs.utils.enu.LogLevelEnum;
import com.wdkj.plugs.utils.enu.LogTypeEnum;
import com.wdkj.plugs.utils.enu.ServiceTypeEnum;

/**
 * @ClassName ExtractSnmpSchedule
 * @Description TODO
 * @Author Mr.xie
 * @Date 2021/10/13 16:44
 */
@Component
public class ExtractPathSchedule {

    public static Integer extractPathTime = 5 ;

	private static Logger log = LoggerFactory.getLogger(ExtractPathSchedule.class);

    private final static String EXTRACT_PATH_DATA = "extract_path_data";
    private static Integer EXECUTION = 0 ;
    @Autowired
    private IExtractPathService extractPathService;
    @Autowired
    private IIndexSyncService indexSyncService;
    @Autowired
    private ISystemLogService systemLogService;
    public static StringBuilder sb = new StringBuilder();
    public static long tid = 0;
    /**
     * 任务执行频率，默认5分钟执行一次
     */
    @Scheduled(cron = "0 3/5 * * * ? ")
    @Async
    public void extractPathData(){
    	log.error("---------start path-路径数据抽取任务开始 Job----------");
        if(EXECUTION==1){
            log.info("--------- path-路径数据抽取任务正在执行，此次任务结束----------");
            OperationToolController.doLog(this.getClass().getName(), "--------- path-路径数据抽取任务正在执行，此次任务结束----------");
            return;
        }
        EXECUTION= 1;
        log.info("---------start path-路径数据抽取任务开始 Job----------");
        try {
            DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            boolean isFirstExtract = false;
            // 获取基础数据最后一次抽取的时间
            String lastTime = indexSyncService.getLastDateByName(EXTRACT_PATH_DATA);
            LocalDateTime now = DateUtil.getNear5(LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES));
            LocalDateTime startTime,endTime;
            //每五分钟抽一次
            if (StringUtils.isBlank(lastTime)){
                //第一次抽取,取前五分钟
                startTime = now.minusMinutes(5);
                isFirstExtract = true;
            }else {
                startTime = LocalDateTime.parse(lastTime,df);
            }
            endTime = now;
            
            sb.setLength(0);
            sb.append("<hr>ExtractPathSchedule 开始于=").append(DateUtil.getNowDateTimeString()).append("\n");
            long startMs = 0;
            tid = Thread.currentThread().getId();

            while (startTime.isBefore(endTime)){
            	startMs = System.currentTimeMillis();
            	sb.append(DateUtil.getNowDateTimeString()).append(" 执行=").append(startTime).append("\n");
                //每次抽取暂停100毫秒；防止补数据时，占用CPU过高
                Thread.sleep(100);
                //查询结束时间
                LocalDateTime end = startTime.plusMinutes(5);
                extractPathService.savePathData(isFirstExtract,startTime,end);
                isFirstExtract = false;
                sb.append(DateUtil.getNowDateTimeString()).append(" 完成 耗时=").append(System.currentTimeMillis()-startMs).append(" ms\n");
                startTime = end;
            }
            EXECUTION = 0 ;
            log.info("---------End path-路径数据抽取任务结束----------");
            sb.append(DateUtil.getNowDateTimeString()).append(" 完成\n");
        } catch (Exception e) {
            EXECUTION = 0 ;
            log.error("path-路径数据抽取定时任务出错:" + e.getMessage(), e);
            sb.append(DateUtil.getNowDateTimeString()).append(" 出错 ").append(OperationToolController.getStackTrace(e));
            systemLogService.saveLog(LogLevelEnum.LEVEL1.code(),e.getMessage(), ServiceTypeEnum.EXTRACT.lable(), LogTypeEnum.LOG_TYPE_ERROR.lable(),"拨测任务抽取数据", this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName());
        }finally {
            EXECUTION = 0 ;
        }
    }
}
