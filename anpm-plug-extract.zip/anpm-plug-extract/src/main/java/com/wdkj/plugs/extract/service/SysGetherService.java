package com.wdkj.plugs.extract.service;



public interface SysGetherService {

	void updateSysGether();

	void updateSflowSnmpGether();

}
