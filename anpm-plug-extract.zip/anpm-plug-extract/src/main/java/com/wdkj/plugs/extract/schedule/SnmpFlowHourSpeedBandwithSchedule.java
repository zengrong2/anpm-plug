package com.wdkj.plugs.extract.schedule;

import com.wdkj.plugs.extract.service.IFlowAnalysisService;
import com.wdkj.plugs.extract.service.ISnmpFlowHourSpeedBandwithService;
import com.wdkj.plugs.extract.util.DateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.PreDestroy;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @ClassName snmp_flow小时表抽取
 * @Description 主要snmp_flow小时表的抽取流速和带宽
 * @Author zengrong
 * @Date 2025/05/14
 */
@Component
public class SnmpFlowHourSpeedBandwithSchedule {
    private static Logger log = LoggerFactory.getLogger(FlowAnalysisSchedule.class);

    @Autowired
    private ISnmpFlowHourSpeedBandwithService snmpFlowHourSpeedBandwithService;

    private final Lock lockExecute = new ReentrantLock();


    @Scheduled(cron = "0 */10 * * * ?")
    @Async
    public void executeSnmpFlowHourSpeedBandwithDataApply() {
        if (lockExecute.tryLock()) {  // 尝试获取锁
            try {
                log.info("---------start SnmpFlowHourSpeedBandwith数据抽取小时任务开始 Job----------");
                long c = System.currentTimeMillis() / 1000;
                snmpFlowHourSpeedBandwithService.analysisDataSnmpFlowHour();
                long d = System.currentTimeMillis() / 1000;
                log.info("---------end SnmpFlowHourSpeedBandwith数据抽取小时任务结束 Job----------开始时间:"+DateUtil.secondToDate(c)+"结束时间:"+DateUtil.secondToDate(d)+"相差:"+(d-c)/60+"分钟");
            } catch (Exception e) {
                e.printStackTrace();
                log.error("SnmpFlowHourSpeedBandwith抽取-报错"+e.getMessage());
            } finally {
                lockExecute.unlock();  // 释放锁
                log.info("---------end SnmpFlowHourSpeedBandwith数据抽取结束任务 Job----------");
            }
        } else {
            log.info("SnmpFlowHourSpeedBandwith抽取-上一个任务还未完成，跳过本次执行");
        }
    }
}
