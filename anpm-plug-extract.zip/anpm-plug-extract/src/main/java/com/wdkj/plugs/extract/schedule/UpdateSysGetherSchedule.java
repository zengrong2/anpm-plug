package com.wdkj.plugs.extract.schedule;

import com.wdkj.plugs.extract.service.SysGetherService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * @ClassName UpdateSnmpRepeatSchedule
 * @Description TODO
 * @Author Mr.xie
 * @Date 2021/5/26 9:49
 */
@Component
public class UpdateSysGetherSchedule {

    private static Logger logger = LoggerFactory.getLogger(UpdateSysGetherSchedule.class);

    @Autowired
    private SysGetherService sysGetherService;

    /**
     * 检查探针的心跳，如果探针的最后上报时间大于3分钟，则认定为离线，需要更新探针的状态为离线
     */
    @Scheduled(cron = "0/10 * * * * ?")
    @Async
    public void updateSnmpRepeat() {
        updateSysGetherRepeat();
        updateSflowSnmpRepeat();
    }


    /**
     * 检查探针的心跳，如果探针的最后上报时间大于3分钟，则认定为离线，需要更新探针的状态为离线
     */
    public void updateSysGetherRepeat() {
        try {
            logger.info("-----检查探针心跳开始-----");
            sysGetherService.updateSysGether();
            logger.info("-----检查探针心跳结束-----");
        } catch (Exception e) {
            logger.error("检查探针心跳失败", e);
        }
    }

    /**
     * 检查sflow采集器的心跳，如果探针的最后上报时间大于3分钟，则认定为离线，需要更新探针的状态为离线
     */
    public void updateSflowSnmpRepeat() {
        try {
            logger.info("-----检查sFlow探针心跳开始-----");
            sysGetherService.updateSflowSnmpGether();
            logger.info("-----检查sFlow探针心跳结束-----");
        } catch (Exception e) {
            logger.error("检查sFlow探针心跳失败:", e);
        }
    }
}
