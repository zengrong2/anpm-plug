package com.wdkj.plugs.extract.service.impl;

import com.google.common.collect.Lists;
import com.wdkj.plugs.extract.dao.mysql.IIndexSyncDao;
import com.wdkj.plugs.extract.dao.mysql.SysDialConfigDestIpNameDao;
import com.wdkj.plugs.extract.service.ISysDialConfigDestIpNameServer;
import com.wdkj.plugs.model.po.SysDialConfigDestIpNamePo;
import com.wdkj.plugs.model.po.TaskDestIpNamePo;
import com.wdkj.plugs.utils.constant.BaseConstant;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author 郑兴泉 956607644@qq.com
 * @data 2024/9/12
 * 描述：
 */
//@Service
@Deprecated
public class SysDialConfigDestIpNameServerImpl implements ISysDialConfigDestIpNameServer {

    private static Logger log = LoggerFactory.getLogger(SysDialConfigDestIpNameServerImpl.class);

    @Resource
    private SysDialConfigDestIpNameDao sysDialConfigDestIpNameDao;

    @Resource
    private ISysDialConfigDestIpNameServer sysDialConfigDestIpNameServer;

    @Resource
    private JdbcTemplate jdbcTemplate;

    @Resource
    private IIndexSyncDao indexSyncDao;

    private String tableName = "sys_dial_config_destipname";

//    private final String insertSql = "INSERT INTO sys_dial_config_destipname (task_id,org_id,ip,dest_ip_name)VALUES(?,?,?,?)";
//    private final String updateSql = "update sys_dial_config_destipname set ip = ? ,dest_ip_name = ? where task_id = ? ";

    @Override
    @Deprecated
    public void updateTaskDestIpName() {
//        try {
//            String lastDateByName = indexSyncDao.getLastDateByName(tableName);
//            if (StringUtils.isBlank(lastDateByName)) {
//                // 说明第一次执行
//                indexSyncDao.saveSyncDate(getParam(1));
//            } else {
//                if ("1".equals(lastDateByName)) {
//                    log.error("有程序正在执行，不能够重复执行");
//                    return;
//                } else {
//                    indexSyncDao.updateSyncDate(getParam(1));
//                }
//            }
//            List<Integer> taskIds = sysDialConfigDestIpNameDao.queryTaskAllByTaskId();
//            if (CollectionUtils.isEmpty(taskIds)) {
//                sysDialConfigDestIpNameDao.deleteAll();
//                return;
//            }
//            List<List<Integer>> taskPartition = Lists.partition(taskIds, BaseConstant.FIGURE_500);
//            for (List<Integer> taskPartitionIds : taskPartition) {
//                List<TaskDestIpNamePo> taskDestIpNamePoList = sysDialConfigDestIpNameDao.queryTaskDestIpName(taskPartitionIds);
//                if (CollectionUtils.isEmpty(taskDestIpNamePoList)) {
//                    continue;
//                }
//                List<SysDialConfigDestIpNamePo> dialConfigDestIpNamePoList = taskDestIpNamePoList.stream().map(destIpNamePo -> {
//                    SysDialConfigDestIpNamePo namePo = new SysDialConfigDestIpNamePo();
//                    namePo.setTaskId(destIpNamePo.getId());
//                    namePo.setDestIpName(destIpNamePo.getShowDestName());
//                    namePo.setIp(destIpNamePo.getDestIp());
//                    namePo.setOrgId(destIpNamePo.getOrgId());
//                    return namePo;
//                }).collect(Collectors.toList());
//
//                sysDialConfigDestIpNameServer.addOrUpdate(dialConfigDestIpNamePoList);
//            }
//            indexSyncDao.updateSyncDate(getParam(0));
//        } catch (Exception e) {
//            log.error("执行报错 , error=>", e);
//            indexSyncDao.updateSyncDate(getParam(0));
//        }
    }

    private Map<String, String> getParam(Integer status) {
        Map<String, String> paramMap = new HashMap<>(2);
        paramMap.put("table", tableName);
        paramMap.put("syncTime", String.valueOf(status));
        return paramMap;
    }

    @Override
    public void addOrUpdate(List<SysDialConfigDestIpNamePo> dataList) {
        List<Integer> existsIds = sysDialConfigDestIpNameDao.queryExistsDestIpNameByTaskId();
        if (CollectionUtils.isEmpty(existsIds)) {
            sysDialConfigDestIpNameServer.add(dataList);
            return;
        }
        List<SysDialConfigDestIpNamePo> addList = new ArrayList<>(dataList.size());
        List<SysDialConfigDestIpNamePo> updateList = new ArrayList<>(dataList.size());
        for (SysDialConfigDestIpNamePo namePo : dataList) {
            if (existsIds.contains(namePo.getTaskId())) {
                updateList.add(namePo);
            } else {
                addList.add(namePo);
            }
        }
        sysDialConfigDestIpNameServer.add(addList);
        sysDialConfigDestIpNameServer.update(updateList);

    }

    @Override
    public void destroy() {
        String lastDateByName = indexSyncDao.getLastDateByName(tableName);
        if (StringUtils.isNotBlank(lastDateByName)) {
            // 修改状态
            indexSyncDao.updateSyncDate(getParam(0));
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void add(List<SysDialConfigDestIpNamePo> dataList) {
//        if (CollectionUtils.isEmpty(dataList)) {
//            return;
//        }
//
//        jdbcTemplate.batchUpdate(insertSql, new BatchPreparedStatementSetter() {
//            @Override
//            public void setValues(PreparedStatement preparedStatement, int i) throws SQLException {
//                SysDialConfigDestIpNamePo namePo = dataList.get(i);
//                preparedStatement.setInt(1, namePo.getTaskId());
//                preparedStatement.setInt(2, namePo.getOrgId());
//                preparedStatement.setString(3, namePo.getIp());
//                preparedStatement.setString(4, namePo.getDestIpName());
//            }
//
//            @Override
//            public int getBatchSize() {
//                return dataList.size();
//            }
//        });
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void update(List<SysDialConfigDestIpNamePo> dataList) {
//
//        if (CollectionUtils.isEmpty(dataList)) {
//            return;
//        }
//
//        jdbcTemplate.batchUpdate(updateSql, new BatchPreparedStatementSetter() {
//            @Override
//            public void setValues(PreparedStatement preparedStatement, int i) throws SQLException {
//                SysDialConfigDestIpNamePo namePo = dataList.get(i);
//                preparedStatement.setString(1, namePo.getIp());
//                preparedStatement.setString(2, namePo.getDestIpName());
//                preparedStatement.setInt(3, namePo.getTaskId());
//            }
//
//            @Override
//            public int getBatchSize() {
//                return dataList.size();
//            }
//        });
    }
}
