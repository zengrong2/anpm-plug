package com.wdkj.plugs.extract.service;

/**
 * @ClassName ISpecialMatchFlowService
 * @Description TODO
 * @Author Mr.xie
 * @Date 2022/4/19 14:00
 */
public interface ISpecialMatchFlowService {
    void updatesJob();
}
