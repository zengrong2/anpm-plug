package com.wdkj.plugs.extract.service;

public interface ISysDialConfigSameReminderService {
    void excuteSysDialConfigSameReminder();
}
