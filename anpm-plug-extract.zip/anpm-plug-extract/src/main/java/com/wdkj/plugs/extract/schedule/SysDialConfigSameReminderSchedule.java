package com.wdkj.plugs.extract.schedule;

import com.wdkj.plugs.extract.service.ISysDialConfigSameReminderService;
import com.wdkj.plugs.extract.service.IpMacService;
import com.wdkj.plugs.systemlog.service.ISystemLogService;
import com.wdkj.plugs.utils.enu.LogLevelEnum;
import com.wdkj.plugs.utils.enu.LogTypeEnum;
import com.wdkj.plugs.utils.enu.ServiceTypeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 【拨测分析-拨测任务管理】相同的探针相同的IP相同MAC相同的端口存在多条一样的数据时
 * id更大的拨测任务数据1任务状态：已暂停，2异常提醒：相同拨测任务，重复任务编号：xxxx
 */
@Component
public class SysDialConfigSameReminderSchedule {
    private static Logger logger = LoggerFactory.getLogger(SysDialConfigSameReminderSchedule.class);
    @Autowired
    private ISysDialConfigSameReminderService sysDialConfigSameReminderService;
    @Autowired
    private ISystemLogService systemLogService;

    @Scheduled(cron = "0 */5 * * * *")
    @Async
    public void hanldeSysDialConfigSameReminder() {
        try {
            sysDialConfigSameReminderService.excuteSysDialConfigSameReminder();
        } catch (Exception e
        ) {
            logger.error("处理【拨测任务管理】相同的探针相同的IP相同MAC相同的端口存在多条一样的数据时定时任务报错,{}", e.getMessage());
            systemLogService.saveLog(LogLevelEnum.LEVEL1.code(),e.getMessage(), ServiceTypeEnum.EXTRACT.lable(), LogTypeEnum.LOG_TYPE_ERROR.lable(),"处理【拨测任务管理】相同的探针相同的IP相同MAC相同的端口存在多条一样的数据时定时任务", this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName());
        }

    }
}
