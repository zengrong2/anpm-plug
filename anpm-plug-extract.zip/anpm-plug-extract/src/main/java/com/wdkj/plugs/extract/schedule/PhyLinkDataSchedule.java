package com.wdkj.plugs.extract.schedule;


import cn.hutool.core.map.MapUtil;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.wdkj.plugs.core.model.po.Org;
import com.wdkj.plugs.core.support.DynamicTableContext;
import com.wdkj.plugs.extract.dao.click.IPhyLinkDataReportClickDao;
import com.wdkj.plugs.extract.dao.mysql.IPhyLinkDataReportDao;
import com.wdkj.plugs.extract.service.LanguageService;
import com.wdkj.plugs.model.po.LinkDataTwo;
import com.wdkj.plugs.model.po.PhySnmpData;
import com.wdkj.plugs.model.po.ProbeDatas;
import com.wdkj.plugs.model.vo.VLinkRouteVo;
import com.wdkj.plugs.model.vo.VRateUnit;
import com.wdkj.plugs.utils.List.ListUtils;
import com.wdkj.plugs.utils.date.DateUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;

import static com.wdkj.plugs.utils.topo.topology.ComUtil.distinctByKey;

/**
 * @author lp
 */
@Component
public class PhyLinkDataSchedule {

    private static Logger logger = LoggerFactory.getLogger(PhyLinkDataSchedule.class);

    @Autowired
    private IPhyLinkDataReportDao phyLinkDataReportDao;

    @Autowired
    private IPhyLinkDataReportClickDao phyLinkDataReportClickDao;

    @Autowired
    private LanguageService languageService;

    @Value("${flowQueryMinute:480}")
    private Integer flowQueryMinute;

    @Scheduled(cron = "0 0/3 * * * ?")
    @Async
    public void daySchedule() {
        languageService.setLanguage();
        try {
            logger.info("-----开始执行物理拓扑线路数据更新-----");
            // 查询物理拓扑所有设备的线路
            List<VLinkRouteVo> phyLinks = phyLinkDataReportDao.findTopoLinksList();
            // 查询所有中继任务 k-devIp + peerIp
            // 未删除、未屏蔽、启动中的任务
            List<PhySnmpData> snmpRepeat = phyLinkDataReportDao.getSnmpRepeats();

            Map<String, PhySnmpData> snmpMap = new LinkedHashMap<>();
            for (PhySnmpData phySnmpData : snmpRepeat) {
                String devIp = phySnmpData.getDevIp();
                Integer getherId = phySnmpData.getGetherId();
                String peerIp = phySnmpData.getDestIp();
                Integer devId = phySnmpData.getDevId();
//                snmpMap.put(devIp + peerIp + devId, phySnmpData);
                snmpMap.put(devIp + "_" + peerIp + "_" + devId, phySnmpData);
            }
            // 查询中继任务频率列表
            List<PhySnmpData> snmpFre = phyLinkDataReportDao.getSnmpFre();
            Map<Integer, PhySnmpData> snmpFreMap = new LinkedHashMap<>();
            for (PhySnmpData phySnmpData : snmpFre) {
                snmpFreMap.put(phySnmpData.getRepeatId(), phySnmpData);
            }

            // 探针map
            List<Map<String, Object>> probeIds = phyLinkDataReportDao.getProbeId();
            Map<String, String> probeIdMap = new LinkedHashMap<>();
            for (Map<String, Object> stringMap : probeIds) {
                String devId = MapUtil.getStr(stringMap, "devid", "");
                String probeId = MapUtil.getStr(stringMap, "probeid", "");
                probeIdMap.put(devId, probeId);
            }
            // 获取route链路数据，按频率正序，时间倒序排列
            Map<String, Object> datasMap = querySpeculateData();
            // 查询所有拨测节点数据及对应的探针
            //获取每个路径的节点对
            List<ProbeDatas> pathLinkDatalist = getPathLinkList();
            // 探针map
            Map<String, List<ProbeDatas>> probeMap = pathLinkDatalist.stream().collect(
                    Collectors.groupingBy(
                            v -> String.valueOf(v.getProbeId())
                    ));


            List<LinkDataTwo> linkDatas = new LinkedList<>();


            Long queryDelayLossStartTimeLong = null;
            Long queryDelayLossEndTimeLong = null;
            Long startTimeLong = null;
            Long endTimeLong = null;
            if (null != flowQueryMinute) {
                Date now = new Date();
                String endTime = DateUtil.getTimeStr(now);
                queryDelayLossEndTimeLong = DateUtil.dateToStampTwo(endTime);
                String queryDelayLossStartTime = DateUtil.currDataAddReduceHMSNum(now, 2, -flowQueryMinute);
                queryDelayLossStartTimeLong = DateUtil.dateToStampTwo(queryDelayLossStartTime);
                //查询采集任务中端口指标最大的值乘以3
                VRateUnit rateUnit = phyLinkDataReportDao.getSnmpTaskRate();
                if (null != rateUnit) {
                    flowQueryMinute = null != rateUnit.getRate() ? rateUnit.getRate() * 3 : flowQueryMinute;
                }
                String startTime = DateUtil.currDataAddReduceHMSNum(now, 2, -flowQueryMinute);
                startTimeLong = DateUtil.dateToStampTwo(startTime);
                endTimeLong = DateUtil.dateToStampTwo(endTime);

            }

            Map<String, LinkDataTwo> allFlowDataMap = queryFlowData(startTimeLong, endTimeLong);
            //查询z端Ip专线
            Map<String, Integer> allSpecialDataZIpMap = querySpecialData();

            Map<String, List<Integer>> allDataMap = new LinkedHashMap<>();
            for (VLinkRouteVo phyLink : phyLinks) {
                // 数据准备
                String linkId = phyLink.getId();
//                if (!"2254".equals(linkId)) {
//                    continue;
//                }
                String sourceIp = phyLink.getSourceIp(); //本端设备管理ip
                String sourceId = phyLink.getSource(); //本端设备id
                String devPortId = phyLink.getDevPortId(); //本端线路端口
                String targetIp = phyLink.getTargetIp(); //对端设备管理ip
                String targetId = phyLink.getTarget(); //对端设备id
                String peerPortId = phyLink.getPeerPortId(); //对端线路端口
                String orgId = phyLink.getOrgId();
                List<Integer> orgIds = allDataMap.get(orgId);
                if (CollectionUtils.isEmpty(orgIds)) {
                    // 查询数据库
                    Org org = phyLinkDataReportDao.findOrgById(Integer.valueOf(orgId));
                    List<Org> list = phyLinkDataReportDao.queryOrgByTreeNumber(org.getTreeNumber() + "%", null, null, null, null);
                    orgIds = list.stream().map(Org::getId).collect(Collectors.toList());
                    allDataMap.put(orgId, orgIds);
                }

                Map<String, Integer> devPortDataMap = Maps.newHashMap();
                Map<String, Integer> peerPortDataMap = Maps.newHashMap();

                // 本端设备ips,连接设备Ip1
                List<String> devIpList = queryDevIpIfIps(sourceId, devPortId, devPortDataMap);
                devIpList.add(sourceIp);
                List<String> devIps = Lists.newArrayList(devIpList);

                // 对端设备ips，连接设备Ip2
                List<String> peerIpList = queryDevIpIfIps(targetId, peerPortId, peerPortDataMap);
                peerIpList.add(targetIp);
                List<String> peerIps = Lists.newArrayList(peerIpList);

                // 初始化链路数据
                LinkDataTwo linkData = new LinkDataTwo();
                linkData.setDelay("--");
                linkData.setLoseRate("--");
                linkData.setFlowIntoSpeed("--");
                linkData.setFlowOutSpeed("--");
                linkData.setIsSpecial(0);
                linkData.setDevPortId(0);
                linkData.setPeerIdPortId(0);
                linkData.setLinkId(Integer.valueOf(linkId));
                // 查询查询线路流量信息 flowFlag流向标志 0:A->B 1:B->A
                String flowFlag = "0";
//                linkData = getFlowData(linkData, flowFlag, devPortId, peerPortId, sourceId, targetId);

                linkData = getFlowData(linkData, flowFlag, devPortId, peerPortId, sourceId, targetId, allFlowDataMap);
                logger.info("-----执行获取链路信息 流量信息-----" + linkData);
                // 查询中继信息
                linkData = getSnmpInfo(phyLink.getSrcIp(), phyLink.getDestIp(), devPortDataMap, peerPortDataMap, snmpFreMap, snmpMap, sourceId, targetId, devIps, peerIps, linkData, sourceIp, targetIp, probeIdMap, datasMap, probeMap, queryDelayLossStartTimeLong, queryDelayLossEndTimeLong);
                logger.info("-----执行获取链路信息 中继-----" + linkData);

                // 查询专线信息
//                linkData = getSpecialLineInfo(sourceIp, targetIp, linkData, orgIds);
                linkData = getSpecialLineInfo(sourceIp, targetIp, linkData, devIps, peerIps, orgIds, allSpecialDataZIpMap);
                logger.info("-----执行获取链路信息 专线-----" + linkData);
                // 入库
                linkData.setLinkId(Integer.valueOf(linkId));
                linkData.setCreateTime(new Date());
                // 删除再更新
                linkDatas.add(linkData);

            }
            // 批量更新
            List<LinkDataTwo> finalLinkDatas = linkDatas.stream().filter(distinctByKey(LinkDataTwo::getLinkId)).collect(Collectors.toList());
            phyLinkDataReportDao.delLinkData();
            if (!CollectionUtils.isEmpty(finalLinkDatas)) {
                phyLinkDataReportDao.saveLinkData(finalLinkDatas);
            }
            logger.info("-----结束执行获取链路信息-----");
        } catch (Exception e) {
            logger.error("结束执行获取链路信息错误,error=>", e);
        }
    }

    private Map<String, Object> querySpeculateData() {
        List<Map<String, Object>> datas = phyLinkDataReportDao.getOneSpeculateData();
        if (!CollectionUtils.isEmpty(datas)) {
            Map<String, Object> dataMap = Maps.newLinkedHashMap();
            datas.forEach(data -> {
                String routeid = MapUtil.getStr(data, "routeid", "-1");
                String bizdataid = MapUtil.getStr(data, "bizdataid", "-1");
                dataMap.put(routeid + "_" + bizdataid, data);
            });
            return dataMap;
        }
        return Collections.EMPTY_MAP;
    }

    private List<String> queryDevIpIfIps(String sourceId, String devPortId, Map<String, Integer> portDataMap) {
        List<Map<String, Object>> ipIfIps = phyLinkDataReportDao.getDevIpIfIps(sourceId);
        if (CollectionUtils.isEmpty(ipIfIps)) {
            return Lists.newArrayList();
        }
        Set<String> ips = new HashSet<>(ipIfIps.size());
        String devPortIp = "";
        for (Map<String, Object> data : ipIfIps) {
            String id = MapUtil.getStr(data, "id", "-1");
            String ip = MapUtil.getStr(data, "ip", "");
            if (StringUtils.equals(devPortId, id)) {
                devPortIp = ip;
                continue;
            }
            portDataMap.put(ip, Integer.valueOf(id));
            ips.add(ip);
        }
        List<String> ipList = Lists.newArrayList(ips);
        // 当前选中的端口IP，优先匹配
        if (StringUtils.isNotBlank(devPortIp)) {
            ipList.add(0, devPortIp);
        }
        return ipList;
    }

    private Integer queryGetherIdByDevice(String deviceId, Map<String, Integer> getherDataMap) {
        Integer peerGetherId = getherDataMap.get(deviceId);
        if (peerGetherId == null) {
            peerGetherId = phyLinkDataReportDao.queryGetherIdByDevice(deviceId);
            if (peerGetherId == null) {
                // 无效的值
                peerGetherId = -1;
            }
            getherDataMap.put(deviceId, peerGetherId);
        }
        return peerGetherId;
    }

    private Map<String, LinkDataTwo> queryFlowData(Long startTimeLong, Long endTimeLong) {
        // 如果 线路为空，就不查询流量 snmp_flow 表的数据
        //查询流速表的所有流量根据接口id分组
        logger.info("查询流量sql开始....");
        long startTime = System.currentTimeMillis();
        List<LinkDataTwo> allFlowDatas = phyLinkDataReportClickDao.findAllFlowData(startTimeLong, endTimeLong);
        logger.info("查询流量sql结束....，花费：{}", (System.currentTimeMillis() - startTime));
        if (!CollectionUtils.isEmpty(allFlowDatas)) {
            Map<String, LinkDataTwo> allFlowDataMap = new LinkedHashMap<>();
            for (LinkDataTwo linkDataTwo : allFlowDatas) {
                if (null != linkDataTwo.getInterfaceId()) {
                    allFlowDataMap.put(String.valueOf(linkDataTwo.getInterfaceId()), linkDataTwo);
                }
            }
            return allFlowDataMap;
        }

        return Collections.EMPTY_MAP;
    }

    private Map<String, Integer> querySpecialData() {
        List<Map<String, Object>> allSpecialDataZIps = phyLinkDataReportDao.findAllSpecialDataZIp();
        if (!CollectionUtils.isEmpty(allSpecialDataZIps)) {
            Map<String, Integer> allSpecialDataZIpMap = new LinkedHashMap<>();
            for (Map<String, Object> allSpecialDataZIp : allSpecialDataZIps) {
                Integer orgId = MapUtil.getInt(allSpecialDataZIp, "orgId", -1);
                String specialAIp = MapUtil.getStr(allSpecialDataZIp, "specialAIp", "");
                String specialZIp = MapUtil.getStr(allSpecialDataZIp, "specialZIp", "");
                allSpecialDataZIpMap.put(orgId + "_" + specialAIp + "_" + specialZIp, 1);
            }
            return allSpecialDataZIpMap;
        }
        return Collections.EMPTY_MAP;

    }

    private List<ProbeDatas> getPathLinkList() {
        // 只能查询启动中的数据记录
        long a = System.currentTimeMillis();
        List<ProbeDatas> routeList = phyLinkDataReportDao.getRouteList();
        logger.error("查询getRouteList方法，时间：{}", System.currentTimeMillis() - a);
        if (CollectionUtils.isEmpty(routeList)) {
            return Collections.EMPTY_LIST;
        }
        List<ProbeDatas> list = new LinkedList<>();
        for (ProbeDatas route : routeList) {
            String routePathLayer = route.getRoutePathLayer();
            if (StringUtils.isBlank(routePathLayer) || "null".equals(routePathLayer)) {
                continue;
            }
            //路径ip集合
            List<String> ipList = ListUtils.StringToListStr(routePathLayer);
//            List<String> unodeIpList=ListUtils.StringToListStr(route.getUntrustNodes());//不可用节点
            if (route.getCurrentNodeIp() != null && !ipList.contains(route.getCurrentNodeIp())) {
                ipList.add(0, route.getCurrentNodeIp());
            }
            if (route.getNextNodeIp() != null && !ipList.contains(route.getNextNodeIp())) {
                ipList.add(route.getNextNodeIp());
            }
            //路径ip集合
            List<String> routeIpList = ListUtils.StringToListStr(routePathLayer);
            for (String ip : ipList) {
                //过滤掉*,不可用节点
                if (!"*".equals(ip)) {
                    routeIpList.add(ip);
                }
            }
            for (int i = 0, size = routeIpList.size(); i < size - 1; i++) {
                ProbeDatas linkData = new ProbeDatas();
                linkData.setBizDataId(route.getBizDataId());
                linkData.setRouteId(route.getRouteId());
                linkData.setProbeId(route.getProbeId());
                linkData.setOrgId(route.getOrgId());
                linkData.setCurrentNodeIp(routeIpList.get(i));
                linkData.setNextNodeIp(routeIpList.get(i + 1));
                list.add(linkData);
            }
        }
        return list;
    }

    private Integer getPortId(String ip, Map<String, Integer> portDataMap) {
        if (portDataMap == null || portDataMap.size() == 0) {
            return 0;
        }

        Set<Map.Entry<String, Integer>> entries = portDataMap.entrySet();
        for (Map.Entry<String, Integer> entry : entries) {
            String key = entry.getKey();
            Integer id = entry.getValue();
            List<String> ips = Lists.newArrayList(StringUtils.split(key, ";"));
            if (ips.contains(ip)) {
                return id;
            }
        }
        return 0;
    }

    private LinkDataTwo getSnmpInfo(String srcPortIp, String destPortIp,
                                    Map<String, Integer> devPortDataMap, Map<String, Integer> peerPortDataMap,
                                    Map<Integer, PhySnmpData> snmpFreMap, Map<String, PhySnmpData> snmpMap,
                                    String sourceId, String targetId,
                                    List<String> odevIps, List<String> opeerIps, LinkDataTwo linkData,
                                    String sourceIp, String targetIp, Map<String, String> probeIdMap,
                                    Map<String, Object> datas, Map<String, List<ProbeDatas>> probeMap,
                                    Long queryDelayLossStartTimeLong, Long queryDelayLossEndTimeLong) {
        if (ObjectUtils.isEmpty(linkData)) {
            linkData = new LinkDataTwo();
        }
        // 本端设备接口IP
        List<String> devIps = new ArrayList<>(255);
        // 对端设备接口IP
        List<String> peerIps = new ArrayList<>(255);
        if (odevIps != null) {
            for (String odevIp : odevIps) {
                devIps.addAll(Arrays.asList(odevIp.split(";")));
            }
        }

        if (opeerIps != null) {
            for (String odevIp : opeerIps) {
                peerIps.addAll(Arrays.asList(odevIp.split(";")));
            }
        }

        int isSucceed = 0;
        // 匹配任务
        List<PhySnmpData> snmpTask = new LinkedList<>();
        // 正向
        // 对端地址与设备IP2（端口IP+设备管理IP）匹配

        for (String devIp : devIps) {
            for (String peerIp : peerIps) {
                PhySnmpData phySnmpData = snmpMap.get(devIp + "_" + peerIp + "_" + sourceId);
                if (ObjectUtils.isEmpty(phySnmpData)) {
                    phySnmpData = snmpMap.get(devIp + "_" + peerIp + "_" + targetId);
                }
                if (!ObjectUtils.isEmpty(phySnmpData)) {
                    phySnmpData.setDevPortId(getPortId(devIp, devPortDataMap));
                    phySnmpData.setPeerIdPortId(getPortId(peerIp, peerPortDataMap));
                    snmpTask.add(phySnmpData);
                }
            }
        }

        String fDevIp = null;
        String fPeerIp = null;
        String fSrcIp = null;
        Integer devPortId = null;
        Integer peerIdPortId = null;
        if (!ObjectUtils.isEmpty(snmpTask)) {
            isSucceed = 1;
        }
        if (isSucceed == 0) {
            // 反向
            for (String devIp : peerIps) {
                for (String peerIp : devIps) {
                    PhySnmpData phySnmpData = snmpMap.get(devIp + "_" + peerIp + "_" + sourceId);
                    if (ObjectUtils.isEmpty(phySnmpData)) {
                        phySnmpData = snmpMap.get(devIp + "_" + peerIp + "_" + targetId);
                    }
                    if (!ObjectUtils.isEmpty(phySnmpData)) {
                        phySnmpData.setPeerIdPortId(getPortId(devIp, peerPortDataMap));
                        phySnmpData.setDevPortId(getPortId(peerIp, devPortDataMap));
                        snmpTask.add(phySnmpData);
                    }
                }
            }


            if (!ObjectUtils.isEmpty(snmpTask)) {
                isSucceed = 1;
            }
        }
        // 中继匹配成功
        if (isSucceed == 1) {
            logger.info("-----中继匹配成功：-----");
            // 筛选链路，查询频率最小的链路
            String finalRepeatId = null;
            // 中继任务列表
            Set<Integer> repeatIds = snmpTask.stream().map(PhySnmpData::getRepeatId).collect(Collectors.toSet());
            List<PhySnmpData> snmpFres = new LinkedList<>();
            // 拿到中继任务频率
            for (Integer repeatId : repeatIds) {
                PhySnmpData phySnmpData = snmpFreMap.get(repeatId);
                if (ObjectUtils.isEmpty(phySnmpData)) {
                    continue;
                }
                PhySnmpData phySnmpData2 = snmpFreMap.get(repeatId);
                PhySnmpData phySnmpData1 = snmpTask.stream().filter(v -> v.getRepeatId().equals(repeatId)).collect(Collectors.toList()).get(0);
                phySnmpData2.setDevIp(phySnmpData1.getDevIp());
                phySnmpData2.setDestIp(phySnmpData1.getDestIp());
                phySnmpData2.setSrcIp(phySnmpData1.getSrcIp());
                phySnmpData2.setDevPortId(phySnmpData1.getDevPortId());
                phySnmpData2.setPeerIdPortId(phySnmpData1.getPeerIdPortId());
                snmpFres.add(phySnmpData2);
            }
//            Integer repeatId = phyLinkDataReportDao.getSnmpRepeat(repeatIds, null);
            if (!ObjectUtils.isEmpty(snmpFres)) {
                //  取频率最小，时间最近的一条节点对
//                snmpFres.sort(Comparator.comparing(PhySnmpData::getRate)
//                        .thenComparing(Comparator.comparing(PhySnmpData::getCreateTime).reversed()));

                //  取频率最小，时间最早的数据
                snmpFres.sort(Comparator.comparing(PhySnmpData::getRate)
                        .thenComparing(PhySnmpData::getCreateTime));
                PhySnmpData phySnmpData1 = snmpFres.get(0);
                fDevIp = phySnmpData1.getDevIp();
                fPeerIp = phySnmpData1.getDestIp();
                fSrcIp = phySnmpData1.getSrcIp();
                devPortId = phySnmpData1.getDevPortId();
                peerIdPortId = phySnmpData1.getPeerIdPortId();
                finalRepeatId = String.valueOf(phySnmpData1.getRepeatId());
            }
            if (!ObjectUtils.isEmpty(finalRepeatId)) {
                // 拿routeId
                String routeId = phyLinkDataReportDao.getRouteId(1, finalRepeatId);
                if (!ObjectUtils.isEmpty(routeId)) {
                    // 算表名 repeatId routeId 1
                    String tableName = DynamicTableContext.genTraceDataTableName(Integer.parseInt(finalRepeatId), Integer.parseInt(routeId), 1);
                    // 查询时延、丢包数据
                    logger.info("-----tableName：-----" + tableName);
                    LinkDataTwo routeData = phyLinkDataReportClickDao.getRouteData(tableName, routeId, fDevIp, fPeerIp, queryDelayLossStartTimeLong, queryDelayLossEndTimeLong);
                    linkData.setCurrentNodeIp(fSrcIp);
                    linkData.setNextNodeIp(fPeerIp);
                    linkData.setRouteId(Integer.valueOf(routeId));
                    linkData.setRouteType("1");
                    // 添加接口Id
                    linkData.setDevPortId(devPortId);
                    linkData.setPeerIdPortId(peerIdPortId);
                    if (!ObjectUtils.isEmpty(routeData)) {
                        if (StringUtils.isBlank(routeData.getDelay())) {
                            linkData.setDelay("--");
                        } else {
                            linkData.setDelay("-1".equals(routeData.getDelay()) ? "--" : new BigDecimal(routeData.getDelay()).setScale(2, RoundingMode.HALF_UP).toString());
                        }

                        if (StringUtils.isBlank(routeData.getLoseRate())) {
                            linkData.setLoseRate("--");
                        } else {
                            linkData.setLoseRate(new BigDecimal(routeData.getLoseRate()).setScale(2, RoundingMode.HALF_UP).toString());
                        }

//                    linkData.setDelay("-1".equals(routeData.getDelay()) ? "--" : new BigDecimal(routeData.getDelay()).setScale(2, RoundingMode.HALF_UP).toString());
//                    linkData.setLoseRate(new BigDecimal(routeData.getLoseRate()).setScale(2, RoundingMode.HALF_UP).toString());
                    }
                }
            }
        }
        // 中继未匹配，查询拨测信息
        if (isSucceed == 0) {
            if (ObjectUtils.isEmpty(probeIdMap)) {
                // 没有探针直接跳过
                logger.error("没有配置设备映射探针的数据");
                return linkData;
            }
            // 查询拨测 正匹配
            logger.info("-----拨测匹配成功：-----");
            // 拨测链路集合
            Map<String, List<ProbeDatas>> map = new LinkedHashMap<>();
            // 拨测匹配列表
            List<ProbeDatas> matchObjs = new LinkedList<>();
            // 本端设备探针列表
            String probeIds = probeIdMap.get(sourceId);
            List<ProbeDatas> linkDatas = new LinkedList<>();
            if (!ObjectUtils.isEmpty(probeIds)) {
                String[] probeIdStrs = probeIds.split(",");
                for (String probeId : probeIdStrs) {
                    // 拿到该设备探针下的节点链路
                    List<ProbeDatas> probeDatas = probeMap.get(probeId);
                    if (!ObjectUtils.isEmpty(probeDatas)) {
                        linkDatas.addAll(probeDatas);
                    }
                }
                // 遍历该设备的节点链路，匹配拨测链路
                for (ProbeDatas data : linkDatas) {
                    String currentnodeip = data.getCurrentNodeIp();
                    String nextnodeip = data.getNextNodeIp();
                    // 该设备的链路节点列表
                    String key = currentnodeip + "_" + nextnodeip;
                    map.putIfAbsent(key, Lists.newLinkedList());
                    map.get(key).add(data);
                }
                // 用devIp-peerIp正匹配
                for (String devIp : devIps) {
                    for (String peerIp : peerIps) {

                        String key = devIp + "_" + peerIp;
                        List<ProbeDatas> stringMap = map.get(key);
                        if (!ObjectUtils.isEmpty(stringMap)) {
                            Integer portId = getPortId(devIp, devPortDataMap);
                            Integer peerId = getPortId(peerIp, peerPortDataMap);
                            stringMap.forEach(probeDatas -> {
                                probeDatas.setDevPortId(portId);
                                probeDatas.setPeerIdPortId(peerId);
                            });
                            // 匹配成功
                            matchObjs.addAll(stringMap);
                        }
                    }
                }
//                if (matchObjs.size() == 0) {
                // 反匹配
                for (String devIp : peerIps) {
                    for (String peerIp : devIps) {
                        String key = devIp + "_" + peerIp;
                        List<ProbeDatas> stringMap = map.get(key);
                        if (!ObjectUtils.isEmpty(stringMap)) {
                            // 匹配成功
                            Integer peerId = getPortId(devIp, peerPortDataMap);
                            Integer portId = getPortId(peerIp, devPortDataMap);
                            stringMap.forEach(probeDatas -> {
                                probeDatas.setDevPortId(portId);
                                probeDatas.setPeerIdPortId(peerId);
                            });
                            matchObjs.addAll(stringMap);
                        }
                    }
                }
//                }
            } else {
                // 对端设备探针
                String probeIds2 = probeIdMap.get(targetId);
                List<ProbeDatas> linkDatas2 = new LinkedList<>();
                if (!ObjectUtils.isEmpty(probeIds2)) {
                    String[] probeIds2Strs = probeIds2.split(",");
                    for (String probeId2 : probeIds2Strs) {
                        // 拿到该设备探针下的节点链路
                        List<ProbeDatas> probeDatas = probeMap.get(probeId2);
                        if (!ObjectUtils.isEmpty(probeDatas)) {
                            linkDatas2.addAll(probeDatas);
                        }
                    }
                    // 拿到该设备探针下的节点链路
                    for (ProbeDatas data : linkDatas2) {
                        String currentnodeip = String.valueOf(data.getCurrentNodeIp());
                        String nextnodeip = String.valueOf(data.getNextNodeIp());
                        String key = currentnodeip + "_" + nextnodeip;
                        map.putIfAbsent(key, Lists.newLinkedList());
                        map.get(key).add(data);
                    }
                    // 正匹配
                    for (String devIp : peerIps) {
                        for (String peerIp : devIps) {
                            String key = devIp + "_" + peerIp;
                            List<ProbeDatas> stringMap = map.get(key);
                            if (!ObjectUtils.isEmpty(stringMap)) {
                                // 匹配成功
                                Integer peerId = getPortId(devIp, peerPortDataMap);
                                Integer portId = getPortId(peerIp, devPortDataMap);
                                stringMap.forEach(probeDatas -> {
                                    probeDatas.setDevPortId(portId);
                                    probeDatas.setPeerIdPortId(peerId);
                                });
                                matchObjs.addAll(stringMap);
                            }
                        }
                    }
//                    if (matchObjs.size() == 0) {
                    // 反匹配
                    for (String devIp : devIps) {
                        for (String peerIp : peerIps) {
                            String key = devIp + "_" + peerIp;
                            List<ProbeDatas> stringMap = map.get(key);
                            if (!ObjectUtils.isEmpty(stringMap)) {
                                // 匹配成功
                                Integer portId = getPortId(devIp, devPortDataMap);
                                Integer peerId = getPortId(peerIp, peerPortDataMap);
                                stringMap.forEach(probeDatas -> {
                                    probeDatas.setDevPortId(portId);
                                    probeDatas.setPeerIdPortId(peerId);
                                });
                                matchObjs.addAll(stringMap);
                            }
                        }
                    }
//                    }
                } else {
                    // 没有探针则直接返回
                    return linkData;
                }
            }
            logger.info("-----拨测数据：-----" + matchObjs);
            // 查询频率最小且时间最近的一条拨测数据
            List<ProbeDatas> objects = new LinkedList<>();
            if (!ObjectUtils.isEmpty(matchObjs)) {
                logger.info("-----srcIp：-----" + srcPortIp + ",匹配到的数据：" + JSONObject.toJSONString(matchObjs));
                //在这里进行重新匹配
                List<String> srcPortIpList = new LinkedList<>();
                List<String> destPortIpList = new LinkedList<>();
                if (srcPortIp != null) {
                    srcPortIpList = Arrays.asList(srcPortIp.split(";"));
                }
                if (destPortIp != null) {
                    destPortIpList = Arrays.asList(destPortIp.split(";"));
                }

                List<ProbeDatas> matchObjs2 = new ArrayList<>();
                for (ProbeDatas matchObj : matchObjs) {
                    if (srcPortIpList.contains(matchObj.getCurrentNodeIp()) || srcPortIpList.contains(matchObj.getNextNodeIp()) || destPortIpList.contains(matchObj.getCurrentNodeIp()) || destPortIpList.contains(matchObj.getNextNodeIp())) {
                        matchObjs2.add(matchObj);
                    }
                }
                logger.info("-----srcIp：-----" + srcPortIp + ",匹配到的数据2：" + JSONObject.toJSONString(matchObjs2));
                if (!matchObjs2.isEmpty()) {
                    matchObjs = matchObjs2;
                }
                matchObjs = matchObjs.stream().filter(distinctByKey(ProbeDatas::getRouteId)).collect(Collectors.toList());
                // 遍历该设备所有匹配成功的节点对
                for (ProbeDatas speculateDatum : matchObjs) {
                    String routeid = String.valueOf(speculateDatum.getRouteId());
                    String bizdataid = String.valueOf(speculateDatum.getBizDataId());
                    String currentnodeip = String.valueOf(speculateDatum.getCurrentNodeIp());
                    String nextnodeip = String.valueOf(speculateDatum.getNextNodeIp());

                    Object val = datas.get(routeid + "_" + bizdataid);
                    if (val != null) {
                        Integer frequency = MapUtil.getInt((Map) val, "dialinterval", -1);
                        Date crt = MapUtil.getDate((Map) val, "createtime");
                        fDevIp = currentnodeip;
                        fPeerIp = nextnodeip;
                        Long routeId = Long.valueOf(routeid);
                        Integer bizDataId = Integer.valueOf(bizdataid);
                        ProbeDatas probeDatas1 = new ProbeDatas();
                        probeDatas1.setRouteId(Math.toIntExact(routeId));
                        probeDatas1.setBizDataId(bizDataId);
                        probeDatas1.setFrequency(frequency);
                        probeDatas1.setCrt(crt);
                        probeDatas1.setDevPortId(speculateDatum.getDevPortId());
                        probeDatas1.setPeerIdPortId(speculateDatum.getPeerIdPortId());
                        objects.add(probeDatas1);
                    }
                }
                // 取频率最小，时间最近的一条节点对
//                objects.sort(Comparator.comparing(ProbeDatas::getFrequency)
//                        .thenComparing(Comparator.comparing(ProbeDatas::getCrt).reversed()));

                // 取频率最小，时间最早的数据
                objects.sort(Comparator.comparing(ProbeDatas::getFrequency)
                        .thenComparing(ProbeDatas::getCrt));
            }
            if (!ObjectUtils.isEmpty(objects)) {

                ProbeDatas probeDatas = objects.get(0);
                Integer bizDataId = probeDatas.getBizDataId();
                Integer routeId1 = probeDatas.getRouteId();
                String tableName = DynamicTableContext.genTraceDataTableName(bizDataId, routeId1, 0);
                // 查询时延、丢包数据
                LinkDataTwo routeData = phyLinkDataReportClickDao.getRouteData(tableName, routeId1 + "", fDevIp, fPeerIp, queryDelayLossStartTimeLong, queryDelayLossEndTimeLong);
                linkData.setCurrentNodeIp(fDevIp);
                linkData.setNextNodeIp(fPeerIp);
                linkData.setRouteId(Math.toIntExact(routeId1));
                linkData.setRouteType("0");
                linkData.setDevPortId(probeDatas.getDevPortId());
                linkData.setPeerIdPortId(probeDatas.getPeerIdPortId());
                if (!ObjectUtils.isEmpty(routeData)) {

                    if (StringUtils.isBlank(routeData.getDelay())) {
                        linkData.setDelay("--");
                    } else {
                        linkData.setDelay("-1".equals(routeData.getDelay()) ? "--" : new BigDecimal(routeData.getDelay()).setScale(2, RoundingMode.HALF_UP).toString());
                    }

                    if (StringUtils.isBlank(routeData.getLoseRate())) {
                        linkData.setLoseRate("--");
                    } else {
                        linkData.setLoseRate(new BigDecimal(routeData.getLoseRate()).setScale(2, RoundingMode.HALF_UP).toString());
                    }


//                    linkData.setDelay("-1".equals(routeData.getDelay()) ? "--" : new BigDecimal(routeData.getDelay()).setScale(2, RoundingMode.HALF_UP).toString());
//                    linkData.setLoseRate(new BigDecimal(routeData.getLoseRate()).setScale(2, RoundingMode.HALF_UP).toString());
                }
            }
        }
        return linkData;
    }

    private LinkDataTwo getSpecialLineInfo(String devIp, String peerIp, LinkDataTwo linkData,
                                           List<String> odevIps, List<String> opeerIps,
                                           List<Integer> orgIds, Map<String, Integer> specialDataMap) {
        if (ObjectUtils.isEmpty(linkData)) {
            linkData = new LinkDataTwo();
        }

        // 本端接口IP
        List<String> devIps = new ArrayList<>(50);
        // 对端接口IP
        List<String> peerIps = new ArrayList<>(50);
        if (odevIps != null) {
            for (String odevIp : odevIps) {
                devIps.addAll(Arrays.asList(odevIp.split(";")));
            }
        }

        if (opeerIps != null) {
            for (String odevIp : opeerIps) {
                peerIps.addAll(Arrays.asList(odevIp.split(";")));
            }
        }


        // 判断两个设备IP上面，是否存在 专线的AzIP
        // 正向
        boolean isSpecialLine = false;
        for (String devIpTemp : devIps) {
            for (String peerIpTemp : peerIps) {
                boolean existsFlag = existsSpecialData(orgIds, specialDataMap, devIpTemp, peerIpTemp);
                if (existsFlag) {
                    isSpecialLine = true;
                    break;
                }
            }
            if (isSpecialLine) {
                break;
            }
        }

        if (!isSpecialLine) {
            // 反向匹配
            for (String peerIpTemp : peerIps) {
                for (String devIpTemp : devIps) {
                    boolean existsFlag = existsSpecialData(orgIds, specialDataMap, peerIpTemp, devIpTemp);
                    if (existsFlag) {
                        isSpecialLine = true;
                        break;
                    }
                }
                if (isSpecialLine) {
                    break;
                }
            }
        }
        // 设置专线标志
        linkData.setIsSpecial(isSpecialLine ? 1 : 0);
        return linkData;
    }

    private boolean existsSpecialData(List<Integer> orgIds, Map<String, Integer> specialDataMap, String devIp, String peerIpTemp) {
        boolean isSpecialLine = false;
        for (Integer orgId : orgIds) {
            boolean b = specialDataMap.containsKey(orgId + "_" + devIp + "_" + peerIpTemp);
            if (!b) {
                b = specialDataMap.containsKey(orgId + "_" + peerIpTemp + "_" + devIp);
            }
            if (b) {
                isSpecialLine = true;
                break;
            }
        }
        return isSpecialLine;
    }


    private LinkDataTwo getFlowData(LinkDataTwo flowData, String flowFlag, String devPortId, String peerPortId, String sourceId, String targetId, Map<String, LinkDataTwo> allFlowDataMap) {
        Integer linkId = flowData.getLinkId();
        // 查询三个周期内的流量信息
//        Integer rate = phyLinkDataReportDao.getListByDevId(Integer.valueOf(sourceId));
//        if (rate == null) {
//            rate = 0;
//        }
//        flowData = phyLinkDataReportClickDao.getFlowData(devPortId, rate * 3);
        LinkDataTwo existFlowData = null != allFlowDataMap.get(devPortId) ? allFlowDataMap.get(devPortId) : null;
        if (ObjectUtils.isEmpty(existFlowData)) {
            // 本端流量为空，查询对端
            // 查询三个周期内的流量信息
//            rate = phyLinkDataReportDao.getListByDevId(Integer.valueOf(targetId));
//            if (rate == null) {
//                rate = 0;
//            }
//            flowData = phyLinkDataReportClickDao.getFlowData(peerPortId, rate * 3);
//            LinkDataTwo existFlowDataTwo = null != allFlowDataMap.get(devPortId) ? allFlowDataMap.get(devPortId) : null;
            LinkDataTwo existFlowDataTwo = null != allFlowDataMap.get(peerPortId) ? allFlowDataMap.get(peerPortId) : null;
            if (!ObjectUtils.isEmpty(existFlowDataTwo)) {
                BigDecimal flowIntoSpeed = new BigDecimal(existFlowDataTwo.getFlowIntoSpeed());
                BigDecimal flowOutSpeed = new BigDecimal(existFlowDataTwo.getFlowOutSpeed());
                flowData.setFlowIntoSpeed(flowIntoSpeed.compareTo(BigDecimal.ZERO) < 0 ? "--" : existFlowDataTwo.getFlowIntoSpeed());
                flowData.setFlowOutSpeed(flowOutSpeed.compareTo(BigDecimal.ZERO) < 0 ? "--" : existFlowDataTwo.getFlowOutSpeed());
                flowFlag = "1";
                flowData.setFlowDirection(flowFlag);
                flowData.setLinkId(linkId);
                flowData.setMatchPort(peerPortId);
            } else {
                flowData.setFlowIntoSpeed("--");
                flowData.setFlowOutSpeed("--");
            }
        } else {
            BigDecimal flowIntoSpeed = new BigDecimal(existFlowData.getFlowIntoSpeed());
            BigDecimal flowOutSpeed = new BigDecimal(existFlowData.getFlowOutSpeed());
            flowData.setFlowIntoSpeed(flowIntoSpeed.compareTo(BigDecimal.ZERO) < 0 ? "--" : existFlowData.getFlowIntoSpeed());
            flowData.setFlowOutSpeed(flowOutSpeed.compareTo(BigDecimal.ZERO) < 0 ? "--" : existFlowData.getFlowOutSpeed());
            flowData.setFlowDirection(flowFlag);
            flowData.setLinkId(linkId);
            flowData.setMatchPort(devPortId);
        }
        return flowData;
    }


    private static class IpObject {

    }
}
