package com.wdkj.plugs.extract.dao.click;

import com.wdkj.plugs.model.po.DelayData;
import com.wdkj.plugs.model.po.DelayLossData;
import com.wdkj.plugs.model.po.ExtractPathData;
import com.wdkj.plugs.model.vo.VRunTime;
import org.apache.ibatis.annotations.Param;
import org.mapstruct.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @ClassName ExtractSnmpClickDao
 * @Description TODO
 * @Author Mr.xie
 * @Date 2021/10/13 17:01
 */
@Mapper
@Repository
public interface IExtractPathClickDao {
    List<VRunTime> getRunTimeList(@Param("startTimeSecond")Long startTimeSecond, @Param("endTimeSecond") Long endTimeSecond);

    List<VRunTime> getRunTimeListByLink(@Param("startTimeSecond")Long startTimeSecond, @Param("endTimeSecond") Long endTimeSecond,@Param("linkIds") List<Integer> linkIds);

    void save(List<ExtractPathData> list);

    List<VRunTime> getRepairRunTimeList(@Param("startTimeSecond")Long startTimeSecond, @Param("endTimeSecond") Long endTimeSecond);

    DelayLossData getPingDelay(@Param("pingTable") String pingTable, @Param("linkId") Integer linkId,@Param("startTimeSecond") Long startTimeSecond, @Param("endTimeSecond") Long endTimeSecond);

    DelayLossData getDatavLoss(@Param("tableName") String tableName, @Param("linkId") Integer linkId, @Param("destIp") String destIp, @Param("startTimeSecond") Long startTimeSecond, @Param("endTimeSecond") Long endTimeSecond);

    DelayLossData getDelayLoss(@Param("tableName") String tableName, @Param("linkId") Integer linkId, @Param("destIp") String destIp, @Param("startTimeSecond") Long startTimeSecond, @Param("endTimeSecond") Long endTimeSecond);

    List<DelayData> getDelayList(@Param("tableName") String tableName, @Param("linkIds") List<Integer> linkIds, @Param("destIps") List<String> destIps, @Param("startTimeSecond") Long startTimeSecond, @Param("endTimeSecond") Long endTimeSecond);
}
