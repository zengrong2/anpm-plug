package com.wdkj.plugs.extract.schedule;

import com.wdkj.plugs.extract.service.ISpecialDataService;
import com.wdkj.plugs.systemlog.service.ISystemLogService;
import com.wdkj.plugs.utils.enu.LogLevelEnum;
import com.wdkj.plugs.utils.enu.LogTypeEnum;
import com.wdkj.plugs.utils.enu.ServiceTypeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * @ClassName UpdateSnmpRepeatSchedule
 * @Description TODO
 * @Author Mr.xie
 * @Date 2021/5/26 9:49
 */
@Component
public class SpecialDataSchedule {
    /**
     * 执行状态,0.未执行,1.正在执行
     */
    private static Integer IS_EXECUTE = 0;

    private static Logger logger = LoggerFactory.getLogger(SpecialDataSchedule.class);

    @Autowired
    private ISpecialDataService specialDataService;
    @Autowired
    private ISystemLogService systemLogService;

    @Scheduled(cron = "0 3/5 * * * ? ")
    @Async
//    @Scheduled(cron = "0/30 * * * * ? ")
    public void specialDataSchedule(){
        try {
            if (IS_EXECUTE == 1){
                logger.error("专线资料关联任务编号任务正在执行，本次任务中止！");
            }
            IS_EXECUTE = 1;
            logger.info("-----专线资料关联任务编号开始-----");
            specialDataService.updatesJob();
            logger.info("-----专线资料关联任务编号结束-----");
            IS_EXECUTE = 0;
        }catch (Exception e){
            IS_EXECUTE = 0;
            logger.error("专线资料关联任务编号失败 ， error=>",e);
            systemLogService.saveLog(LogLevelEnum.LEVEL1.code(),e.getLocalizedMessage(), ServiceTypeEnum.EXTRACT.lable(), LogTypeEnum.LOG_TYPE_ERROR.lable(),"专线资料关联任务编号", this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName());
        }finally {
            IS_EXECUTE = 0;
        }
    }
}
