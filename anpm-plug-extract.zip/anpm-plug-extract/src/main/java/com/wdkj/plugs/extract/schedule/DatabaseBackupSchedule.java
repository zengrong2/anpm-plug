package com.wdkj.plugs.extract.schedule;

import com.wdkj.plugs.extract.service.IDatabaseBackupService;
import com.wdkj.plugs.extract.service.IIndexSyncService;
import com.wdkj.plugs.model.vo.BackupDefaultValue;
import com.wdkj.plugs.systemlog.service.ISystemLogService;
import com.wdkj.plugs.utils.constant.BaseConstant;
import com.wdkj.plugs.utils.enu.LogLevelEnum;
import com.wdkj.plugs.utils.enu.LogTypeEnum;
import com.wdkj.plugs.utils.enu.ServiceTypeEnum;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @ClassName DatabaseBackupSchedule
 * @Description TODO
 * @Author Mr.xie
 * @Date 2021/10/19 18:07
 */
@Component
public class DatabaseBackupSchedule {
    private static Logger log = LoggerFactory.getLogger(DatabaseBackupSchedule.class);

    private final static String DATABASE_BACKUP = "database_backup";

    private static final String AUTO_BACK_FLAG = "AUTO_BACK_FLAG";
    private static final String BACK_CYCLE = "BACK_CYCLE";
    private static final String BACK_TIME = "BACK_TIME";
    private static Integer EXECUTION = 0 ;
    private static final String BACK_FIRST_DATE = "BACK_FIRST_DATE";
    private static final String ENABLE = "ENABLE";
    @Autowired
    private IIndexSyncService indexSyncService;
    @Autowired
    private IDatabaseBackupService databaseBackupService;
    @Autowired
    private ISystemLogService systemLogService;

    @Scheduled(cron = "0 0/1 * * * ?")
    @Async
    public void execute() {
        if(EXECUTION==1){
            log.info("--------- path-数据库自动备份任务正在执行，此次任务结束----------");
            return;
        }
        EXECUTION= 1;
        log.info("---------start 数据库自动备份任务开始 Job----------"+ System.currentTimeMillis());
        try {
            LocalDateTime now = LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES);
            DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            boolean isFirstExtract = false;
            // 获取数据库自动备份最后一次执行的时间
            LocalDateTime lastTimeDate = null ;
            String lastTime = indexSyncService.getLastDateByName(DATABASE_BACKUP);
            if (StringUtils.isBlank(lastTime)) {
                isFirstExtract = true;
            } else {
                lastTimeDate = LocalDateTime.parse(lastTime, df);
            }
            //获取自动备份默认值
            List<BackupDefaultValue> list = databaseBackupService.getBackupDefaultValue();
            Map<String, String> map = new HashMap<>(16);
            for (BackupDefaultValue defaultValue : list) {
                map.put(defaultValue.getKey(), defaultValue.getValue());
            }
            //判断是否启动自动备份
            String autoBackFlag = map.get(AUTO_BACK_FLAG);
            if (ENABLE.equals(autoBackFlag)){
                //判断当前时间是否满足
                String backDataTime = map.get(BACK_FIRST_DATE) + " " + map.get(BACK_TIME);
                LocalDateTime firstBackTime = LocalDateTime.parse(backDataTime, df);
                boolean flag = isFirstExtract
                        || !(lastTimeDate.isBefore(firstBackTime.plusMinutes(BaseConstant.FIGURE_5))
                        && lastTimeDate.isAfter(firstBackTime.minusMinutes(BaseConstant.FIGURE_5)));
                if ((now.isBefore(firstBackTime.plusMinutes(BaseConstant.FIGURE_5)) && now.isAfter(firstBackTime.minusMinutes(BaseConstant.FIGURE_5)) && flag)
                ){
                    //判断是否远程备份
                    databaseBackupService.dataSourceBackup(now,isFirstExtract,map);
                }else if (now.isAfter(firstBackTime)){
                    //表示已经过了备份日期,加上备份周期
                    LocalDateTime startBackTime;
                    while (true){
                        startBackTime = firstBackTime.plusDays(Long.parseLong(map.get(BACK_CYCLE)));
                        boolean flag1 = isFirstExtract || !(lastTimeDate.isBefore(startBackTime.plusMinutes(5)) && lastTimeDate.isAfter(startBackTime.minusMinutes(5)));
                        if (startBackTime.isAfter(now)){
                            break;
                        }else if ((now.isBefore(startBackTime.plusMinutes(5)) && now.isAfter(startBackTime.minusMinutes(5)) && flag1)){
                            databaseBackupService.dataSourceBackup(now,isFirstExtract,map);
                            break;
                        }
                        firstBackTime = startBackTime;
                    }
                }
            }else {
                log.info("-----backup-----未启用自动备份！----------");
            }
            log.info("-----backup-----End 数据库自动备份任务结束 Job----------");
        } catch (Exception e) {
            log.error("-backup-数据库自动备份任务出错:" + e.getMessage(), e);
            systemLogService.saveLog(LogLevelEnum.LEVEL1.code(),e.getMessage(), ServiceTypeEnum.EXTRACT.lable(), LogTypeEnum.LOG_TYPE_ERROR.lable(),"backup-数据库自动备份任务", this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName());
        } finally {
            EXECUTION = 0 ;
        }
    }
}
