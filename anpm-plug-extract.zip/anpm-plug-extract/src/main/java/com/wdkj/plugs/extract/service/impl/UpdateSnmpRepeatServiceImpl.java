package com.wdkj.plugs.extract.service.impl;

import com.wdkj.plugs.extract.dao.mysql.IUpdateSnmpRepeatDao;
import com.wdkj.plugs.extract.service.IUpdateSnmpRepeatService;
import com.wdkj.plugs.model.po.SnmpRepeat;
import com.wdkj.plugs.model.po.SpecialData;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName UpdateSnmpRepeatServiceImpl
 * @Description TODO
 * @Author Mr.xie
 * @Date 2021/5/26 10:00
 */
@Service
@Transactional(rollbackFor = SQLException.class)
public class UpdateSnmpRepeatServiceImpl implements IUpdateSnmpRepeatService {

    @Autowired
    private IUpdateSnmpRepeatDao updateSnmpRepeatDao;

    @Override
    public void updateSnmpRepeat() {
        //查询专线
        List<SpecialData> specialDataList = updateSnmpRepeatDao.getSpecialData();
        //查询中继
        List<SnmpRepeat> snmpRepeats = updateSnmpRepeatDao.getSnmpRepeat();
        List<SnmpRepeat> list = new ArrayList<>();
        for (SpecialData specialData : specialDataList) {
            for (SnmpRepeat snmpRepeat : snmpRepeats) {
                if (specialData==null||snmpRepeat==null){
                    continue;
                }
                String srcIp = snmpRepeat.getSrcIp();
                String destIp = snmpRepeat.getDestIp();
                String specialAIp = specialData.getSpecialAIp();
                String specialZIp = specialData.getSpecialZIp();
                if (StringUtils.isAllBlank(srcIp,destIp,specialAIp,specialZIp)){
                    continue;
                }
                boolean b = (srcIp.equals(specialAIp) &&
                        destIp.equals(specialZIp)) ||
                        (destIp.equals(specialAIp) &&
                                srcIp.equals(specialZIp));
                if (b){
                    snmpRepeat.setOperator(snmpRepeat.getOperator());
                    list.add(snmpRepeat);
                }
            }
        }
        if (list != null && list.size() > 0){
            for (SnmpRepeat snmpRepeat : list) {
                updateSnmpRepeatDao.updateSnmpRepeatOperator(snmpRepeat);

            }
        }
    }
}
