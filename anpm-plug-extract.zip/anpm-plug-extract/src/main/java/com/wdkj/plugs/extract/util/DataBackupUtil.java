package com.wdkj.plugs.extract.util;

import com.wdkj.plugs.exception.ParamException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * @ClassName DataBackupUtil
 * @Description TODO
 * @Author Mr.xie
 * @Date 2021/3/22 14:45
 */
public class DataBackupUtil {

    private static Logger logger = LoggerFactory.getLogger(DataBackupUtil.class);

    /**
     * 备份数据库数据
     * @param ip
     * @param userName
     * @param password
     * @param databaseName
     * @param savePath
     * @param fileName
     * @Return void
     * @date 2021/3/25
     */
    public static void backup(String ip, String userName, String password, String[] databaseName, String savePath, String fileName) {
        BufferedReader bufrIn = null;
        BufferedReader bufrError = null;
        try {
            String[] command = { "/bin/sh", "-c", "mkdir -p "+savePath+"; mysqldump -h "+ip+" -u "+userName+" -p"+password+"  "+databaseName[0]+" > "+savePath+"/"+databaseName[0]+".sql; mysqldump -h "+ip+" -u "+userName+" -p"+password+" "+databaseName[1]+" > "+savePath+"/"+databaseName[1]+".sql; zip -pj "+savePath+"/"+fileName+" "+savePath+"/*.sql " };
            Process process = Runtime.getRuntime().exec(command );
            for (String s : command) {
                logger.info("命令："+s);
            }
            process.waitFor();
            // 获取命令执行结果, 有两个结果: 正常的输出 和 错误的输出（PS: 子进程的输出就是主进程的输入）
            bufrIn = new BufferedReader(new InputStreamReader(process.getInputStream(), "UTF-8"));
            bufrError = new BufferedReader(new InputStreamReader(process.getErrorStream(), "UTF-8"));
            // 读取输出
            String line;
            StringBuffer sb = new StringBuffer();
            while ((line = bufrIn.readLine()) != null) {
                sb.append(line).append('\n');
            }
            while ((line = bufrError.readLine()) != null) {
                sb.append(line).append('\n');
            }
            logger.info(sb.toString());
            process.destroy();
        }catch (Exception e){
            throw new ParamException("备份失败");
        }finally {
            close(bufrIn,bufrError);
        }
    }

    /**
     * 获取进程pid
     * @param name 进程名称
     * @Return java.util.List<java.lang.String>
     * @date 2021/3/25
     */
    public static List<String> getPIDList(String name){
        BufferedReader reader =null;
        List<String> list = new ArrayList<>();
        try{
            String[] command = { "/bin/sh", "-c", "ps -ef | grep \""+name+"\" | grep -v grep | awk '{print $2}'"};
            //显示所有进程
            Process process = Runtime.getRuntime().exec(command);
            reader = new BufferedReader(new InputStreamReader(process.getInputStream(), "UTF-8"));
            String line = null;
            while((line = reader.readLine())!=null){
                list.add(line);
                logger.info("进程PID:"+line);
            }
            process.destroy();
        }catch(Exception e){
            throw new ParamException("获取"+name+"进程失败");
        }finally{
            close(reader);
        }
        return list;
    }
    /**
     * kill进程
     * @param procList
     * @Return void
     * @date 2021/3/25
     */
    public static void killLinuxProcess(List<String> procList){
        BufferedReader errorReader =null;
        try{
            if (procList == null || procList.size()==0){
                return;
            }
            //显示所有进程
            StringBuffer sb = new StringBuffer();
            for (String pid : procList) {
                sb.append("kill -9 ").append(pid).append("; ");
            }
            String[] command = { "/bin/sh", "-c", sb.toString()};
            logger.info(sb.toString());
            Process process = Runtime.getRuntime().exec(command);
            errorReader = new BufferedReader(new InputStreamReader(process.getErrorStream(), "UTF-8"));
            String line = null;
            sb = new StringBuffer();
            while ((line = errorReader.readLine()) != null) {
                sb.append(line).append('\n');
            }
            logger.info(sb.toString());
        }catch(Exception e){
            throw new ParamException("kill:"+procList+"进程失败");
        }finally{
            close(errorReader);
        }
    }

    /**
     * 多个关闭的简单方法
     */
    public static void close(Closeable... closeables) {
        // 空直接返回
        if (closeables == null || closeables.length == 0) {
            return;
        }
        // 循环关闭流
        for (Closeable closeable : closeables) {
            try {
                if (Objects.nonNull(closeable)) {
                    closeable.close();
                }
            } catch (Exception e) {
                logger.error("关闭流异常：{}", e);
            }
        }
    }
    public static String  getDate(){
        SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");//设置日期格式
        return df.format(new Date());// new Date()为获取当前系统时间
    }



}
