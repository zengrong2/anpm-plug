package com.wdkj.plugs.extract.service;


public interface ICheckReportTimeService {
    void checkReportTime();
}
