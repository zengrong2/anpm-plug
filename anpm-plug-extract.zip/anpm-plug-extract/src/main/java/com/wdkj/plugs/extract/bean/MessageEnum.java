package com.wdkj.plugs.extract.bean;


import com.wdkj.plugs.utils.enu.EnumTypeHandleUtils;

/**
 * 作者:wangqc<br/>
 * 1~100系统级别错误 例如:SYS_**<br/>
 */
public enum MessageEnum
{

	SUCCESS(1, "backup.success"), FAIL(2, "backup.operationFailed"), IS_EXIST(4, "backup.dataExists"), IS_NOT_EXIST(5, "backup.DataDoesNotExist"), LOGIN_NO(9, "backup.NotLoggedIn"),
	NO_PERMISSIONS(10, "backup.permissionDenied"), PARAMETER_ERROR(11, "backup.ParameterError"), TOKENID_IS_NULL(12,"backup.tokenIdIsEmpty"),ILLEGAL_OPT(13,"backup.IllegalOperation"),
	NO_FILE(14, "backup.NoFileUploaded"),DATA_REPEAT(15, "backup.DataDuplication"),EXEL_ERROR(16, "backup.PEDIEOA"),EXEL_FAIL(17, "backup.DNMTTPDTT"),
	PARAM_NODE_IP_ERROR(18, "backup.PENIMBP"),PARAM_BF_NODE_IP_ERROR(19, "backup.PETPNIMBP"),PARAM_LINK_ID_ERROR(20, "backup.PELIMBP"),
	PARAM_SEARCH_TIME_ERROR(21, "backup.PEQTMBP"),PARAM_SNMP_ERROR(22, "backup.PEWSMBT"),PARAM_CLASS_ERROR(23, "backup.PEQCE"),
	NO_TASK_ERROR(24, "backup.NoTasksAvailable"),NO_PROBE_ERROR(25, "backup.TheProbeDoes"),TASK_REPEAT_ERROR(26, "backup.TSTAE"),PROBE_IP_NULL(27, "backup.ProbeIpCannot"),
	COLLECTOR_IP_NULL(28, "backup.CICBE"),NAME_NOT_NULL(29, "backup.NameIsRequired"),ORGID_NOT_NULL(30, "backup.OICBE"),COLLECTOR_IP_REPEAT(31, "backup.TCIIDPRI"),
	NAME_REPEAT(32, "backup.TNIDPRI"),ID_NOT_NULL(33, "backup.idCannotBeEmpty"),DATA_IS_DELETE(34, "extract.DHBDOF"),TYPE_IS_NULL(35, "backup.TTPCBE"),
	GATHER_IS_NULL(36, "backup.TCNLE"),INTERFACE_IP_IS_NULL(37, "backup.SPICBE"),GETHER_HAS_TASK(38, "backup.OCWTAATBD"),
	START_IS_NOT_DELETE(39, "backup.SDCPTO"),START_IS_NOT_EDIT(40, "backup.ICBMISSATOF"),DATA_DELETEED(41,"backup.DataHasBeenDeleted"),NOT_DELETE_YOURSELF(42,"backup.Can'tDeleteMyself"),
	OFF_LINE(43, "backup.Offline"),NORMAL(44, "backup.normal"),OPT_ID_EMPTY(45, "backup.ODIIE"),ORG_IS_DELETE(47,"backup.TOHBDATOF"),OID_VALIDATION_ERROR(48,"backup.TIAOWTSNDAMPMI"),
	SNMP_TASK_VALIDATION_ERROR(49,"backup.UTSODICBR"),INVALID_DATA(50,"backup.TSDCIDPSA"),
	GET_LICENSE_ERROR(51,"backup.EIOLOF"),ANSIS_LICENSE_ERROR(52,"backup.LPEOF"),NO_LICENSE_ERROR(53,"backup.PUTLF"),
	LICENSE_TIME_EXPIRE(54,"backup.YLHEPCTA"),LICENSE_NUM_ERROR(55,"backup.TLBIIPCTA"),LICENSE_FILE_ERROR(56,"backup.TCOTLFIIPCTA"),
	GROUP_TASK_IS_NOT_DELETE(57, "backup.TGHATACBD"),TASK_OBJ_IS_DELETE(58, "backup.TTHBDACBA"),GROUP_IS_DELETE(59, "backup.TSGHBDACBA"),
	ADD_VIEW_NUM_ERROR(60, "backup.UT8VCBATTCO"),
	ERROR_DATA_SIZE(61, "backup.TAODITLIIRTBLT2"),
	CONNECT_ERROR(70, "backup.UTCTTCS"),

	/**
	 * 
	 */
	ACCOUNT_FREEZE(1001, "backup.AccountHasBeen"), ACCOUNT_ROLE_FREEZE(1002, "backup.RoleFrozen"), ACCOUNT_PASSWORD_EXPIRE(1003, "backup.TPHEPCTA"),
	ACCOUNT_PWD(1004, "backup.WUNOP"), ACCOUNT_NOT_EXIST(1005, "backup.AccountDoesNot"),ACCOUNT_PWD_GRADE(1006, "backup.PEAPTCACONLASSAIMT8CL"),

	ACCOUNT_PWD_NOTEQUAL(1007,"backup.TOPII"),ACCOUNT_PWD_NOT_NULL(1008, "backup.PCNBB"),ACCOUNT_NOT_ADMIN(1009,"backup.IYANASAYCOCYOP"),
	
	
	//用户不存在  原始密码不一致 非法操作
	/**
	 * 
	 */
	ORG_NOT_EXIST(1010, "backup.ODNE"),
	ORG_ID_IS_NULL(1011, "backup.OIIE"),
	ORG_NAME_IS_NULL(1013, "backup.ONIE"),
	ORG_NAME_EXIST(1014, "backup.BNAE"),
	ORG_CODE_EXIST(1015, "backup.BCAE"),
	ORG_SEQ_NUM(1016, "backup.TSNCBLT0"),
	ORG_EXIST_USER(1017, "backup.TAAUUTOATUNTBR"),
	
	

	
	/**
	 * 
	 */
	USER_NOT_EXIST(1020, "backup.UserDoesNotExist"),
	USER_EXIST(1021, "backup.UserAlreadyExists"),
	/**
	 * 
	 */
	USER_ACTIVE_STATUS_NO(1022, "backup.CCOAS"),
	
	/**
	 * 
	 */
	ROLE_NOT_EXIST(1030, "backup.roleDoesNotExist"),
	
	ROLE_ID_IS_NULL(1031, "backup.RoleIDIsEmpty"),
	ROLE_NAME_IS_NULL(1031, "backup.RoleNameIsEmpty"),
	ROLE_NOT_DELETE(1032, "backup.TRCBD"),
	ROLE_EXIST(1033, "backup.DCN"),
	//ROLE_NOT_DELETE(1034, "该角色不能删除")

	SYS_ERROR(10034,"backup.SystemException"),
	NO_SATISFIED_DATA(10035,"backup.NoMatchingData"),
	SNMP_TIME_PARAM_ERROR(10036,"backup.TQTPCBGT1H"),
	SNMP_TREND_TIME_PARAM_ERROR(10037,"backup.TQTPCBGT6D"),



	;

	
	
	

//	SYS_PARAMETER_ERROR(3, "参数错误"),
//	SYS_PARSE_POJO_ERROR(4, "解析POJO错误"),
//	SYS_NOT_EXIST_CLIENT(5, "不存在该类型客户"),
//	SYS_LOGIN_OK(6, "登录成功"),
//	SYS_USER_NO_EXIST(7, "用户不存在"),
//	SYS_OPERATION_IS_SUCCESS(8, "操作成功"),
//	SYS_LOGIN_NO(9, "未登录"),
//	SYS_NO_PERMISSIONS(10, "没有权限"),
//	SYS_ALARMCONFIG_EXIST(11, "该告警规则配置已经存在"),
//	SYS_NOT_EXIST_TYPE(12, "您没有该链路类型"),
//	SYS_USER_NAME_EXIST(13, "账号存在"), SYS_ROLE_NAME_EXIST(100, "角色已存在"),
//	SYS_USER_ACTIVE_STATUS_NO(14, "不能更改自己激活状态"),
//	SYS_UPDATE_SUCCESS(15, "密码更新成功"),
//
//	USER_LINK_TYPE_EXIST_NO(16, "客户不存在此链路类型"), 
//	IS_NOT_ADMIN(17, "您非超级管理员只能修改自己的密码"),
//	IP_IS_ERROR(18, "IP已经存在地址表内/IP地址无法识别");

	private String lable;
	private int code;

	private MessageEnum(int code, String lable)
	{
		this.lable = lable;
		this.code = code;
	}

	public static String lable(int value)
	{
		for (MessageEnum c : MessageEnum.values())
		{
			if (c.code() == value)
			{
				return EnumTypeHandleUtils.getMessage(c.lable);
			}
		}
		return null;
	}

	public static int code(String lable)
	{
		for (MessageEnum c : MessageEnum.values())
		{
			if (c.lable().equals(lable))
			{
				return c.code;
			}
		}
		return 0;
	}

	public String lable()
	{
		return lable;
	}

	public int code()
	{
		return code;
	}
}
