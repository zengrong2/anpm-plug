package com.wdkj.plugs.extract.web;

import com.wdkj.plugs.core.model.to.Result;
import com.wdkj.plugs.extract.schedule.ExtractSpecialSchedule;
import com.wdkj.plugs.utils.enu.MessageEnum;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Description:
 * Created by zoujian ON 2021/4/26.
 */
@RestController
@RequestMapping("/specialExtract")
public class SpecialExtractController {

    private static Logger logger = LoggerFactory.getLogger(SpecialExtractController.class);

    @Autowired
    private ExtractSpecialSchedule extractSpecialSchedule;

    @PostMapping("/doExtractSpecialData")
    @ApiOperation(value = "抽取专线数据", tags = "专线健康档案抽取", httpMethod = "POST")
    public Result<?> doExtractSpecialData() {
        try {
            extractSpecialSchedule.extractSpecialData();
            return new Result<>(MessageEnum.SUCCESS);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("抽取专线数据失败={}" , e.getMessage());
            return new Result<>(MessageEnum.FAIL,e.getMessage());
        }
    }

}
