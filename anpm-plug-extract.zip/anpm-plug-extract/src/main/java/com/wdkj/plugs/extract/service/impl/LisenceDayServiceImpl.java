package com.wdkj.plugs.extract.service.impl;

import com.wdkj.plugs.extract.dao.mysql.LisenceDayDao;
import com.wdkj.plugs.extract.dao.mysql.ReportDao;
import com.wdkj.plugs.extract.service.ICheckReportTimeService;
import com.wdkj.plugs.extract.service.ILisenceDayService;
import com.wdkj.plugs.model.po.CheckReportData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service

public class LisenceDayServiceImpl implements ILisenceDayService {

	private static Logger log = LoggerFactory.getLogger(LisenceDayServiceImpl.class);

	@Autowired
	private LisenceDayDao lisenceDayDao;

	private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

	@Override
	@Transactional(rollbackFor = Exception.class)
	public void checkLicence() {
		log.info("Lisence Day -----");
		//获取当前年月日
		String curDate = sdf.format(new Date());
		//通过当前年月日查询数据库是否已有数据
		Integer count = lisenceDayDao.selectByDay(curDate);
		if(count == 0){
			// 插入记录
			lisenceDayDao.insertLisenceDay();
		}
	}
}