package com.wdkj.plugs.extract.service.impl;

import com.wdkj.plugs.extract.dao.mysql.ILanguageDao;
import com.wdkj.plugs.extract.service.LanguageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;

import java.util.Locale;

/**
 * @author lp
 */
@Service
public class LanguageServiceImpl implements LanguageService {

    @Autowired
    private ILanguageDao languageDao ;

    @Override
    public void setLanguage() {
        Integer defaultLanguage = languageDao.getLanguage();
        if(defaultLanguage == 0 ){
            Locale locale = new Locale("zh", "CN");
            LocaleContextHolder.setLocale(locale);
        } else {
            Locale locale = new Locale("en", "US");
            LocaleContextHolder.setLocale(locale);
        }
    }
}
