package com.wdkj.plugs.extract.dao.mysql;

import com.wdkj.plugs.model.po.SysCodeTable;
import org.apache.ibatis.annotations.Mapper;

/**
 * @description:
 * @author: guoyang
 * @date: 2022/12/27
 **/
@Mapper
public interface SysCodeTableDao {
    SysCodeTable findCodeBykey(String findCodeBykey);
}
