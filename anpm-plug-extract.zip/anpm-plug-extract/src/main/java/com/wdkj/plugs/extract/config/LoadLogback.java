//package com.wdkj.plugs.extract.config;
//
//import com.wdkj.plugs.systemlog.service.impl.SystemLogServicelmpl;
//import org.dom4j.Attribute;
//import org.dom4j.Document;
//import org.dom4j.DocumentException;
//import org.dom4j.Element;
//import org.dom4j.io.SAXReader;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.stereotype.Component;
//
//import javax.annotation.PostConstruct;
//import java.io.File;
//import java.util.List;
//
//@Component
//public class LoadLogback {
//
//    private static Logger logger = LoggerFactory.getLogger(LoadLogback.class);
//
//    @PostConstruct
//    public void load() throws DocumentException {
//        String xmlPath = "logback.xml";
//        File xmlFile = null;
//        try {
////    	  try {
////    		  xmlFile = ResourceUtils.getFile("classpath:" + xmlPath);
////  	      } catch (Exception e) {
////  	    	  e.printStackTrace();
////  	        logger.error("获取xmlFile路径错误=" + e.getMessage());
////  	      }
//            if (xmlFile == null) {
//                String path = System.getProperty("user.dir") + File.separator + "config" + File.separator + xmlPath;
//                //String path = "E:\\workspace\\anpm_4.0\\anpm-report-server\\anpm-report-server\\src\\main\\resources"+ File.separator + xmlPath;
//                xmlFile = new File(path);
//            }
//            System.out.println("xmlFile=" + xmlFile);
//            SAXReader reader = new SAXReader();
//            Document document = reader.read(xmlFile);
//            Element root = document.getRootElement();
//            List<Element> childElements = root.elements();
//            for (Element child : childElements) {
//                if ("root".equals(child.getName())) {
//                    List<Attribute> attributeList = child.attributes();
//                    for (Attribute attr : attributeList) {
//                        if (!"level".equalsIgnoreCase(attr.getName())) {
//                            continue;
//                        }
//                        if ("INFO".equalsIgnoreCase(attr.getValue())) {
//                            SystemLogServicelmpl.LoggInfo = true;
//                            break;
//                        } else if ("DEBUG".equalsIgnoreCase(attr.getValue())) {
//                            SystemLogServicelmpl.LoggDebug = true;
//                            break;
//                        }
//                    }
//                }
//            }
//            System.out.println("getXMLfILE IS OK=" + xmlFile);
//        } catch (Exception e) {
//            System.out.println("getXMLfILE IS ERROR=" + xmlFile);
//            logger.error("获取xml脚本路径错误=" + e.getMessage());
//        }
//    }
//
//}