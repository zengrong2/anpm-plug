package com.wdkj.plugs.extract.service.impl;

import com.wdkj.plugs.extract.dao.mysql.ReportDao;
import com.wdkj.plugs.extract.service.ICheckReportTimeService;
import com.wdkj.plugs.model.po.CheckReportData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(rollbackFor = Exception.class)
public class CheckReportTimeServiceImpl implements ICheckReportTimeService {

	private static Logger log = LoggerFactory.getLogger(CheckReportTimeServiceImpl.class);

	@Autowired
	private ReportDao reportDao;

	//超时时间配置
	private static final int timeOut = 120 * 60;

	@Override
	public void checkReportTime() {
		log.info("check report time ------");
		long outTime = System.currentTimeMillis()/1000-timeOut;
		List<CheckReportData> reportDataList = reportDao.findReportData();
		for (CheckReportData checkReportData : reportDataList) {
			if(checkReportData.getStartTime() <= outTime){
				reportDao.updateReportStatus("Generate data timeout ",checkReportData.getId());
			}
		}
	}
}