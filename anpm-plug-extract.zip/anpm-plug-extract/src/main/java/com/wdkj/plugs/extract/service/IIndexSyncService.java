package com.wdkj.plugs.extract.service;


/**
 * 数据抽取记录Service
 */
public interface IIndexSyncService {

    String  getLastDateByName(String extractSnmpData);
}
