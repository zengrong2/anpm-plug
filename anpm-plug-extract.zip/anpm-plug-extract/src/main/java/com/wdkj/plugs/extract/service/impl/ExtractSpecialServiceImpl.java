package com.wdkj.plugs.extract.service.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.wdkj.plugs.core.support.DynamicTableContext;
import com.wdkj.plugs.extract.dao.click.IExtractSpecialClickDao;
import com.wdkj.plugs.extract.dao.mysql.IExtractSpecialDao;
import com.wdkj.plugs.extract.dao.mysql.IIndexSyncDao;
import com.wdkj.plugs.extract.schedule.ExtractPathSchedule;
import com.wdkj.plugs.extract.schedule.ExtractSnmpSchedule;
import com.wdkj.plugs.extract.schedule.ExtractSpecialSchedule;
import com.wdkj.plugs.extract.service.IExtractSpecialService;
import com.wdkj.plugs.extract.util.DateUtil;
import com.wdkj.plugs.model.po.DelaySpecialData;
import com.wdkj.plugs.model.po.DelaySpecialFlowData;
import com.wdkj.plugs.model.po.ExtractSpecialData;
import com.wdkj.plugs.model.vo.VRunTime;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

/**
 * @ClassName ExtractSpecialServiceImpl
 * @Description TODO
 * @Author Mr.xie
 * @Date 2020/11/12 11:37
 */
@Service
public class ExtractSpecialServiceImpl implements IExtractSpecialService {
    private static Logger log = LoggerFactory.getLogger(ExtractSpecialServiceImpl.class);
    @Autowired
    private IIndexSyncDao indexSyncDao;
    @Autowired
    private IExtractSpecialDao extractSpecialDao;
    @Autowired
    private IExtractSpecialClickDao extractSpecialClickDao;
    @Resource
    private IExtractSpecialService extractSpecialService;

    @Resource(name = "clickJdbcTemplate")
    private JdbcTemplate jdbcTemplate;

    private static Set<Integer> NORMAL_ID_LIST = Sets.newHashSet();

    @Override
    public void saveSpecialData(Boolean isFirstExtract, LocalDateTime startTime, LocalDateTime end) {
        long startTimeSecond = startTime.toEpochSecond(ZoneOffset.of("+8"));
        long endTimeSecond = end.toEpochSecond(ZoneOffset.of("+8"));
        ExtractSpecialSchedule.sb.append("<div  class='c1'><pre>").append(DateUtil.getNowDateTimeString()).append(" 本次时间范围 ").append(startTime).append("-").append(end).append("\n");
        log.info("IExtractSpecialService exec start.... , startTime:{} ,  end:{}", startTimeSecond, endTimeSecond);

        DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        List<VRunTime> runTimes = extractSpecialClickDao.getRunTimeList(startTimeSecond, endTimeSecond);
        ExtractSpecialSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" runTimes ").append(runTimes.size()).append("\n");
        List<ExtractSpecialData> specialList = new CopyOnWriteArrayList<>();
        List<Integer> linkIdList = new LinkedList<>();
        long countStartTime = System.currentTimeMillis();
        try {
            linkIdList = runTimes.stream().map(VRunTime::getLinkId).collect(Collectors.toList());
            saveData(runTimes, specialList, startTime, end);
            log.info("IExtractSpecialService exec 第一批数据处理耗时 time : {}", (System.currentTimeMillis() - countStartTime));
        } catch (Exception e) {
            log.error("IExtractSpecialService 抽取专线数据报错了 error=>", e);
        }

        // 补数据的逻辑
        List<ExtractSpecialData> repairData = new LinkedList<>();
        try {
            List<VRunTime> repairRunTimeList = extractSpecialClickDao.getRepairRunTimeList(startTimeSecond, endTimeSecond);
            Set<Integer> repairLinkIdList = repairRunTimeList.stream().collect(Collectors.groupingBy(VRunTime::getLinkId)).keySet();
            List<ExtractSpecialData> repairDataList = new LinkedList<>();
            if (!repairLinkIdList.isEmpty()) {
                repairDataList = extractSpecialDao.getSpecialListByLinkId(repairLinkIdList);
            }

            ExtractSpecialSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" repairDataList ").append(repairDataList.size()).append("\n");
            Map<Integer, ExtractSpecialData> repairLinkMap = new HashMap<>(12);
            repairDataList.forEach(it -> {
                repairLinkMap.put(it.getLinkId(), it);
            });
            for (VRunTime runTime : repairRunTimeList) {
                ExtractSpecialData specialData = repairLinkMap.get(runTime.getLinkId());
                if (Objects.nonNull(specialData)) {
                    //上次正常入的这次就走以前的补数据逻辑
                    if (!CollectionUtils.isEmpty(NORMAL_ID_LIST) && !NORMAL_ID_LIST.contains(specialData.getLinkId())) {
                        continue;
                    }
                    ExtractSpecialData data = new ExtractSpecialData();
                    BeanUtils.copyProperties(specialData, data);
                    data.setRunTime(runTime.getRunTime());
                    data.setCreateTs(runTime.getReportTs());
                    // 时延数据
                    setDelayLoss(data, null);

                    //转换带宽
                    setFlowDataList(specialData, null);

                    String upstreamBandwidth = specialData.getUpstreamBandwidth();
                    String downstreamBandwidth = specialData.getDownstreamBandwidth();
                    data.setIntUpstreamBandwidth(convertBW(upstreamBandwidth));
                    data.setIntDownstreamBandwidth(convertBW(downstreamBandwidth));
                    repairData.add(data);
                }
            }
            if (!CollectionUtils.isEmpty(NORMAL_ID_LIST)) {
                List<VRunTime> otherRuntimeList = repairRunTimeList.stream().filter(it -> !NORMAL_ID_LIST.contains(it.getLinkId())).collect(Collectors.toList());
                saveData(otherRuntimeList, repairData, startTime.minusMinutes(ExtractPathSchedule.extractPathTime), startTime);
            }

            log.info("IExtractSpecialService exec 第二批数据处理用时:{}", (System.currentTimeMillis() - countStartTime));
            countStartTime = System.currentTimeMillis();
        } catch (Exception e) {
            log.error("IExtractSpecialService 抽取专线补数据报错了 error=>", e);
        }

        NORMAL_ID_LIST = Sets.newHashSet(linkIdList);
        //保存数据
        specialList.addAll(repairData);
        //过滤
        // 待保存数据集合
        int sumbitCount = 0;
        List<ExtractSpecialData> saveList = new LinkedList<>();
        log.info("IExtractSpecialService exec 待保存数据总数：{}", specialList.size());

        ExtractSpecialSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" specialList ").append(specialList.size()).append("\n");
        for (ExtractSpecialData linkData : specialList) {
            if (Objects.isNull(linkData.getCreateTs())) {
                continue;
            }
            saveList.add(linkData);
            sumbitCount++;
            // 批量提交
            if (saveList.size() >= 3000) {
                log.info("IExtractSpecialService exec 提交数： {} , 总耗时：{}", sumbitCount, (System.currentTimeMillis() - countStartTime));
                extractSpecialClickDao.save(saveList);
//                extractSpecialService.batchSaveData(saveList);
                saveList.clear();
            }
        }

        ExtractSpecialSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" saveList ").append(saveList.size()).append("\n");
        // 处理当前未达到批量条数或者批量后剩余未达到批量条数的信息
        if (!saveList.isEmpty()) {
            extractSpecialClickDao.save(saveList);
//            extractSpecialService.batchSaveData(saveList);
            saveList.clear();
        }
        Map<String, String> paramMap = new HashMap<>(2);
        paramMap.put("table", "extract_special_data");
        paramMap.put("syncTime", end.format(df));
        // 保存或更新抽取时间
        if (isFirstExtract) {
            indexSyncDao.saveSyncDate(paramMap);
        } else {
            indexSyncDao.updateSyncDate(paramMap);
        }
        ExtractSpecialSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" 完成\n</pre></div>");
    }

    private Long convertBW(String bandwidth) {
        //将K、M、G、T转为bps
        if (StringUtils.isNotBlank(bandwidth)) {
            List<String> asList = Arrays.asList(new String[]{"k", "m", "g", "t"});
            for (int i = 0; i < asList.size(); i++) {
                if (StringUtils.containsIgnoreCase(bandwidth, asList.get(i))) {
                    String b = StringUtils.removeEndIgnoreCase(bandwidth, asList.get(i));
                    if (StringUtils.isNumeric(b)) {
                        BigInteger bigInteger = new BigInteger(b);
                        return bigInteger.multiply(new BigInteger("1024").pow(i + 1)).longValue();
                    }
                }
            }
            if (StringUtils.isNumeric(bandwidth)) {
                return new BigInteger(bandwidth).longValue();
            }
        }
        return new BigInteger("-1").longValue();
    }


    @Transactional(rollbackFor = Exception.class)
    @Override
    public void batchSaveData(List<ExtractSpecialData> saveList) {

        if (CollectionUtils.isEmpty(saveList)) {
            return;
        }


        String sql = "INSERT INTO extract_special_data ( link_id, special_id, data_source, run_time, delay, min_delay, max_delay, avg_flow_into_speed, avg_flow_out_speed, max_flow_into_speed, max_flow_out_speed, min_flow_into_speed, min_flow_out_speed, create_ts, upstream_bandwidth, downstream_bandwidth, lose_rate, min_lose_rate, max_lose_rate, sum_delay, sum_lose, delay_count, lose_count, sum_into_speed, into_speed_count, sum_out_speed, out_speed_count ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ? )";


        Lists.partition(saveList, 1000).forEach(list -> {

            jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {

                @Override
                public void setValues(java.sql.PreparedStatement ps, int i) throws java.sql.SQLException {
                    ExtractSpecialData data = list.get(i);

//    #{ item.linkId }, #{ item.specialId }, #{ item.dataSource }, #{ item.runTime }, #{ item.delay }, #{ item.minDelay },
//    #{ item.maxDelay }, #{ item.avgFlowIntoSpeed }, #{ item.avgFlowOutSpeed }, #{ item.maxFlowIntoSpeed }, #{ item.maxFlowOutSpeed },
//    #{ item.minFlowIntoSpeed }, #{ item.minFlowOutSpeed }, #{ item.createTs }, #{ item.intUpstreamBandwidth },
//    #{ item.intDownstreamBandwidth }, #{ item.loseRate }, #{ item.minLoseRate }, #{ item.maxLoseRate }, #{ item.sumDelay },
//    #{ item.sumLose }, #{ item.delayCount },#{ item.loseCount }, #{ item.sumIntoSpeed }, #{ item.intoSpeedCount },
//    #{ item.sumOutSpeed }, #{ item.outSpeedCount }

                    ps.setInt(1, data.getLinkId());
                    ps.setInt(2, data.getSpecialId());
                    ps.setInt(3, data.getDataSource());
                    ps.setLong(4, data.getRunTime());
                    ps.setFloat(5, data.getDelay());
                    ps.setFloat(6, data.getMinDelay());
                    ps.setFloat(7, data.getMaxDelay());
                    ps.setDouble(8, data.getAvgFlowIntoSpeed());
                    ps.setDouble(9, data.getAvgFlowOutSpeed());
                    ps.setDouble(10, data.getMaxFlowIntoSpeed());
                    ps.setDouble(11, data.getMaxFlowOutSpeed());
                    ps.setDouble(12, data.getMinFlowIntoSpeed());
                    ps.setDouble(13, data.getMinFlowOutSpeed());
                    ps.setLong(14, data.getCreateTs());
                    ps.setLong(15, data.getIntUpstreamBandwidth());
                    ps.setLong(16, data.getIntDownstreamBandwidth());
                    ps.setFloat(17, data.getLoseRate());
                    ps.setFloat(18, data.getMinLoseRate());
                    ps.setFloat(19, data.getMaxLoseRate());
                    ps.setFloat(20, data.getSumDelay());
                    ps.setFloat(21, data.getSumLose());
                    ps.setInt(22, data.getDelayCount());
                    ps.setInt(23, data.getLoseCount());
                    ps.setDouble(24, data.getSumIntoSpeed());
                    ps.setInt(25, data.getIntoSpeedCount());
                    ps.setDouble(26, data.getSumOutSpeed());
                    ps.setInt(27, data.getOutSpeedCount());
                }

                @Override
                public int getBatchSize() {
                    return list.size();
                }
            });
        });


    }

    private void saveData(List<VRunTime> runTimes, List<ExtractSpecialData> specialList, LocalDateTime startTime, LocalDateTime end) {


        long startTimeSecond = startTime.toEpochSecond(ZoneOffset.of("+8"));
        long endTimeSecond = end.toEpochSecond(ZoneOffset.of("+8"));

        //初始化使用数据------------
        Set<Integer> linkIntIdList = runTimes.stream().collect(Collectors.groupingBy(VRunTime::getLinkId)).keySet();
        List<ExtractSpecialData> dataList = new LinkedList<>();
        if (!linkIntIdList.isEmpty()) {
            dataList = extractSpecialDao.getSpecialListByLinkId(linkIntIdList);
        }
        ExtractSpecialSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" dataList ").append(dataList.size()).append("\n");
        Map<Integer, ExtractSpecialData> linkMap = new HashMap<>(255);
        dataList.forEach(it -> {
            linkMap.put(it.getLinkId(), it);
        });
        //通过存表不同进行区分
        Map<String, List<DelaySpecialData>> allDataMap = new HashMap<>(255);
        dataList.stream().collect(Collectors.groupingBy(it -> DynamicTableContext.genTraceDataTableName(it.getSpecialId(), it.getLinkId(), it.getDataSource()))).forEach((k, v) -> {
            List<Integer> lIds = v.stream().map(ExtractSpecialData::getLinkId).collect(Collectors.toList());
            log.info("IExtractSpecialService exec 查询时延数据：tableName: {} ,route_id:{} , startTime:{} , endTime:{} ", k, lIds, startTimeSecond, endTimeSecond);
            List<DelaySpecialData> list = extractSpecialClickDao.getDelayList(k, lIds, startTimeSecond, endTimeSecond);
            list.stream().collect(Collectors.groupingBy(it -> k + it.getLinkId())).forEach(allDataMap::put);
        });
        ExtractSpecialSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" allDataMap ").append(allDataMap.size()).append("\n");
        
        //初始化流速数据
        List<Integer> specialIds = dataList.stream().map(ExtractSpecialData::getSpecialId).distinct().collect(Collectors.toList());
        //报错处理
        Map<Integer, List<DelaySpecialFlowData>> specialFlowDataMap = new HashMap<>(12);
        if (null != specialIds && specialIds.size() > 0) {
            specialFlowDataMap = extractSpecialClickDao.getSpecialFlowList(startTimeSecond, endTimeSecond, specialIds).stream().collect(Collectors.groupingBy(DelaySpecialFlowData::getSpecialId));
        }
        ExtractSpecialSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" specialFlowDataMap ").append(specialFlowDataMap.size()).append("\n");
        //初始化使用数据------------
        for (VRunTime runTime : runTimes) {
            ExtractSpecialData specialData = linkMap.get(runTime.getLinkId());
            if (Objects.nonNull(specialData)) {
                    /*String specialIp = specialData.getSpecialIp();
                    if (StringUtils.isBlank(specialIp)) {
                        continue;
                    }*/
                //获取表名
                Integer specialId = specialData.getSpecialId();
                if (null == specialId) {
                    continue;
                }
                Integer dataSource = specialData.getDataSource();
                String tableName = DynamicTableContext.genTraceDataTableName(specialId, runTime.getLinkId(), dataSource);
                List<DelaySpecialData> specialDataList = allDataMap.get(tableName + runTime.getLinkId());
                setDelayLoss(specialData, specialDataList);
                specialData.setRunTime(runTime.getRunTime());
//                specialData.setCreateTs(endTimeSecond);

                log.info("IExtractSpecialService exec specialId： {} , linkId:{} ,  tableName :{}", specialId, runTime.getLinkId(), tableName);

                //流速
                List<DelaySpecialFlowData> flowDataList = specialFlowDataMap.get(specialData.getSpecialId());
                setFlowDataList(specialData, flowDataList);

                String upstreamBandwidth = specialData.getUpstreamBandwidth();
                String downstreamBandwidth = specialData.getDownstreamBandwidth();
                specialData.setIntUpstreamBandwidth(convertBW(upstreamBandwidth));
                specialData.setIntDownstreamBandwidth(convertBW(downstreamBandwidth));

                if (runTime.getReportTs() != null) {
                    specialData.setCreateTs(runTime.getReportTs());
                } else {
                    specialData.setCreateTs(endTimeSecond);
                }

                specialList.add(specialData);
            } else {
                log.info("IExtractSpecialService exec time： link_id : {} 不存在 ", runTime.getLinkId());
            }
        }
        ExtractSpecialSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" done runTimes ").append(runTimes.size()).append("\n");
    }

    /***
     * 设置时延信息信息
     */
    private void setDelayLoss(ExtractSpecialData specialData, List<DelaySpecialData> data) {
        if (data != null && data.size() > 0) {
            specialData.setDelay((float) data.stream().mapToDouble(DelaySpecialData::getDelay).average().getAsDouble());
            specialData.setMaxDelay((float) data.stream().mapToDouble(DelaySpecialData::getDelay).max().getAsDouble());
            specialData.setMinDelay((float) data.stream().mapToDouble(DelaySpecialData::getDelay).min().getAsDouble());
            // 之前的写法
//            specialData.setSumDelay((float)data.stream().mapToDouble(DelaySpecialData::getDelay).sum());
//            specialData.setDelayCount(data.size());
            // 修改后，应该吧 负数排除在外
            specialData.setSumDelay((float) data.stream().filter(it -> it.getDelay() > 0).mapToDouble(DelaySpecialData::getDelay).sum());
            specialData.setDelayCount((int) data.stream().filter(it -> it.getDelay() > 0).count());

            specialData.setLoseRate((float) data.stream().mapToDouble(DelaySpecialData::getLoseRate).average().getAsDouble());
            specialData.setMaxLoseRate((float) data.stream().mapToDouble(DelaySpecialData::getLoseRate).max().getAsDouble());
            specialData.setMinLoseRate((float) data.stream().mapToDouble(DelaySpecialData::getLoseRate).min().getAsDouble());
            specialData.setSumLose((float) data.stream().filter(it -> it.getLoseRate() >= 0).mapToDouble(DelaySpecialData::getLoseRate).sum());
            specialData.setLoseCount((int) data.stream().filter(it -> it.getLoseRate() >= 0).count());
        } else {
            specialData.setDelay(-1F);
            specialData.setMaxDelay(-1F);
            specialData.setMinDelay(-1F);
            specialData.setLoseRate(-1F);
            specialData.setMaxLoseRate(-1F);
            specialData.setMinLoseRate(-1F);
            specialData.setSumDelay(0F);
            specialData.setSumLose(0F);
            specialData.setDelayCount(0);
            specialData.setLoseCount(0);
        }
    }

    /***
     * 设置流速信息
     */
    private void setFlowDataList(ExtractSpecialData specialData, List<DelaySpecialFlowData> flowDataList) {
        if (flowDataList != null && flowDataList.size() > 0) {
            specialData.setAvgFlowIntoSpeed(flowDataList.stream().mapToDouble(DelaySpecialFlowData::getFlowIntoSpeed).average().getAsDouble());
            specialData.setMaxFlowIntoSpeed(flowDataList.stream().mapToDouble(DelaySpecialFlowData::getFlowIntoSpeed).max().getAsDouble());
            specialData.setMinFlowIntoSpeed(flowDataList.stream().mapToDouble(DelaySpecialFlowData::getFlowIntoSpeed).min().getAsDouble());
            specialData.setAvgFlowOutSpeed(flowDataList.stream().mapToDouble(DelaySpecialFlowData::getFlowOutSpeed).average().getAsDouble());
            specialData.setMaxFlowOutSpeed(flowDataList.stream().mapToDouble(DelaySpecialFlowData::getFlowOutSpeed).max().getAsDouble());
            specialData.setMinFlowOutSpeed(flowDataList.stream().mapToDouble(DelaySpecialFlowData::getFlowOutSpeed).min().getAsDouble());
            specialData.setSumIntoSpeed(flowDataList.stream().mapToDouble(DelaySpecialFlowData::getFlowIntoSpeed).sum());
            specialData.setSumOutSpeed(flowDataList.stream().mapToDouble(DelaySpecialFlowData::getFlowOutSpeed).sum());
            specialData.setIntoSpeedCount((int) flowDataList.stream().filter(it -> it.getFlowIntoSpeed() != null && it.getFlowIntoSpeed() >= 0).count());
            specialData.setOutSpeedCount((int) flowDataList.stream().filter(it -> it.getFlowOutSpeed() != null && it.getFlowOutSpeed() >= 0).count());
        } else {
            specialData.setAvgFlowIntoSpeed(-1.0);
            specialData.setMaxFlowIntoSpeed(-1.0);
            specialData.setMinFlowIntoSpeed(-1.0);
            specialData.setAvgFlowOutSpeed(-1.0);
            specialData.setMaxFlowOutSpeed(-1.0);
            specialData.setMinFlowOutSpeed(-1.0);
            specialData.setSumIntoSpeed(0.0);
            specialData.setSumOutSpeed(0.0);
            specialData.setIntoSpeedCount(0);
            specialData.setOutSpeedCount(0);
        }
    }

//    @PostConstruct
//    private void init(){
//        List<ExtractSpecialData> saveList = new ArrayList<>(100);
//        for (int i = 0; i < 100; i++) {
//            ExtractSpecialData data = new ExtractSpecialData();
//            data.setLinkId(i);
//            data.setSpecialId(i);
//            data.setRunTime(i * 5L);
//            data.setDataSource(0);
//            data.setDelay(0F);
//            data.setMinDelay(0F);
//            data.setMaxDelay(0F);
//            data.setAvgFlowIntoSpeed(0D);
//            data.setAvgFlowOutSpeed(0D);
//            data.setMaxFlowIntoSpeed(0D);
//            data.setMaxFlowOutSpeed(0D);
//            data.setMinFlowIntoSpeed(0D);
//            data.setMinFlowOutSpeed(0D);
//            data.setCreateTs(0L);
//            data.setIntUpstreamBandwidth(0L);
//            data.setIntDownstreamBandwidth(0L);
//            data.setLoseRate(0F);
//            data.setMinLoseRate(0F);
//            data.setMaxLoseRate(0F);
//            data.setSumDelay(0F);
//            data.setSumLose(0F);
//            data.setDelayCount(i);
//            data.setLoseCount(i);
//            data.setSumIntoSpeed(0D);
//            data.setIntoSpeedCount(i);
//            data.setSumOutSpeed(0D);
//            data.setOutSpeedCount(i);
//
//            saveList.add(data);
//        }
//
//        batchSaveData(saveList);
//        log.info("执行成功");
//    }


}
