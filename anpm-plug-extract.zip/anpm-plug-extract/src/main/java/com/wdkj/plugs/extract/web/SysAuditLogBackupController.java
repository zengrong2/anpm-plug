package com.wdkj.plugs.extract.web;

import com.wdkj.plugs.core.model.to.Result;
import com.wdkj.plugs.extract.schedule.SysAuditLogBackupSchedule;
import com.wdkj.plugs.utils.enu.MessageEnum;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @ClassName SysAuditLogBackupController
 * @Description TODO
 * @Author penglei
 * @Date 2022/12/27 15:50
 */
@RestController
@RequestMapping("/sysAuditLogBackup")
public class SysAuditLogBackupController {
    private static Logger logger = LoggerFactory.getLogger(SysAuditLogBackupController.class);
    @Autowired
    private SysAuditLogBackupSchedule sysAuditLogBackupSchedule;

    @PostMapping("/execute")
    @ApiOperation(value = "审计日志数据备份", tags = "审计日志数据备份", httpMethod = "POST")
    public Result<?> update() {
        try {
            logger.info("-----审计日志数据备份开始-----");
            sysAuditLogBackupSchedule.execute();
            logger.info("-----审计日志数据备份结束-----");
            return new Result<>(MessageEnum.SUCCESS);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("审计日志数据备份失败={}" , e.getMessage());
            return new Result<>(MessageEnum.FAIL,e.getMessage());
        }
    }
}
