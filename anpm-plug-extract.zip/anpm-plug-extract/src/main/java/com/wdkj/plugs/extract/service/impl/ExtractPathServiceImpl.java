package com.wdkj.plugs.extract.service.impl;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Sets;
import com.wdkj.plugs.core.support.DynamicTableContext;
import com.wdkj.plugs.extract.dao.click.IExtractPathClickDao;
import com.wdkj.plugs.extract.dao.mysql.IExtractPathDao;
import com.wdkj.plugs.extract.dao.mysql.IIndexSyncDao;
import com.wdkj.plugs.extract.schedule.ExtractPathSchedule;
import com.wdkj.plugs.extract.service.IExtractPathService;
import com.wdkj.plugs.extract.util.DateUtil;
import com.wdkj.plugs.model.po.DelayData;
import com.wdkj.plugs.model.po.ExtractPathData;
import com.wdkj.plugs.model.vo.VRunTime;

/**
 * @ClassName ExtractSnmpServiceImpl
 * @Description TODO
 * @Author Mr.xie
 * @Date 2021/10/13 17:00
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class ExtractPathServiceImpl implements IExtractPathService {

	private static Logger log = LoggerFactory.getLogger(ExtractPathServiceImpl.class);

	@Autowired
	private IIndexSyncDao indexSyncDao;

	@Autowired
	private IExtractPathDao extractPathDao;

	@Autowired
	private IExtractPathClickDao extractPathClickDao;

	private JdbcTemplate jdbcTemplate;

	private static Set<Integer> normalIdList = Sets.newHashSet();

	@Autowired
	public void setJdbcTemplate(@Qualifier("clickDataSource") DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public static String ipv4StringToNum(String ip) {
		String[] ips = ip.split("\\.");
		if (ips.length != 4) {
			return null;
		}
		long ip_num;
		ip_num = (Long.parseLong(ips[0], 10) << 24) +
				(Long.parseLong(ips[1], 10) << 16) +
				(Long.parseLong(ips[2], 10) << 8) +
				Long.parseLong(ips[3], 10);
		return ip_num + "";
	}

	private void savePathData(List<VRunTime> runTimes, List<ExtractPathData> pathDataList, LocalDateTime startTime, LocalDateTime end) {
		long startTimeSecond = startTime.toEpochSecond(ZoneOffset.of("+8"));
		long endTimeSecond = end.toEpochSecond(ZoneOffset.of("+8"));
		//初始化使用数据------------
		Set<Integer> linkIntIdList = runTimes.stream().collect(Collectors.groupingBy(VRunTime::getLinkId)).keySet();
		List<ExtractPathData> dataList = new ArrayList<ExtractPathData>();
		if (linkIntIdList.size() > 0) {
			ExtractPathSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" 开始查询 getLinkListById\n");
			dataList = extractPathDao.getLinkListById(linkIntIdList);
			ExtractPathSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" 结束查询 getLinkListById ").append(dataList.size()).append("\n");
		}
		Map<Integer, ExtractPathData> linkMap = new HashMap<>(255);
		dataList.forEach(it -> {
			linkMap.put(it.getLinkId(), it);
		});
		//通过存表不同进行区分
		Map<String, List<DelayData>> allDataMap = new HashMap<>(255);
		/*dataList.stream().collect(Collectors.groupingBy(it -> DynamicTableContext.genTraceDataTableName(it.getDestIp(), it.getLinkId()))).forEach((k, v) -> {*/
		dataList.stream().collect(Collectors.groupingBy(it -> DynamicTableContext.genTraceDataTableName(it.getTaskId(), it.getLinkId(),it.getDataSource()))).forEach((k, v) -> {
			List<String> destIpList = v.stream().map(ExtractPathData::getDestIp).distinct().collect(Collectors.toList());
			List<Integer> lIds = v.stream().map(ExtractPathData::getLinkId).collect(Collectors.toList());
			List<DelayData> list = extractPathClickDao.getDelayList(k, lIds, destIpList, startTimeSecond, endTimeSecond);
			list.stream().collect(Collectors.groupingBy(it -> k + it.getLinkId())).forEach(allDataMap::put);
		});
		ExtractPathSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" allDataMap.size=").append(allDataMap.size()).append(", runTimes.size=").append(runTimes.size()).append("\n");
		
		//初始化使用数据------------
		for (VRunTime runTime : runTimes) {
			ExtractPathData linkData2 = linkMap.get(runTime.getLinkId());
			if (Objects.nonNull(linkData2)) {
				ExtractPathData linkData = linkData2.clone();
				String destIp = linkData.getDestIp();
				/*String destNum = ipv4StringToNum(destIp);*/
				Integer linkId = linkData.getLinkId();
				Integer taskId = linkData.getTaskId();
				Integer dataSource = linkData.getDataSource();
				//获取表名
				/*String tableName = DynamicTableContext.genTraceDataTableName(destIp, linkId);*/
				String tableName = DynamicTableContext.genTraceDataTableName(taskId, linkId,dataSource);
				if(null != allDataMap.get(tableName + linkId)){
					/*List<DelayData> selfDataList = allDataMap.get(tableName + linkId).stream().filter(it ->
							it.getCurIp() != null && it.getCurIp().equals(destNum)).collect(Collectors.toList());*/
					List<DelayData> selfDataList = allDataMap.get(tableName + linkId).stream().collect(Collectors.toList());
					setDelayLoss(linkData, selfDataList);
				}else{
					setDelayLoss(linkData, null);
				}
				//封装运行时长
				linkData.setRunTime(runTime.getRunTime());
				linkData.setCreateTs(endTimeSecond);
				pathDataList.add(linkData);
			}
		}
		ExtractPathSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" 结束！\n");
	}


	private void repairSavePathData(List<VRunTime> runTimes, List<ExtractPathData> pathDataList, LocalDateTime startTime, LocalDateTime end) {
		long startTimeSecond = startTime.toEpochSecond(ZoneOffset.of("+8"));
		long endTimeSecond = end.toEpochSecond(ZoneOffset.of("+8"));
		//初始化使用数据------------
		Set<Integer> linkIntIdList = runTimes.stream().collect(Collectors.groupingBy(VRunTime::getLinkId)).keySet();
		List<ExtractPathData> dataList = new ArrayList<ExtractPathData>();
		if (linkIntIdList.size() > 0) {
			dataList = extractPathDao.getLinkListById(linkIntIdList);
		}
		Map<Integer, ExtractPathData> linkMap = new HashMap<>(12);
		dataList.forEach(it -> {
			linkMap.put(it.getLinkId(), it);
		});
		//通过存表不同进行区分
		Map<String, List<DelayData>> allDataMap = new HashMap<>(12);
		/*dataList.stream().collect(Collectors.groupingBy(it -> DynamicTableContext.genTraceDataTableName(it.getDestIp(), it.getLinkId()))).forEach((k, v) -> {*/
		dataList.stream().collect(Collectors.groupingBy(it -> DynamicTableContext.genTraceDataTableName(it.getTaskId(), it.getLinkId(),it.getDataSource()))).forEach((k, v) -> {
			List<String> destIpList = v.stream().map(ExtractPathData::getDestIp).distinct().collect(Collectors.toList());
			List<Integer> lIds = v.stream().map(ExtractPathData::getLinkId).collect(Collectors.toList());
			List<DelayData> list = extractPathClickDao.getDelayList(k, lIds, destIpList, startTimeSecond, endTimeSecond);
			list.stream().collect(Collectors.groupingBy(it -> k + it.getLinkId())).forEach(allDataMap::put);
		});
		//初始化使用数据------------
		for (VRunTime runTime : runTimes) {
			ExtractPathData linkData2 = linkMap.get(runTime.getLinkId());
			if (Objects.nonNull(linkData2)) {
				ExtractPathData linkData = linkData2.clone();
				String destIp = linkData.getDestIp();
				/*String destNum = ipv4StringToNum(destIp);*/
				Integer linkId = linkData.getLinkId();
				Integer taskId = linkData.getTaskId();
				Integer dataSource = linkData.getDataSource();
				//获取表名
				/*String tableName = DynamicTableContext.genTraceDataTableName(destIp, linkId);*/
				String tableName = DynamicTableContext.genTraceDataTableName(taskId, linkId,dataSource);
				if(null != allDataMap.get(tableName + linkId)){
					/*List<DelayData> selfDataList = allDataMap.get(tableName + linkId).stream().filter(it ->
							it.getCurIp() != null && it.getCurIp().equals(destNum)).collect(Collectors.toList());*/
					List<DelayData> selfDataList = allDataMap.get(tableName + linkId).stream().collect(Collectors.toList());
					setDelayLoss(linkData, selfDataList);
				}else{
					setDelayLoss(linkData, null);
				}
				//封装运行时长
				linkData.setRunTime(runTime.getRunTime());
				/*linkData.setCreateTs(endTimeSecond);*/
				linkData.setCreateTs(runTime.getReportTs());
				pathDataList.add(linkData);
			}
		}
	}


	DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

	@Override
	public void savePathData(Boolean isFirstExtract, LocalDateTime startTime, LocalDateTime end) throws ExecutionException, InterruptedException {
		long startTimeSecond = startTime.toEpochSecond(ZoneOffset.of("+8"));
		long endTimeSecond = end.toEpochSecond(ZoneOffset.of("+8"));
		log.info("path-抽取时间段：{}-{}", startTime.format(df), end.format(df));
        ExtractPathSchedule.sb.append("<div class='c1'><pre>").append(DateUtil.getNowDateTimeString()).append(" 本次时间范围 ").append(startTime).append("-").append(end).append("\n");

		long b = System.currentTimeMillis();
		int runTimeSize = 0;
		List<ExtractPathData> pathDataList = Collections.synchronizedList(new ArrayList<>());
		List<Integer> linkIdList = new ArrayList<>();
		try {
			//运行时长
			List<VRunTime> runTimes = extractPathClickDao.getRunTimeList(startTimeSecond, endTimeSecond);
			linkIdList = runTimes.stream().map(VRunTime::getLinkId).collect(Collectors.toList());
			runTimeSize = runTimes.size();
			ExtractPathSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" runTimes ").append(runTimes.size()).append("\n");
			ExtractPathSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" pathDataList ").append(pathDataList.size()).append("\n");
			//保存
			savePathData(runTimes, pathDataList, startTime, end);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("error:{}", e.getMessage());
			return;
		}
		long c = System.currentTimeMillis();
		log.info("path-查询所有运行时长-数量：{}，耗时：{} 毫秒", runTimeSize, (c - b));

		long d = System.currentTimeMillis();
		log.info("path-封装路径时延丢包流量耗时：{} 毫秒", (d - c));
		long e = 0L;
		try {
			long repairStartTime = System.currentTimeMillis();
			//补数据
			List<VRunTime> repairRunTimeList = extractPathClickDao.getRepairRunTimeList(startTimeSecond, endTimeSecond);
			//将link放入缓存
			Set<Integer> linkIntIdList = repairRunTimeList.stream().collect(Collectors.groupingBy(VRunTime::getLinkId)).keySet();
			List<ExtractPathData> dataList = new ArrayList<>();
			if(null != linkIntIdList && linkIntIdList.size() >0){
				dataList = extractPathDao.getLinkListById(linkIntIdList);
			}
			Map<Integer, ExtractPathData> linkMap = new HashMap<>(255);
			dataList.forEach(it -> {
				linkMap.put(it.getLinkId(), it);
			});
			ExtractPathSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" dataList ").append(dataList.size()).append("\n");
			List<ExtractPathData> repairData = Collections.synchronizedList(new ArrayList<>());
			for (VRunTime runTime : repairRunTimeList) {
				ExtractPathData extractPathData = new ExtractPathData();
				ExtractPathData pathData = linkMap.get(runTime.getLinkId());
				//上次正常入的这次就走以前的补数据逻辑
				if (Objects.nonNull(pathData)){
					if(!normalIdList.isEmpty() && !normalIdList.contains(pathData.getLinkId())) {
						continue ;
					}
					extractPathData.setTaskId(pathData.getTaskId());
					extractPathData.setOrgId(pathData.getOrgId());
					extractPathData.setDataSource(pathData.getDataSource());
					extractPathData.setLinkId(runTime.getLinkId());
					extractPathData.setRunTime(runTime.getRunTime());
					setDelayLoss(extractPathData, null);
					extractPathData.setCreateTs(runTime.getReportTs());
					repairData.add(extractPathData);
				}
			}
			if(!normalIdList.isEmpty()){
				List<VRunTime> otherRuntimeList = repairRunTimeList.stream().filter(it -> !normalIdList.contains(it.getLinkId())).collect(Collectors.toList());
				repairSavePathData(otherRuntimeList,pathDataList,startTime.minusMinutes(ExtractPathSchedule.extractPathTime),startTime);
			}/*else{
				if(null != repairRunTimeList && repairRunTimeList.size() > 0){
					repairSavePathData(repairRunTimeList,pathDataList,startTime.minusMinutes(ExtractPathSchedule.extractPathTime),startTime);
				}
			}*/
			e = System.currentTimeMillis();

			ExtractPathSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" path-运行时长补数据耗时： ").append(e - d).append("毫秒\n");
			log.info("path-运行时长补数据耗时：{} 毫秒", (e - d));
			//保存数据
			log.info("path-本次抽取路径数量：{}，补运行时长数量：{} 。", pathDataList.size(), repairData.size());
			System.out.println("repair耗时：" + (System.currentTimeMillis() - repairStartTime));
			pathDataList.addAll(repairData);
		} catch (Exception e2) {
			log.error("error:{}", e2.getMessage());
			return;
		}
		normalIdList = Sets.newHashSet(linkIdList);
		//过滤
		// 待保存数据集合
		List<ExtractPathData> saveList = new ArrayList<>(pathDataList.size());
		ExtractPathSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" saveList ").append(saveList.size()).append("\n");
		System.out.println("总数：" + pathDataList.size() + ",startTime:" + startTime.format(df));
		for (ExtractPathData linkData : pathDataList) {
			if (Objects.isNull(linkData.getCreateTs())) {
				continue;
			}
			saveList.add(linkData);
			// 批量提交
			if (saveList.size() >= 30000) {
				String insertSql = getInsertSql(saveList);
				jdbcTemplate.execute(insertSql);
				saveList.clear();
			}
		}
		// 处理当前未达到批量条数或者批量后剩余未达到批量条数的信息
		if (!saveList.isEmpty()) {
			jdbcTemplate.execute(getInsertSql(saveList));
			saveList.clear();
		}
		long f = System.currentTimeMillis();
		log.info("path-保存数据耗时：" + (f - e) + "毫秒");
		ExtractPathSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" path-保存数据耗时： ").append(e - d).append("毫秒\n");

		Map<String, String> paramMap = new HashMap<>(2);
		paramMap.put("table", "extract_path_data");
		paramMap.put("syncTime", end.format(df));
		// 保存或更新抽取时间
		if (isFirstExtract) {
			indexSyncDao.saveSyncDate(paramMap);
		} else {
			indexSyncDao.updateSyncDate(paramMap);
		}
		long g = System.currentTimeMillis();
		System.out.println("path-路径抽取总耗时：" + (g - b) + "毫秒");
		ExtractPathSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" 完成 path-路径抽取总耗时： ").append(g - b).append("毫秒\n</div>");
		log.info("path-路径抽取总耗时：" + (g - b) + "毫秒");
	}

	public String getInsertSql(List<ExtractPathData> saveList) {
		StringBuffer sql = new StringBuffer("INSERT INTO\n" +
				"        extract_path_data (\n" +
				"            data_source,\n" +
				"            run_time,\n" +
				"            task_id,\n" +
				"            org_id,\n" +
				"            delay,\n" +
				"            min_delay,\n" +
				"            max_delay,\n" +
				"            create_ts,\n" +
				"            link_id,\n" +
				"            lose_rate,\n" +
				"            min_lose_rate,\n" +
				"            max_lose_rate,\n" +
				"            sum_delay,\n" +
				"            sum_lose,\n" +
				"            delay_count,\n" +
				"            lose_count)\n" +
				"        VALUES");
		sql.append(saveList.stream().map(it -> String.format("('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')",
				it.getDataSource(), it.getRunTime(), it.getTaskId(), it.getOrgId(), it.getDelay(), it.getMinDelay(), it.getMaxDelay(), it.getCreateTs(),
				it.getLinkId(), it.getLoseRate(), it.getMinLoseRate(), it.getMaxLoseRate(), it.getSumDelay(), it.getSumLose(), it.getDelayCount(), it.getLoseCount())).collect(Collectors.joining(",")));
		return sql.toString();
	}

	private void setDelayLoss(ExtractPathData pathData, List<DelayData> data) {
		if (data != null && data.size() > 0) {
			pathData.setDelay((float)data.stream().mapToDouble(DelayData::getDelay).average().getAsDouble());
			pathData.setMaxDelay((float)data.stream().mapToDouble(DelayData::getDelay).max().getAsDouble());
			pathData.setMinDelay((float)data.stream().mapToDouble(DelayData::getDelay).min().getAsDouble());
			pathData.setSumDelay((float)data.stream().filter(it-> it.getDelay() > 0).mapToDouble(DelayData::getDelay).sum());
			pathData.setDelayCount((int) data.stream().filter(it -> it.getDelay() > 0).count());
			pathData.setLoseRate((float)data.stream().mapToDouble(DelayData::getLoseRate).average().getAsDouble());
			pathData.setMaxLoseRate((float)data.stream().mapToDouble(DelayData::getLoseRate).max().getAsDouble());
			pathData.setMinLoseRate((float)data.stream().mapToDouble(DelayData::getLoseRate).min().getAsDouble());
			pathData.setSumLose((float)data.stream().filter(it-> it.getLoseRate() >= 0).mapToDouble(DelayData::getLoseRate).sum());
			pathData.setLoseCount((int) data.stream().filter(it-> it.getLoseRate() >= 0).count());
		} else {
			pathData.setDelay(-1F);
			pathData.setMaxDelay(-1F);
			pathData.setMinDelay(-1F);
			pathData.setSumDelay(0F);
			pathData.setDelayCount(0);
			pathData.setLoseRate(-1F);
			pathData.setMaxLoseRate(-1F);
			pathData.setMinLoseRate(-1F);
			pathData.setSumLose(0F);
			pathData.setLoseCount(0);
		}
	}

}