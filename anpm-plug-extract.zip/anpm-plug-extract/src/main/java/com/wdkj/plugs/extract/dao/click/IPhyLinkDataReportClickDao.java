package com.wdkj.plugs.extract.dao.click;


import com.wdkj.plugs.model.po.LinkData;
import com.wdkj.plugs.model.po.LinkDataTwo;
import org.apache.ibatis.annotations.Param;
import org.mapstruct.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 
 * @author lp
 *
 */
@Repository
@Mapper
public interface IPhyLinkDataReportClickDao {

    LinkDataTwo getFlowData(@Param("portId")String portId, @Param("rate")Integer rate);

    LinkDataTwo getRouteData(@Param("tableName") String tableName, @Param("routeId") String routeId, @Param("preIp") String fDevIp, @Param("curIp") String fPeerIp,@Param("startTime")Long startTime,@Param("endTime")Long endTime);

    List<LinkDataTwo> findAllFlowData(@Param("startTime")Long startTime,@Param("endTime")Long endTime);
}
