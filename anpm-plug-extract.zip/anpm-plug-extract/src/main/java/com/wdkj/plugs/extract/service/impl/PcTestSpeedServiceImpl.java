package com.wdkj.plugs.extract.service.impl;

import com.wdkj.plugs.extract.dao.mysql.IPcTestSpeedDao;
import com.wdkj.plugs.extract.service.IPcTestSpeedService;
import com.wdkj.plugs.model.po.PcTestSpeedTask;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class PcTestSpeedServiceImpl implements IPcTestSpeedService {

    @Autowired
    private IPcTestSpeedDao dao;

    @Override
    public List<PcTestSpeedTask> getRunningPcTask() {
        return dao.getRunningPcTask();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updatePcTask(List<Integer> taskIds) {
        dao.updatePcTask(taskIds);
    }
}
