package com.wdkj.plugs.extract.dao.mysql;


import com.wdkj.plugs.model.po.SpecialData;
import com.wdkj.plugs.model.vo.RepeatVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * @Description TODO
 * @Author liupan
 * @Date 2021/4/26 10:14
 */
@Mapper
@Repository
public interface ISpecialDataDisplayIdMapper {


    List<SpecialData> getAllList();

    @Deprecated
    List<Map<String, String>> getByDisplayId();

    int updateByPrimaryKeySelective(SpecialData record);

    List<RepeatVo> getRepeatList();

    void updateById(SpecialData data);

    List<Map<String, String>> getByDisplayIdByOrg(@Param("specialZIp")String specialZIp, @Param("orgList") List<Integer> orgIdList);

    List<Integer> getOrgSectionById(@Param("orgId")Integer orgId);

    Integer getUnrecoveredEvent(@Param("linkId")Integer linkId);

    Integer getTaskDialConfigById(@Param("dialConfigId") Integer dialConfigId);

    Integer getSnmpRepeatById(@Param("snmpRepeatId") Integer snmpRepeatId);


    List<Integer> findOwnAndBranchOrgIdByTreeNumber(@Param("treeNumber") String treeNumber);

    String getOrgTreeNumberByOrgId(@Param("orgId") Integer orgId);

    String getSysDataTable(@Param("key") String key);

    int querySpecialUnrecoveredEvent(@Param("taskId") Integer taskId);

    List<Map<String, String>> getByDisplayIdByOrgAll();

    List<Map<String, String>> querySpecialUnrecoveredEventDataMap();

    List<Map<String, String>> getUnrecoveredEventAll(@Param("linkIds") List<Integer> linkIds);
}
