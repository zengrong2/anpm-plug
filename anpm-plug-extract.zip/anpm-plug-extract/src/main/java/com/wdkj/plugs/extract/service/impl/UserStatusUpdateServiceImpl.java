package com.wdkj.plugs.extract.service.impl;


import com.wdkj.plugs.core.dao.IUserQueryDao;
import com.wdkj.plugs.core.model.po.User;
import com.wdkj.plugs.extract.dao.mysql.SysCodeTableDao;
import com.wdkj.plugs.extract.service.IUserService;
import com.wdkj.plugs.model.po.SysCodeTable;
//import com.wdkj.plugs.user.dao.IUserDao;
import com.wdkj.plugs.utils.enu.TypeEnum;
import org.checkerframework.checker.units.qual.A;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * @description:
 * @author: guoyang
 * @date: 2022/12/26
 **/
@Service
public class UserStatusUpdateServiceImpl implements IUserService {

    private static Logger log = LoggerFactory.getLogger(UserStatusUpdateServiceImpl.class);

    private static Integer threeMonthSeconds = 86400 * 90;

    private static String SYSTEM_CONFIG_IDENTIFY_TWO = "SYSTEM_CONFIG_IDENTIFY_TWO";
    @Autowired
    private IUserQueryDao userQueryDao;
    @Autowired
    private SysCodeTableDao sysCodeTableDao;
    @Override
    public void activeUser() {
//        SysCodeTable sysCodeTable = sysCodeTableDao.findCodeBykey(SYSTEM_CONFIG_IDENTIFY_TWO);
//        List<Integer> statusList = new ArrayList<>();
//        statusList.add(TypeEnum.TYPE5.code());//密码错误休眠
//        List<User> users = userQueryDao.findUserByStatus(statusList);
//        users.stream().forEach(user -> {
////            LocalDateTime unLockTime = user.getLoginErrTime().plusHours(Long.valueOf(sysCodeTable.getValue()));
//            LocalDateTime unLockTime = user.getLoginErrTime().plusMinutes(1);
////            锁定时间如果到了，设置状态为激活   并且错误次数清零
//            if (unLockTime.isBefore(LocalDateTime.now())) {
//                user.setStatus(TypeEnum.TYPE1.code());
//                user.setLoginErrCount(0);
//                userQueryDao.updateUser(user);
//                log.info("账号：{}被激活，时间：{}", user.getUserName(), LocalDateTime.now().toString());
//            }
//        });
    }

    @Override
    public void inactiveUser() {
        List<Integer> statusList = new ArrayList<>();
        statusList.add(TypeEnum.TYPE1.code());//激活
        statusList.add(TypeEnum.TYPE5.code());//密码错误休眠
        statusList.add(TypeEnum.TYPE6.code());//新增账号休眠
        statusList.add(TypeEnum.TYPE7.code());//长时间未登录休眠
        List<User> users = userQueryDao.findUserByStatus(statusList);
        users.stream().forEach(user -> {
            //          距离上次登录超过三个月
            long currentSecond = System.currentTimeMillis() / 1000;
            Integer lastLoginTs = user.getLastLoginTs();
            if (user.getStatus() != TypeEnum.TYPE7.code()) {
                if (lastLoginTs == null) {
//                    等于null表示未登录过
                    LocalDateTime createTime = user.getCreateTime().plusMonths(3);
                    if (createTime.isBefore(LocalDateTime.now())) {
                        user.setStatus(TypeEnum.TYPE7.code());
                    }
                }else
                if ((lastLoginTs + threeMonthSeconds) < currentSecond) {
                    user.setStatus(TypeEnum.TYPE7.code());
                }
            }
//          临期账号过期
            LocalDateTime validDate = user.getValidDate();
            if (user.getUserType() == TypeEnum.TYPE2.code() && validDate.isBefore(LocalDateTime.now())) {
                user.setStatus(TypeEnum.TYPE3.code());
            }
            userQueryDao.updateUser(user);
            log.info("账号id：{}被休眠，休眠类型为：{},时间：{}", user.getId(), user.getStatus(), LocalDateTime.now().toString());
        });
    }
}
