package com.wdkj.plugs.extract.schedule;


import com.wdkj.plugs.extract.service.IpMacService;
import com.wdkj.plugs.systemlog.service.ISystemLogService;
import com.wdkj.plugs.utils.enu.LogLevelEnum;
import com.wdkj.plugs.utils.enu.LogTypeEnum;
import com.wdkj.plugs.utils.enu.ServiceTypeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * 定时查询  ip和mac关系表的定时任务  ，当ip变化时，更新任务中的ip    需要快速匹配   30秒执行一次
 */
@Component
public class ProbeTaskIpOrMacUpdateSchedule {

    private static Logger logger = LoggerFactory.getLogger(ProbeTaskIpOrMacUpdateSchedule.class);
    @Autowired
    private IpMacService ipMacService;
    @Autowired
    private ISystemLogService systemLogService;

    @Scheduled(cron = "0 0/5 * * * ? ")
    public void updateIPAndMAC() {
        try {
            ipMacService.excute();
        } catch (Exception e
        ) {
            logger.error("IP,MAC关系更新定时任务报错,{}", e.getMessage());
            systemLogService.saveLog(LogLevelEnum.LEVEL1.code(),e.getMessage(), ServiceTypeEnum.EXTRACT.lable(), LogTypeEnum.LOG_TYPE_ERROR.lable(),"IP,MAC关系更新定时任务", this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName());
        }

    }
}
