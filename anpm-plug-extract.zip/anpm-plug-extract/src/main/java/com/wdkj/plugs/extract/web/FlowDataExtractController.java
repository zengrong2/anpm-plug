package com.wdkj.plugs.extract.web;

import com.wdkj.plugs.core.model.to.Result;
import com.wdkj.plugs.extract.service.IFlowExtractService;
import com.wdkj.plugs.utils.enu.MessageEnum;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Description:
 * Created by zoujian ON 2021/4/15.
 */
@RestController
@RequestMapping("/FlowDataExtract")
public class FlowDataExtractController {

    private static Logger logger = LoggerFactory.getLogger(FlowDataExtractController.class);


    @Autowired
    private IFlowExtractService flowExtractService;


    @PostMapping("/doExtractFlowHourData")
    @ApiOperation(value = "抽取小时流量数据", tags = "流量", httpMethod = "POST")
    public Result<?> doExtractFlowHourData(String startTime, String endTime) {
        try {
            flowExtractService.extractFlowHourData(startTime,endTime);
            return new Result<>(MessageEnum.SUCCESS);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("抽取小时流量数据失败={}" , e.getMessage());
            return new Result<>(MessageEnum.FAIL);
        }
    }

    @PostMapping("/doExtractFlowDayData")
    @ApiOperation(value = "抽取天流量数据", tags = "流量", httpMethod = "POST")
    public Result<?> doExtractFlowDayData(String startTime, String endTime) {
        try {
            flowExtractService.extractFlowDayData(startTime,endTime);
            return new Result<>(MessageEnum.SUCCESS);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("抽取天流量数据失败={}" , e.getMessage());
            return new Result<>(MessageEnum.FAIL);
        }
    }



}
