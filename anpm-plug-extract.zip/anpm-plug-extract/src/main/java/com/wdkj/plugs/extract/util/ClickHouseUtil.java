package com.wdkj.plugs.extract.util;

import org.apache.commons.lang3.StringUtils;
import ru.yandex.clickhouse.ClickHouseConnection;
import ru.yandex.clickhouse.ClickHouseDataSource;
import ru.yandex.clickhouse.settings.ClickHouseProperties;

import java.sql.SQLException;

public class ClickHouseUtil
{

	public static ClickHouseConnection connect(String user,String pwd,String dbName,String dbUrl) 
	{
		ClickHouseProperties properties=new ClickHouseProperties();
		properties.setUser(user);
		if(StringUtils.isNotEmpty(pwd))
		{
		 properties.setPassword(pwd);
		}
		properties.setDatabase(dbName);
		properties.setConnectionTimeout(60000);
		properties.setSocketTimeout(60000);
		properties.setSessionTimeout(60000L);
		ClickHouseConnection connection =null;
	    try 
	    {
	        ClickHouseDataSource dataSource = new ClickHouseDataSource(dbUrl,properties); //default表示数据表 ,port原来为8123
			connection = dataSource.getConnection();
		} catch (SQLException e) {
		    e.printStackTrace();
		} 
        return connection;
	}
}