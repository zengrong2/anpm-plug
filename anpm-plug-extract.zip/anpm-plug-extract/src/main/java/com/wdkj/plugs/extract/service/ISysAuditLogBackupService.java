package com.wdkj.plugs.extract.service;

import com.wdkj.plugs.model.vo.SysAuditLogBackupDefaultValue;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * @ClassName ISysAuditLogBackupService
 * @Description TODO
 * @Author lan
 * @Date 2022/04/06
 */
public interface ISysAuditLogBackupService {
    void dataSourceBackup(LocalDateTime endTime, Boolean isFirstExtract, Map<String, String> map);

    List<SysAuditLogBackupDefaultValue> getBackupDefaultValue();
}
