package com.wdkj.plugs.extract.schedule;

import com.wdkj.plugs.extract.service.IUserService;
import com.wdkj.plugs.systemlog.service.ISystemLogService;
import com.wdkj.plugs.utils.enu.LogLevelEnum;
import com.wdkj.plugs.utils.enu.LogTypeEnum;
import com.wdkj.plugs.utils.enu.ServiceTypeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * @ClassName 用户激活和休眠定时操作
 * @Description TODO
 * @Author guoyang
 * @Date 2022年12月26日17:49:08
 */
@Component
public class UserActiveAndInactiveSchedule {


	private static Logger log = LoggerFactory.getLogger(UserActiveAndInactiveSchedule.class);

    @Autowired
    private IUserService userService;
    @Autowired
    private ISystemLogService systemLogService;
    /**
     * 任务执行频率，1天执行一次
     */
    @Scheduled(cron = "0 0 0/1 * * ? ")
    @Async
    public void userActiveAndInactive(){
        try {
//        休眠账号
            userService.inactiveUser();
        } catch (Exception e) {
            log.error("用户休眠定时任务报错", e);
            systemLogService.saveLog(LogLevelEnum.LEVEL1.code(),e.getMessage(), ServiceTypeEnum.EXTRACT.lable(), LogTypeEnum.LOG_TYPE_ERROR.lable(),"用户休眠定时任务", this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }
}
