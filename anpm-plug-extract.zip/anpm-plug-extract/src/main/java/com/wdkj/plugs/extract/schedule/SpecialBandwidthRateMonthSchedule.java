package com.wdkj.plugs.extract.schedule;

import com.wdkj.plugs.extract.service.ISpecialBandwidthRateMonthService;
import com.wdkj.plugs.extract.util.DateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @ClassName special_bandwidth_rate_month专线流量月表抽取
 * @Description 主要special_bandwidth_rate专线流量表的抽取月数据
 * @Author zengrong
 * @Date 2025/05/14
 */
@Component
public class SpecialBandwidthRateMonthSchedule {
    private static Logger log = LoggerFactory.getLogger(SpecialBandwidthRateMonthSchedule.class);

    @Autowired
    private ISpecialBandwidthRateMonthService specialBandwidthRateMonthService;

    private final Lock lockExecute = new ReentrantLock();


    @Scheduled(cron = "0 */10 * * * ?")
    @Async
    public void executeSpecialBandwidthRateMonth() {
        if (lockExecute.tryLock()) {  // 尝试获取锁
            try {
                log.info("---------start specialBandwidthRateMonth数据抽取月任务开始 Job----------");
                long c = System.currentTimeMillis() / 1000;
                specialBandwidthRateMonthService.analysisDataSpecialBandwidthRateMonth();
                long d = System.currentTimeMillis() / 1000;
                log.info("---------end specialBandwidthRateMonth数据抽取月任务结束 Job----------开始时间:"+ DateUtil.secondToDate(c)+"结束时间:"+ DateUtil.secondToDate(d)+"相差:"+(d-c)/60+"分钟");
            } catch (Exception e) {
                e.printStackTrace();
                log.error("specialBandwidthRateMonth抽取-报错"+e.getMessage());
            } finally {
                lockExecute.unlock();  // 释放锁
                log.info("---------end specialBandwidthRateMonth数据抽取结束任务 Job----------");
            }
        } else {
            log.info("specialBandwidthRateMonth抽取-上一个任务还未完成，跳过本次执行");
        }
    }
}
