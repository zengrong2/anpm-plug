package com.wdkj.plugs.extract.schedule;

import com.wdkj.plugs.core.service.IUserQueryService;
import com.wdkj.plugs.systemlog.service.ISystemLogService;
import com.wdkj.plugs.utils.enu.LogLevelEnum;
import com.wdkj.plugs.utils.enu.LogTypeEnum;
import com.wdkj.plugs.utils.enu.ServiceTypeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * @description:  该定时任务 定时判断 因为前端有轮询保持保持连接状态的  2分钟一次  所以如果spring-session中的数据如果上次访问时间超过2一分钟 则表明  该网站被关闭或者停止  那么删除掉session  并把用户状态更改为离线
 * @author: guoyang
 * @date: 2023/2/10
 **/
@Component
public class UserOnlineSchdeule {
    private static Logger log = LoggerFactory.getLogger(UserOnlineSchdeule.class);


    @Autowired
    private IUserQueryService userQueryService;
    @Autowired
    private ISystemLogService systemLogService;

    /**
     * 任务执行频率，1分钟执行一次
     */
    @Scheduled(cron = "0 0/1 * * * ? ")
    @Async
    public void checkUserOnline(){
        try {
//           检查用户登录状态
            userQueryService.checkUserOnline();
            log.info("用户检查登录状态定时任务成功");
        } catch (Exception e) {
            log.error("用户检查登录状态定时任务报错", e);
            systemLogService.saveLog(LogLevelEnum.LEVEL1.code(),e.getMessage(), ServiceTypeEnum.EXTRACT.lable(), LogTypeEnum.LOG_TYPE_ERROR.lable(),"用户检查登录状态定时任务", this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }
}
