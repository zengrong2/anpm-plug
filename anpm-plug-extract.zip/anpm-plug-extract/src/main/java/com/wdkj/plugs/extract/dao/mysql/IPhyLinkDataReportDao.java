package com.wdkj.plugs.extract.dao.mysql;


import com.wdkj.plugs.core.model.po.Org;
import com.wdkj.plugs.model.po.*;
import com.wdkj.plugs.model.vo.VLinkRouteVo;
import com.wdkj.plugs.model.vo.VRateUnit;
import org.apache.ibatis.annotations.Param;
import org.mapstruct.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * @author lp
 */
@Repository
@Mapper
public interface IPhyLinkDataReportDao {

    Integer getListByDevId(@Param("devId") Integer devId);

    List<VLinkRouteVo> findTopoLinksList();

    Integer getSnmpRepeat(@Param("repeatIds") List<Integer> repeatIds, @Param("orgIds") List<String> orgIds);

    Map<String, String> getSnmpById(@Param("repeatId") String repeatId);

    String getRouteId(@Param("dataSource") Integer dataSource, @Param("bizDataId") String bizDataId);

    List<PhySnmpData> getSnmpRepeats();

    List<PhySnmpData> getSnmpFre();

    List<Map<String, Object>> getProbeId();

    List<ProbeDatas> getSpeculateData();

    List<Map<String, Object>> getOneSpeculateData();

    List<ProbeDatas> getRouteList();

    @Deprecated
    List<String> getDevIps(String devId);

    List<Map<String,Object>> getDevIpIfIps(@Param("devId") String devId);

    void saveLinkData(@Param("linkDatas") List<LinkDataTwo> linkDatas);

    void delLinkData();

//    Integer getListByDevId(@Param("devId")Integer devId);

    void updateLinkData(LinkData linkData);

    String getLinkDataByLinkId(String linkId);

    @Deprecated
    List<String> getSpecialLine(@Param("aip") String aip, @Param("zip") String zip, @Param("orgIds") List<Integer> orgIds);

    Org findOrgById(@Param("id") Integer id);

    List<Org> queryOrgByTreeNumber(@Param("treeNumber") String treeNumber, @Param("treeLevel") Integer treeLevel, @Param("parentId") Integer parentId, @Param("dataScope") String dataScope, @Param("creatorId") Integer creatorId);

    List<SnmpDevPortGroupDevId> findAllSnmpDevPortGroupDevId();

    List<Map<String, Object>> findAllSpecialDataZIp();

    List<Org> findAllOrgs();

    VRateUnit getSnmpTaskRate();

    Integer queryGetherIdByDevice(@Param("deviceId") String deviceId);
}
