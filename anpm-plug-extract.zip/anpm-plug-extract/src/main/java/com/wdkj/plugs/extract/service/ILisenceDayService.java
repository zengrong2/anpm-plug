package com.wdkj.plugs.extract.service;


public interface ILisenceDayService {
    void checkLicence();
}
