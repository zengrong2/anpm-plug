package com.wdkj.plugs.extract.service.impl;


import cn.hutool.core.map.MapUtil;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.wdkj.plugs.extract.dao.mysql.ISpecialDataDisplayIdMapper;
import com.wdkj.plugs.extract.service.ISpecialDataService;
import com.wdkj.plugs.model.po.SpecialData;
import com.wdkj.plugs.model.vo.RepeatVo;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import static com.wdkj.plugs.utils.constant.BaseConstant.*;

/**
 * @ClassName SpecialDataDayServiceImpl
 * @Description TODO
 * @Author liuxf
 * @Date 2021/5/27 10:12
 */
@Service
public class SpecialDataServiceImpl implements ISpecialDataService {

    protected static final Logger logger = LoggerFactory.getLogger(SpecialDataServiceImpl.class);

    private final String leasedLineMatchDialTosRulesKey = "leasedLineMatchDialTosRules";


    @Autowired
    private ISpecialDataDisplayIdMapper specialDataDisplayIdMapper;

    /**
     * 1.匹配中继，先用z端匹配中继对端，未匹配上则用a端匹配中继对端
     * 2.z端匹配多条则中继，再使用a端设备ip匹配中继本端设备ip，如果匹配上并只有一条，则取该中继，如果有多条则取时间最早的那条
     * 3.a端匹配多条则中继，再使用z端设备ip匹配中继本端设备ip，如果匹配上并只有一条，则取该中继，如果有多条则取时间最早的那条
     * 5.后续产品经理张刚力确认，还需要匹配中继的本地地址，
     * 匹配中继，先用z端匹配中继本端，未匹配上则用a端匹配中继本端
     * 2.z端匹配多条则中继，再使用a端设备ip匹配中继本端设备ip，如果匹配上并只有一条，则取该中继，如果有多条则取时间最早的那条
     * 3.a端匹配多条则中继，再使用z端设备ip匹配中继本端设备ip，如果匹配上并只有一条，则取该中继，如果有多条则取时间最早的那条
     * 4.如果该中继有事件持续，直接结束，如果没有事件则取该中继
     * <p>
     * 2023年8月1日
     * 修改需求：
     * 专线匹配拨测任务，现在只按照 专线 Z端IP 进行匹配，不匹配的A端IP 地址了。
     */
    @Override
    public void updatesJob() {
        //查询所有的专线，
        List<SpecialData> selectList = specialDataDisplayIdMapper.getAllList();
        if (CollectionUtils.isEmpty(selectList)) {
            logger.error("未查询到 要进行匹配的专线信息数据");
            return;
        }
        //查询所有中继
        List<RepeatVo> repeatList = specialDataDisplayIdMapper.getRepeatList();

        // 专线匹配拨测TOS规则(1:最小,2:最大)
        Integer tosMatchRules = queryLeasedLineMatchDialTestTosRules();

        Multimap<Integer, RepeatVo> orgMultimap = ArrayListMultimap.create();
        Multimap<String, RepeatVo> destMultimap = ArrayListMultimap.create();
//        Multimap<String, RepeatVo> srcMultimap = ArrayListMultimap.create();
        Multimap<String, RepeatVo> devMultimap = ArrayListMultimap.create();
        // 中继按照机构进行分组
        for (RepeatVo repeatVo : repeatList) {
            orgMultimap.put(repeatVo.getOrgId(), repeatVo);
        }

        // 查询所有的拨测任务，方便专线匹配
        // 提前查询出来，不在for循环里面查询
        List<Map<String, String>> displayIdAllMap = specialDataDisplayIdMapper.getByDisplayIdByOrgAll();
        Map<Integer, Integer> eventDataMap = querySpecDataUnrecoveredEvent();
        // 机构的缓存
        Map<Integer, List<Integer>> orgCacheDataMap = new ConcurrentHashMap<>(255);


        for (SpecialData data : selectList) {

            logger.info("正在匹配专线数据：id:{} , 专线编号：{} ", data.getId(), data.getSpecialNum());

            if (StringUtils.isNotBlank(data.getSpecialIp())) {
                // 是否匹配上了数据
                // 1、判断专线 specialIp 是否是 specialAIp、specialZIp。如在，就要判断 步骤 2.
                // 2、如果优先匹配上了中继信息，就不在进行匹配操作了。
                // 3、如果专线 specialIp 不在 specialAIp、specialZIp 里面，就要吧专线匹配数据进行清空，进行重新匹配。
                //判断专线a端是否修改，主要判断中继信息
                // 如果一开始匹配上了拨测，没有发生事件。同时匹配上了中继信息，这个时候，就需要保存中继匹配，而清空拨测的匹配。
                if (isMatchSpecialAZ(data)) {
                    if (isMatchSnmpRepeat(data)) {
                        // 先判断中继，中继是否匹配上了
                        updateById(data);
                        continue;
                    }
                } else {
                    // 匹配的IP不在 specialAIp、specialZIp 之间，就清空重新匹配
                    data.setDisplayId(null);
                    data.setDialConfigId(null);
                    data.setSnmpRepeatId(null);
                    data.setSnmpRepeatCode(null);
                    data.setState(0);
                    data.setLinkId(null);
                    data.setSpecialIp(null);
                    data.setShowSpecialIp(null);
                    updateById(data);
                }
            }

            List<Integer> orgIdListTemp = Collections.EMPTY_LIST;
            if (orgCacheDataMap.containsKey(data.getOrgId())) {
                orgIdListTemp = orgCacheDataMap.get(data.getOrgId());
            } else {
                // 直接查询
                orgIdListTemp = handleOwnAndBranchOrgIds(data.getOrgId());
                if (orgIdListTemp == null) {
                    orgIdListTemp = new ArrayList<>();
                }
                orgCacheDataMap.put(data.getOrgId(), orgIdListTemp);
            }

            List<Integer> orgIdList = Lists.newArrayList(orgIdListTemp);
            orgIdList.add(0, data.getOrgId());

//            List<Integer> orgIdList = handleOwnAndBranchOrgIds(data.getOrgId());
//            if (orgIdList == null) {
//                orgIdList = new ArrayList<>();
//            }
//            orgIdList.add(0, data.getOrgId());
//            srcMultimap.clear();
            destMultimap.clear();
            devMultimap.clear();
            for (Integer orgId : orgIdList) {
                Collection<RepeatVo> repeatVos = orgMultimap.get(orgId);
                if (repeatVos != null && repeatVos.size() > 0) {
                    for (RepeatVo repeatVo : repeatVos) {
                        String devIp = repeatVo.getDevIp();
                        String srcIp = repeatVo.getSrcIp();
                        String destIp = repeatVo.getDestIp();
//                        srcMultimap.put(srcIp, repeatVo);
                        destMultimap.put(destIp, repeatVo);
                        devMultimap.put(devIp + srcIp, repeatVo);
                        devMultimap.put(devIp + destIp, repeatVo);
                    }
                }
            }
            // 专线是否产生了未恢复的事件
            boolean unrecoveredEvent = isUnrecoveredEvent(eventDataMap.get(data.getId()));
//            boolean unrecoveredEvent = isUnrecoveredEvent(data.getId());

            String specialZIp = data.getSpecialZIp();
            String specialAIp = data.getSpecialAIp();
            String devAIp = StringUtils.isNotBlank(data.getDevAIp()) ? data.getDevAIp() : null;
            String devZIp = StringUtils.isNotBlank(data.getDevZIp()) ? data.getDevZIp() : null;
            if (destMultimap.containsKey(specialZIp) && !unrecoveredEvent && !isMatchDialConfig(data)) {
                //z端匹配中继对端
                extracted(destMultimap, devMultimap, data, specialZIp, devAIp);
                data.setSpecialIp(data.getSpecialZIp());
                data.setShowSpecialIp(data.getShowSpecialZIp());
//                data.setDisplayId(null);
//                data.setDialConfigId(null);
                updateById(data);
            } else if (destMultimap.containsKey(specialAIp) && !unrecoveredEvent && !isMatchDialConfig(data)) {
                //a端匹配中继对端
                extracted(destMultimap, devMultimap, data, specialAIp, devZIp);
                data.setSpecialIp(data.getSpecialAIp());
                data.setShowSpecialIp(data.getShowSpecialAIp());
//                data.setDisplayId(null);
//                data.setDialConfigId(null);
                updateById(data);
            }

            /*else if (srcMultimap.containsKey(specialZIp)) {
                //z端匹配中继本端
                extracted(srcMultimap, devMultimap, data, specialZIp, devAIp);
                data.setSpecialIp(data.getSpecialZIp());
                specialDataDisplayIdMapper.updateById(data);
            } else if (srcMultimap.containsKey(specialAIp)) {
                //a端匹配中继本端
                extracted(srcMultimap, devMultimap, data, specialAIp, devZIp);
                data.setSpecialIp(data.getSpecialAIp());
                specialDataDisplayIdMapper.updateById(data);
            } */

            else {
                // 如果专线有事件，并且匹配上了中继信息，就直接不走匹配拨测下面的逻辑了。
                if (unrecoveredEvent && StringUtils.isNotBlank(data.getSnmpRepeatCode())) {
                    logger.info("专线:{} 匹配上了中继：{} ， 并发生了事件，因此不进行匹配拨测任务了", data.getId(), data.getSnmpRepeatCode());
                    continue;
                }

//                List<Integer> orgIds = handleOwnAndBranchOrgIds(data.getOrgId());
                //查询拨测任务
//                List<Map<String, String>> mapList = specialDataDisplayIdMapper.getByDisplayIdByOrg(specialZIp, orgIds);
                List<Map<String, String>> mapList = getSpecialDataMatchDisplay(displayIdAllMap, specialZIp, orgIdList);
                // 查询拨测任务的数据不存在的时候，需要清空之前的匹配
                if (CollectionUtils.isEmpty(mapList)) {
                    // 说明也没有匹配到中继信息，就直接清空拨测的数据就行了
                    if (StringUtils.isBlank(data.getSnmpRepeatCode())) {
                        // 说明当前的路径变化了。
                        data.setDisplayId(null);
                        data.setDialConfigId(null);
                        data.setSnmpRepeatCode(null);
                        data.setSnmpRepeatId(null);
                        data.setState(0);
                        data.setLinkId(null);
                        data.setSpecialIp(null);
                        data.setShowSpecialIp(null);
                        updateById(data);
                    }
                    continue;
                }

                if (mapList.size() > 1) {
                    // 在原匹配规则上，若匹配到多个拨测任务时，优先取启用的，再根据优先级取【默认优先取优先级低的（TOS值小的），在数据库配置，支持配置取TOS值小的或取TOS值大的】，若TOS值相同，取ID小的
                    Collections.sort(mapList, (o1, o2) -> {
                        // status
                        Integer status1 = MapUtil.getInt(o1, "status", 0);
                        Integer status2 = MapUtil.getInt(o2, "status", 0);
                        // 1：已启用，2：已暂停
                        int statusCompare = status1.compareTo(status2);
                        if (statusCompare == 0) {
                            Integer tos1 = MapUtil.getInt(o1, "tos", 0);
                            Integer tos2 = MapUtil.getInt(o2, "tos", 0);

                            int tosCompare = 0;
                            if (tosMatchRules == 1) {
                                // 1:最小
                                tosCompare = tos1.compareTo(tos2);
                            } else if (tosMatchRules == 2) {
                                // 1:最大
                                tosCompare = tos2.compareTo(tos1);
                            }
                            if (tosCompare == 0) {
                                Integer id1 = MapUtil.getInt(o1, "id", 0);
                                Integer id2 = MapUtil.getInt(o2, "id", 0);
                                return id1.compareTo(id2);
                            } else {
                                return tosCompare;
                            }
                        }
                        return statusCompare;
                    });
                }
                // 批量查询事件
                List<Integer> linkIdAll = mapList.stream().map(datas -> {
                    return MapUtil.getInt(datas, "linkid", -1);
                }).collect(Collectors.toList());
                Map<Integer, Integer> linkDataMap = queryUnrecoveredEventByLinkId(linkIdAll);
                // 最后一次的匹配数据
                // 最后一次的匹配数据
                Map<String, String> dialConfigMap = null;
                //匹配拨测任务
                //查询该任务最新路径是否还包含该专线
                for (Map<String, String> map : mapList) {
                    //数据权限
                    Integer dialConfigId = Integer.valueOf(String.valueOf(map.get("id")));
                    Integer status = Integer.valueOf(String.valueOf(map.get("status")));
                    Integer linkId = Integer.valueOf(String.valueOf(map.get("linkid")));
                    String route_path = MapUtil.getStr(map, "route_path", "");
                    String[] arr = null;
                    if (StringUtils.isNotBlank(route_path)) {
                        arr = route_path.split(",");
                    }

                    String displayId = MapUtil.getStr(map, "display_id", "");
                    String destIp = MapUtil.getStr(map, "dest_ip", "");

                    // 这里可能存在
                    List<String> list = Lists.newArrayList();
                    if (Objects.nonNull(arr) && arr.length > 0) {
                        list = Lists.newArrayList(arr);
                    }
                    if (!list.contains(destIp)) {
                        list.add(destIp);
                    }

                    // 先检查是否是当前已匹配的任务
                    boolean isCurrentTask = StringUtils.isNotBlank(data.getDisplayId()) && data.getDisplayId().equals(displayId);

                    //判断是否有事件未恢复
//                    Integer flag = specialDataDisplayIdMapper.getUnrecoveredEvent(linkId);
                    Integer flag = linkDataMap.getOrDefault(linkId, null);
                    boolean hasEvent = Objects.nonNull(flag) && flag > 0;

                    // 如果有事件且不是当前任务，则跳过
                    if (hasEvent && !isCurrentTask) {
                        logger.info("配置专线 linkId：{}  ,有事件发生（未恢复），不匹配专线了。", linkId);
                        continue;
                    }

                    if (isCurrentTask) {
                        if (!list.contains(data.getSpecialIp())) {
                            dialConfigMap = null;
                            //该任务不包含专线ip了
                            data.setDisplayId(null);
                            data.setDialConfigId(null);
                            data.setState(0);
                            data.setLinkId(null);
                            data.setSpecialIp(null);
                            data.setShowSpecialIp(null);
                            updateById(data);
                        } else {
                            if (list.contains(data.getSpecialZIp())) {
                                data.setSpecialIp(data.getSpecialZIp());
                                data.setShowSpecialIp(data.getShowSpecialZIp());
                            }
                            dialConfigMap = null;
                            if (!linkId.equals(data.getLinkId())) {
                                // 当前任务的linkId发生变化，优先匹配当前任务的新linkId
                                if (hasEvent) {
                                    logger.info("当前任务 linkId：{}  ,有事件发生（未恢复），但保持当前任务匹配。", linkId);
                                }
                                data.setDisplayId(displayId);
                                data.setDialConfigId(dialConfigId);
                                data.setState(status);
                                data.setLinkId(linkId);
                                updateById(data);
                            }
                            break;
                        }
                    } else if (dialConfigMap == null) {
                        // 不是当前任务，保存到dialConfigMap用于后续重新匹配
                        dialConfigMap = map;
                        continue;
                    }
                }
                // 如果查询出来的 拨测任务数据中， 没有一个 displayId 等于当前 专线的 已经匹配的 displayId ，就要重新匹配专线数据。
                // 任意取一条数据进行匹配
                if (dialConfigMap != null) {
                    //数据权限
                    Integer dialConfigId = Integer.valueOf(String.valueOf(dialConfigMap.get("id")));
                    Integer status = Integer.valueOf(String.valueOf(dialConfigMap.get("status")));
                    Integer linkId = Integer.valueOf(String.valueOf(dialConfigMap.get("linkid")));
                    String route_path = MapUtil.getStr(dialConfigMap, "route_path", "");
                    String[] arr = null;
                    if (StringUtils.isNotBlank(route_path)) {
                        arr = route_path.split(",");
                    }
                    String displayId = MapUtil.getStr(dialConfigMap, "display_id", "");
                    String destIp = MapUtil.getStr(dialConfigMap, "dest_ip", "");

                    List<String> list = Lists.newArrayList();
                    if (Objects.nonNull(arr) && arr.length > 0) {
                        list = Lists.newArrayList(arr);
                    }
                    if (!list.contains(destIp)) {
                        list.add(destIp);
                    }
                    if (list.contains(data.getSpecialZIp())) {
                        data.setSpecialIp(data.getSpecialZIp());
                        data.setShowSpecialIp(data.getShowSpecialZIp());
                        data.setDisplayId(displayId);
                        data.setDialConfigId(dialConfigId);
                        data.setState(status);
                        data.setLinkId(linkId);
                        updateById(data);
                    }
                }
            }
        }

    }

    private Map<Integer, Integer> queryUnrecoveredEventByLinkId(List<Integer> linkIdAll) {
        if (CollectionUtils.isEmpty(linkIdAll)) {
            return Collections.EMPTY_MAP;
        }
        Map<Integer, Integer> linkDataMap = new HashMap<>(50);
        List<Map<String, String>> unrecoveredEventAll = specialDataDisplayIdMapper.getUnrecoveredEventAll(linkIdAll);
        if (!CollectionUtils.isEmpty(unrecoveredEventAll)) {
            unrecoveredEventAll.forEach(map -> {
                linkDataMap.put(MapUtil.getInt(map, "linkId", -1), MapUtil.getInt(map, "count", null));
            });
        }
        return linkDataMap;
    }


    private List<Map<String, String>> getSpecialDataMatchDisplay(List<Map<String, String>> displayIdAllMap, String specialZIp, List<Integer> orgIdList) {
//        AND (
//                sl.route_path LIKE CONCAT(#{specialZIp},',%')
//        OR sl.route_path LIKE CONCAT('%,',#{specialZIp},',%')
//        OR sl.route_path LIKE CONCAT('%,',#{specialZIp})
//        OR sl.route_path = #{specialZIp}
//        or sl.dest_ip = #{specialZIp}
//        )
//        <if test="orgList != null and orgList.size() > 0">
//                AND sdc.org_id IN
//            <foreach collection="orgList" item="item" index="" open="(" separator="," close=")">
//                #{item}
//            </foreach>
//        </if>

        if (CollectionUtils.isEmpty(displayIdAllMap)) {
            return Collections.EMPTY_LIST;
        }


        return displayIdAllMap.stream().filter(data -> {
            String route_path = MapUtil.getStr(data, "route_path", "");
            String dest_ip = MapUtil.getStr(data, "dest_ip", "");
            Integer org_id = MapUtil.getInt(data, "org_id", -1);

            // 先判断 route_path 是存在 z_ip
            boolean exists = false;
            String[] ips = StringUtils.split(route_path, ",");
            for (String ip : ips) {
                if (StringUtils.equals(specialZIp, ip)) {
                    exists = true;
                    break;
                }
            }

            // 先判断 dest_ip 是否等于 z_ip
            if (StringUtils.equals(specialZIp, dest_ip)) {
                exists = true;
            }

            // 如果上面都存在了，就判断 org_id
            if (exists) {
                exists = orgIdList.contains(org_id);
            }
            return exists;
        }).collect(Collectors.toList());
    }



    /***
     *   判断专线是否有 未恢复的事件
     */
    private Map<Integer, Integer> querySpecDataUnrecoveredEvent() {
        List<Map<String, String>> dataMap = specialDataDisplayIdMapper.querySpecialUnrecoveredEventDataMap();
        if (CollectionUtils.isEmpty(dataMap)) {
            return Collections.EMPTY_MAP;
        }
        return dataMap.stream().collect(Collectors.toMap(data -> {
            return MapUtil.getInt(data, "taskId", -1);
        }, data -> {
            return MapUtil.getInt(data, "count", -1);
        }));
    }


    /***
     *   是否匹配了拨测
     */
    private boolean isMatchDialConfig(SpecialData data) {
        return Objects.nonNull(data.getDialConfigId());
    }



    /***
     *   判断专线是否有 未恢复的事件
     */
    private boolean isUnrecoveredEvent(Integer count) {
        return Objects.nonNull(count) && count > 0;
    }

//    private boolean isUnrecoveredEvent(Integer taskId) {
//        int count = specialDataDisplayIdMapper.querySpecialUnrecoveredEvent(taskId);
//        return count > 0;
//    }

    private boolean isMatchSnmpRepeat(SpecialData data) {
        return StringUtils.isNotBlank(data.getSnmpRepeatCode())
                || Objects.nonNull(data.getSnmpRepeatId());
    }

    private boolean isMatchSpecialAZ(SpecialData data) {
        return StringUtils.equals(data.getSpecialAIp(), data.getSpecialIp())
                || StringUtils.equals(data.getSpecialZIp(), data.getSpecialIp());
    }

    /***
     *
     * 专线匹配拨测TOS规则(1:最小,2:最大)
     */
    public Integer queryLeasedLineMatchDialTestTosRules() {
        int result = 1;
        String value = specialDataDisplayIdMapper.getSysDataTable(leasedLineMatchDialTosRulesKey);
        if (StringUtils.isNotBlank(value)) {
            try {
                result = Integer.valueOf(value);
            } catch (Exception e) {
                logger.error("查询专线匹配拨测TOS规则 失败 error=>", e);
                result = 1;
            }
            return result;
        }
        return result;
    }

    /***
     * 查询当前及以下机构的ID
     */
    public List<Integer> handleOwnAndBranchOrgIds(Integer orgId) {
        String treeNumber = specialDataDisplayIdMapper.getOrgTreeNumberByOrgId(orgId);
        List<Integer> ownAndBranchOrgIds = new ArrayList<>();
        if (StringUtils.isNotBlank(treeNumber)) {
            ownAndBranchOrgIds = specialDataDisplayIdMapper.findOwnAndBranchOrgIdByTreeNumber(treeNumber);
        }
        return ownAndBranchOrgIds;
    }

    /***
     * 判断中继是否或者拨测是否删除了，删除了就直接清空SpecialData表 display_id，dial_config_id，snmp_repeat_code，snmp_repeat_id
     * @author zxq(956607644 @ qq.com)
     * @date 2023/5/16 18:33
     * @param data

     * @return void
     */
    public void updateById(SpecialData data) {
        assignmentSpecialData(data);
        specialDataDisplayIdMapper.updateById(data);
    }

    /***
     * 防止我在更新操作的时候，同时页面上在删除 拨测任务和中继任务
     */
    private void assignmentSpecialData(SpecialData data) {
        Integer snmpRepeatId = data.getSnmpRepeatId();
        if (Objects.nonNull(snmpRepeatId)) {
            /* <!-- 1已启动、2已暂停、3删除中 --> */
            Integer state = specialDataDisplayIdMapper.getSnmpRepeatById(snmpRepeatId);
            if (Objects.isNull(state)) {
                logger.info("专线匹配中继失效了{}", data);
                data.setSnmpRepeatId(null);
                data.setSnmpRepeatCode(null);
                data.setState(0);
            } else {
                //SpecialData: 0:未关联，1：已启用，2：已暂停，3：删除中
                if (state == FIGURE_1) {
                    data.setState(1);
                } else if (state == FIGURE_2) {
                    data.setState(2);
                }
            }
        } else {
            Integer dialConfigId = data.getDialConfigId();
            if (Objects.nonNull(dialConfigId)) {
                //<!-- 1：启动 0：暂停 -->
                Integer state = specialDataDisplayIdMapper.getTaskDialConfigById(dialConfigId);
                if (Objects.isNull(state)) {
                    logger.info("专线匹配拨测失效了{}", data);
                    data.setDialConfigId(null);
                    data.setDisplayId(null);
                    data.setState(0);
                } else {
                    //SpecialData: 0:未关联，1：已启用，2：已暂停，3：删除中
                    if (state == FIGURE_1) {
                        data.setState(1);
                    } else if (state == FIGURE_0) {
                        data.setState(2);
                    }
                }
            }
        }
        //这里做一个保底的操作。 如果两个匹配都不存在，则清空 bizlinkid
        if (Objects.isNull(data.getDialConfigId()) && Objects.isNull(data.getSnmpRepeatId())) {
            data.setBizLinkId(null);
            data.setState(0);
        }
    }

    private void extracted(Multimap<String, RepeatVo> srcMultimap, Multimap<String, RepeatVo> devMultimap, SpecialData data, String specialAIp, String devZIp) {
        List<RepeatVo> repeatVos = new ArrayList<>(srcMultimap.get(specialAIp));
        if (repeatVos.size() == 1) {
            //a端匹配中继本端有1条
            data.setSnmpRepeatCode(repeatVos.get(0).getSnmpTaskCode());
            data.setSnmpRepeatId(repeatVos.get(0).getId());
            data.setState(repeatVos.get(0).getStatus());
            data.setLinkId(repeatVos.get(0).getLinkId());
        } else {
            //a端匹配中继本端有多条,用z端设备ip+z端匹配中继本端设备ip+对端
            extracted(devMultimap, data, specialAIp, devZIp, repeatVos);
        }
    }

    private void extracted(Multimap<String, RepeatVo> devMultimap, SpecialData data, String specialZIp, String devAIp, List<RepeatVo> repeatVos) {
        if (StringUtils.isNotBlank(devAIp)) {
            if (devMultimap.containsKey(devAIp + specialZIp)) {
                List<RepeatVo> list = new ArrayList<>(devMultimap.get(devAIp + specialZIp));
                data.setSnmpRepeatCode(list.get(0).getSnmpTaskCode());
                data.setSnmpRepeatId(list.get(0).getId());
                data.setState(list.get(0).getStatus());
                data.setLinkId(list.get(0).getLinkId());
            } else {
                //取时间最早的那条中继
                data.setSnmpRepeatCode(repeatVos.get(0).getSnmpTaskCode());
                data.setSnmpRepeatId(repeatVos.get(0).getId());
                data.setState(repeatVos.get(0).getStatus());
                data.setLinkId(repeatVos.get(0).getLinkId());
            }
        } else {
            //取时间最早的那条中继
            data.setSnmpRepeatCode(repeatVos.get(0).getSnmpTaskCode());
            data.setSnmpRepeatId(repeatVos.get(0).getId());
            data.setState(repeatVos.get(0).getStatus());
            data.setLinkId(repeatVos.get(0).getLinkId());
        }
    }

}
