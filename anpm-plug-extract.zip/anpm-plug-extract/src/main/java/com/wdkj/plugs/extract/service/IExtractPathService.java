package com.wdkj.plugs.extract.service;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.concurrent.ExecutionException;

/**
 * @ClassName ExtractSnmpService
 * @Description TODO
 * @Author Mr.xie
 * @Date 2021/10/13 16:59
 */
public interface IExtractPathService {
    void savePathData(Boolean isFirstExtract, LocalDateTime startTime, LocalDateTime end) throws IOException, ClassNotFoundException, InterruptedException, ExecutionException;
}
