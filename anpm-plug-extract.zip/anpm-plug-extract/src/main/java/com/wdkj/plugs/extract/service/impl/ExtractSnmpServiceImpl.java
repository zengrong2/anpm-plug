package com.wdkj.plugs.extract.service.impl;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.wdkj.plugs.core.support.DynamicTableContext;
import com.wdkj.plugs.extract.dao.click.IExtractSnmpClickDao;
import com.wdkj.plugs.extract.dao.mysql.IExtractSnmpDao;
import com.wdkj.plugs.extract.dao.mysql.IIndexSyncDao;
import com.wdkj.plugs.extract.schedule.ExtractPathSchedule;
import com.wdkj.plugs.extract.schedule.ExtractSnmpSchedule;
import com.wdkj.plugs.extract.service.IExtractSnmpService;
import com.wdkj.plugs.extract.util.DateUtil;
import com.wdkj.plugs.model.po.DelaySnmpData;
import com.wdkj.plugs.model.po.ExtractSnmpData;
import com.wdkj.plugs.model.vo.DevFlowVo;
import com.wdkj.plugs.model.vo.VRunTime;

/**
 * @ClassName ExtractSnmpServiceImpl
 * @Description TODO
 * @Author Mr.xie
 * @Date 2021/10/13 17:00
 */
@Service
public class ExtractSnmpServiceImpl implements IExtractSnmpService {
    private static Logger log = LoggerFactory.getLogger(ExtractSnmpServiceImpl.class);
    @Autowired
    private IIndexSyncDao indexSyncDao;
    @Autowired
    private IExtractSnmpDao extractSnmpDao;
    @Autowired
    private IExtractSnmpClickDao extractSnmpClickDao;

    @Resource
    private IExtractSnmpService extractSnmpService;

    @Resource(name = "clickJdbcTemplate")
    private JdbcTemplate jdbcTemplate;

    private static Set<Integer> normalIdList = Sets.newHashSet();

    private void saveSnmpData(List<VRunTime> runTimes, LocalDateTime startTime, LocalDateTime end, List<ExtractSnmpData> snmpDataList) {
        long startTimeSecond = startTime.toEpochSecond(ZoneOffset.of("+8"));
        long endTimeSecond = end.toEpochSecond(ZoneOffset.of("+8"));
        ExtractSnmpSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" 开始 getDevFlowSpeed：\n");
        //流速
        List<DevFlowVo> devFlowSpeed = extractSnmpClickDao.getDevFlowSpeed(startTimeSecond, endTimeSecond);
        ExtractSnmpSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" getDevFlowSpeed 完成 size=").append(devFlowSpeed.size()).append("\n");
        Map<String, DevFlowVo> flowMap = new HashMap<>(255);
        for (DevFlowVo devFlowVo : devFlowSpeed) {
            String key = devFlowVo.getDevIp() + "_" + devFlowVo.getInterfaceIp() + "_" + devFlowVo.getOrgId();
            flowMap.put(key, devFlowVo);
        }
        //初始化使用数据------------
        Set<Integer> linkIdList = runTimes.stream().collect(Collectors.groupingBy(VRunTime::getLinkId)).keySet();
        List<ExtractSnmpData> dataList;
        if (linkIdList.isEmpty()) {
            dataList = new ArrayList<>();
        } else {
            dataList = extractSnmpDao.getRepeatListByLinkId(linkIdList);
        }

        ExtractSnmpSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" dataList：").append(dataList.size()).append("\n");
        Map<Integer, ExtractSnmpData> dataMap = new HashMap<>(255);
        dataList.forEach(it -> {
            dataMap.put(it.getLinkId(), it);
        });
        Map<String, List<DelaySnmpData>> allDataMap = new HashMap<>(255);
        /*dataList.stream().collect(Collectors.groupingBy(it-> DynamicTableContext.genTraceDataTableName(it.getDestIp(), it.getLinkId()))).forEach((k,v)->{*/
        dataList.stream().collect(Collectors.groupingBy(it -> DynamicTableContext.genTraceDataTableName(it.getSnmpId(), it.getLinkId(), it.getDataSource()))).forEach((k, v) -> {
            List<Integer> lIds = v.stream().map(ExtractSnmpData::getLinkId).collect(Collectors.toList());
            List<DelaySnmpData> list = extractSnmpClickDao.getDelayList(k, lIds, startTimeSecond, endTimeSecond);
            list.stream().collect(Collectors.groupingBy(it -> k + it.getLinkId())).forEach(allDataMap::put);
        });
        ExtractSnmpSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" allDataMap：").append(allDataMap.size()).append("\n");
        //初始化使用数据------------
        for (VRunTime runTime : runTimes) {
            ExtractSnmpData snmpData2 = dataMap.get(runTime.getLinkId());
            if (Objects.nonNull(snmpData2)) {
                ExtractSnmpData snmpData = new ExtractSnmpData();
                BeanUtils.copyProperties(snmpData2, snmpData);
                String destIp = snmpData.getDestIp();
                int linkId = snmpData.getLinkId();
                int snmpId = snmpData.getSnmpId();
                Integer dataSource = snmpData.getDataSource();
                /*String tableName = DynamicTableContext.genTraceDataTableName(destIp, linkId);*/
                String tableName = DynamicTableContext.genTraceDataTableName(snmpId, linkId, dataSource);
                List<DelaySnmpData> selfDataList = allDataMap.get(tableName + linkId);
                setDelayLoss(snmpData, selfDataList);
                //封装运行时长
                snmpData.setRunTime(runTime.getRunTime());

                if (runTime.getReportTs() != null) {
                    snmpData.setCreateTs(runTime.getReportTs());
                } else {
                    snmpData.setCreateTs(endTimeSecond);
                }

                //封装流速
                setFlowSpeed(flowMap, snmpData);
                snmpDataList.add(snmpData);
            }
        }
    }

    @Override
    public void saveSnmpData(Boolean isFirstExtract, LocalDateTime startTime, LocalDateTime end) {
        DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        long startTimeSecond = startTime.toEpochSecond(ZoneOffset.of("+8"));
        long endTimeSecond = end.toEpochSecond(ZoneOffset.of("+8"));
        ExtractSnmpSchedule.sb.append("<div  class='c1'><pre>").append(DateUtil.getNowDateTimeString()).append(" 本次时间范围： ").append(startTime).append("-").append(end).append("\n");
        //查询要抽取的中继
        List<ExtractSnmpData> snmpDataList = new ArrayList<>();
        List<Integer> linkIdList = new ArrayList<>();
        try {
            //运行时长
            List<VRunTime> runTimes = extractSnmpClickDao.getRunTimeList(startTimeSecond, endTimeSecond);
            ExtractSnmpSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" runTimes ").append(runTimes.size()).append("\n");
            linkIdList = runTimes.stream().map(VRunTime::getLinkId).collect(Collectors.toList());
            saveSnmpData(runTimes, startTime, end, snmpDataList);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        List<ExtractSnmpData> repairData = new ArrayList<>();
        try {
            //补数据
            List<VRunTime> repairRunTimeList = extractSnmpClickDao.getRepairRunTimeList(startTimeSecond, endTimeSecond);
            Set<Integer> repairLinkIdList = repairRunTimeList.stream().collect(Collectors.groupingBy(VRunTime::getLinkId)).keySet();
            List<ExtractSnmpData> repairDataList;
            if (repairLinkIdList.isEmpty()) {
                repairDataList = new ArrayList<>();
            } else {
                repairDataList = extractSnmpDao.getRepeatListByLinkId(repairLinkIdList);
            }
            
            Map<Integer, ExtractSnmpData> repairDataMap = new HashMap<>(12);
            repairDataList.forEach(it -> {
                repairDataMap.put(it.getLinkId(), it);
            });
            ExtractSnmpSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" repairRunTimeList ").append(repairRunTimeList.size()).append("\n");
            for (VRunTime vRunTime : repairRunTimeList) {
//            ExtractSnmpData data = extractSnmpDao.getRepeatByLinkId(vRunTime.getLinkId());
                ExtractSnmpData data = repairDataMap.get(vRunTime.getLinkId());
                if (Objects.nonNull(data)) {
                    if (normalIdList != null && !normalIdList.contains(data.getLinkId())) {
                        continue;
                    }
                    ExtractSnmpData snmpData = new ExtractSnmpData();
                    BeanUtils.copyProperties(data, snmpData);
                    snmpData.setRunTime(vRunTime.getRunTime());
                    snmpData.setCreateTs(vRunTime.getReportTs());

                    setDelayLoss(snmpData, null);
                    //封装流速
                    setFlowSpeed(new HashMap<>(16), snmpData);
                    repairData.add(snmpData);
                }
            }
            if (normalIdList != null) {
                List<VRunTime> otherRuntimeList = repairRunTimeList.stream().filter(it -> !normalIdList.contains(it.getLinkId())).collect(Collectors.toList());
                saveSnmpData(otherRuntimeList, startTime.minusMinutes(ExtractPathSchedule.extractPathTime), startTime, snmpDataList);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        normalIdList = Sets.newHashSet(linkIdList);
        //保存数据
        snmpDataList.addAll(repairData);
        // 待保存数据集合
        List<ExtractSnmpData> saveList = new ArrayList<>();
        ExtractSnmpSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" 待保存数据总数:snmpDataList ").append(snmpDataList.size()).append("\n");
        System.out.println("待保存数据总数:" + snmpDataList.size());
        for (ExtractSnmpData linkData : snmpDataList) {
            if (Objects.isNull(linkData.getCreateTs())) {
                continue;
            }
            saveList.add(linkData);
            // 批量提交
            if (saveList.size() >= 3000) {
                ExtractSnmpSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" saveList ").append(saveList.size()).append("\n");
                log.info("snmp-保存数据：{}", saveList.toString());
                extractSnmpClickDao.save(saveList);
//                extractSnmpService.batchSaveData(saveList);
                saveList.clear();
            }
        }
        // 处理当前未达到批量条数或者批量后剩余未达到批量条数的信息
        if (!saveList.isEmpty()) {
            ExtractSnmpSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" saveList ").append(saveList.size()).append("\n");
            extractSnmpClickDao.save(saveList);
//            extractSnmpService.batchSaveData(saveList);
            saveList.clear();
        }

        Map<String, String> paramMap = new HashMap<>(2);
        paramMap.put("table", "extract_snmp_data");
        paramMap.put("syncTime", end.format(df));
        // 保存或更新抽取时间
        if (isFirstExtract) {
            indexSyncDao.saveSyncDate(paramMap);
        } else {
            indexSyncDao.updateSyncDate(paramMap);
        }
        ExtractSnmpSchedule.sb.append(DateUtil.getNowDateTimeString()).append(" 完成\n</div>");
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void batchSaveData(List<ExtractSnmpData> saveList) {

        if (CollectionUtils.isEmpty(saveList)) {
            return;
        }

        String sql = "INSERT INTO extract_snmp_data ( link_id, snmp_id, data_source, run_time, create_ts, delay, min_delay, max_delay, avg_flow_into_speed, max_flow_into_speed, avg_flow_out_speed, max_flow_out_speed, lose_rate, min_lose_rate, max_lose_rate, min_flow_into_speed, min_flow_out_speed, sum_delay, sum_lose, delay_count, lose_count, sum_into_speed, into_speed_count, sum_out_speed, out_speed_count ) VALUES ( ?, ?, ?, ?, ?, ?,?, ?, ?, ?,?, ?,?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        Lists.partition(saveList, 500).forEach(list -> {

            jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
                @Override
                public void setValues(java.sql.PreparedStatement ps, int i) throws java.sql.SQLException {
                    ExtractSnmpData data = list.get(i);

// #{item.linkId}, #{item.snmpId}, #{item.dataSource}, #{item.runTime}, #{item.createTs}, #{item.delay}, #{item.minDelay},
//                #{item.maxDelay}, #{item.avgFlowIntoSpeed}, #{item.maxFlowIntoSpeed}, #{item.avgFlowOutSpeed},
//                #{item.maxFlowOutSpeed}, #{item.loseRate}, #{item.minLoseRate}, #{item.maxLoseRate},
//                #{item.minFlowIntoSpeed}, #{item.minFlowOutSpeed}, #{item.sumDelay}, #{item.sumLose}, #{item.delayCount},
//                #{item.loseCount}, #{item.sumIntoSpeed}, #{item.intoSpeedCount}, #{item.sumOutSpeed}, #{item.outSpeedCount}

                    ps.setInt(1, data.getLinkId());
                    ps.setInt(2, data.getSnmpId());
                    ps.setInt(3, data.getDataSource());
                    ps.setLong(4, data.getRunTime());
                    ps.setLong(5, data.getCreateTs());
                    ps.setFloat(6, data.getDelay());
                    ps.setFloat(7, data.getMinDelay());
                    ps.setFloat(8, data.getMaxDelay());
                    ps.setDouble(9, data.getAvgFlowIntoSpeed());
                    ps.setDouble(10, data.getMaxFlowIntoSpeed());
                    ps.setDouble(11, data.getAvgFlowOutSpeed());
                    ps.setDouble(12, data.getMaxFlowOutSpeed());
                    ps.setFloat(13, data.getLoseRate());
                    ps.setFloat(14, data.getMinLoseRate());
                    ps.setFloat(15, data.getMaxLoseRate());
                    ps.setDouble(16, data.getMinFlowIntoSpeed());
                    ps.setDouble(17, data.getMinFlowOutSpeed());
                    ps.setFloat(18, data.getSumDelay());
                    ps.setFloat(19, data.getSumLose());
                    ps.setInt(20, data.getDelayCount());
                    ps.setInt(21, data.getLoseCount());
                    ps.setDouble(22, data.getSumIntoSpeed());
                    ps.setInt(23, data.getIntoSpeedCount());
                    ps.setDouble(24, data.getSumOutSpeed());
                    ps.setInt(25, data.getOutSpeedCount());
                }

                @Override
                public int getBatchSize() {
                    return list.size();
                }
            });


        });

    }

    private void setFlowSpeed(Map<String, DevFlowVo> flowMap, ExtractSnmpData snmpData) {
        String key = snmpData.getDevIp() + "_" + snmpData.getSrcIp() + "_" + snmpData.getOrgId();
        DevFlowVo devFlowVo = flowMap.get(key);
        if (devFlowVo != null) {
            snmpData.setAvgFlowIntoSpeed(devFlowVo.getAvgFlowIntoSpeed());
            snmpData.setMaxFlowIntoSpeed(devFlowVo.getMaxFlowIntoSpeed());
            snmpData.setMinFlowIntoSpeed(devFlowVo.getMinFlowIntoSpeed());
            snmpData.setAvgFlowOutSpeed(devFlowVo.getAvgFlowOutSpeed());
            snmpData.setMaxFlowOutSpeed(devFlowVo.getMaxFlowOutSpeed());
            snmpData.setMinFlowOutSpeed(devFlowVo.getMinFlowOutSpeed());
            snmpData.setSumIntoSpeed(devFlowVo.getSumIntoSpeed());
            snmpData.setSumOutSpeed(devFlowVo.getSumOutSpeed());
            snmpData.setIntoSpeedCount(devFlowVo.getIntoSpeedCount());
            snmpData.setOutSpeedCount(devFlowVo.getOutSpeedCount());
        } else {
            snmpData.setAvgFlowIntoSpeed(-1.0);
            snmpData.setMaxFlowIntoSpeed(-1.0);
            snmpData.setMinFlowIntoSpeed(-1.0);
            snmpData.setAvgFlowOutSpeed(-1.0);
            snmpData.setMaxFlowOutSpeed(-1.0);
            snmpData.setMinFlowOutSpeed(-1.0);
            snmpData.setSumIntoSpeed(0.0);
            snmpData.setSumOutSpeed(0.0);
            snmpData.setIntoSpeedCount(0);
            snmpData.setOutSpeedCount(0);
        }
    }


    private void setDelayLoss(ExtractSnmpData snmpData, List<DelaySnmpData> data) {
        if (data != null && data.size() > 0) {
            snmpData.setDelay((float) data.stream().mapToDouble(DelaySnmpData::getDelay).average().getAsDouble());
            snmpData.setMaxDelay((float) data.stream().mapToDouble(DelaySnmpData::getDelay).max().getAsDouble());
            snmpData.setMinDelay((float) data.stream().mapToDouble(DelaySnmpData::getDelay).min().getAsDouble());
            snmpData.setSumDelay((float) data.stream().filter(it -> it.getDelay() > 0).mapToDouble(DelaySnmpData::getDelay).sum());
            snmpData.setDelayCount((int) data.stream().filter(it -> it.getDelay() > 0).count());
            snmpData.setLoseRate((float) data.stream().mapToDouble(DelaySnmpData::getLoseRate).average().getAsDouble());
            snmpData.setMaxLoseRate((float) data.stream().mapToDouble(DelaySnmpData::getLoseRate).max().getAsDouble());
            snmpData.setMinLoseRate((float) data.stream().mapToDouble(DelaySnmpData::getLoseRate).min().getAsDouble());
            snmpData.setSumLose((float) data.stream().filter(it -> it.getLoseRate() >= 0).mapToDouble(DelaySnmpData::getLoseRate).sum());
            snmpData.setLoseCount((int) data.stream().filter(it -> it.getLoseRate() >= 0).count());
        } else {
            snmpData.setDelay(-1F);
            snmpData.setMaxDelay(-1F);
            snmpData.setMinDelay(-1F);
            snmpData.setLoseRate(-1F);
            snmpData.setMaxLoseRate(-1F);
            snmpData.setMinLoseRate(-1F);
            snmpData.setSumDelay(0F);
            snmpData.setDelayCount(0);
            snmpData.setSumLose(0F);
            snmpData.setLoseCount(0);
        }
    }


//
//    @PostConstruct
//    private void init(){
//        List<ExtractSnmpData> saveList = new ArrayList<>(100);
//        for (int i = 0; i < 100; i++) {
//            ExtractSnmpData data = new ExtractSnmpData();
//            data.setLinkId(i);
//            data.setSnmpId(100);
//            data.setRunTime(i * 5L);
//            data.setDataSource(0);
//            data.setDelay(100F);
//            data.setMinDelay(100F);
//            data.setMaxDelay(100F);
//            data.setAvgFlowIntoSpeed(100D);
//            data.setAvgFlowOutSpeed(100D);
//            data.setMaxFlowIntoSpeed(100D);
//            data.setMaxFlowOutSpeed(100D);
//            data.setMinFlowIntoSpeed(100D);
//            data.setMinFlowOutSpeed(100D);
//            data.setCreateTs(100L);
//            data.setLoseRate(100F);
//            data.setMinLoseRate(100F);
//            data.setMaxLoseRate(100F);
//            data.setSumDelay(100F);
//            data.setSumLose(100F);
//            data.setDelayCount(i);
//            data.setLoseCount(i);
//            data.setSumIntoSpeed(100D);
//            data.setIntoSpeedCount(i);
//            data.setSumOutSpeed(100D);
//            data.setOutSpeedCount(i);
//
//            saveList.add(data);
//        }
//
//        batchSaveData(saveList);
//        log.info("执行成功");
//    }
}
