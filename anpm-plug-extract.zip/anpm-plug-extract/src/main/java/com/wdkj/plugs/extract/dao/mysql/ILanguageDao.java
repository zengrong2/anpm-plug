package com.wdkj.plugs.extract.dao.mysql;

import org.mapstruct.Mapper;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface ILanguageDao {
	//获取当前系统的语言环境
	Integer getLanguage();
}
