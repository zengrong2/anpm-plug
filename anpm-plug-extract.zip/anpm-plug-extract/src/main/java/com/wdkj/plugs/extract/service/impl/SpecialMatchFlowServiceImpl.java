package com.wdkj.plugs.extract.service.impl;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.wdkj.plugs.extract.dao.mysql.ISpecialMatchFlowDao;
import com.wdkj.plugs.extract.service.ISpecialMatchFlowService;
import com.wdkj.plugs.model.po.SnmpInterfaceInfo;
import com.wdkj.plugs.model.po.SpecialMatchFlow;
import com.wdkj.plugs.model.vo.VSpecialMatchVo;
import com.wdkj.plugs.utils.constant.BaseConstant;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.*;

/**
 * @ClassName SpecialMatchFlowServiceImpl
 * @Description TODO
 * @Author Mr.xie
 * @Date 2022/4/19 14:00
 */
@Service
public class SpecialMatchFlowServiceImpl implements ISpecialMatchFlowService {

    private static Logger log = LoggerFactory.getLogger(SpecialMatchFlowServiceImpl.class);


    @Autowired
    private ISpecialMatchFlowDao specialMatchFlowDao;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updatesJob() {
        /*
         * 1.查询所有未匹配流速的专线
         * 2.查询端口信息表
         * (如果匹配上多个则不匹配)
         * 3.专线z端设备ip+专线z端ip匹配snmp_dev_port设备ip+端口ip
         * 4.专线a端设备+专线a端ip匹配snmp_dev_port设备ip+端口ip
         * 4.专线z端ip匹配snmp_dev_port端口ip
         * 4.专线a端ip匹配snmp_dev_port端口ip
         */
        List<VSpecialMatchVo> specialMatchVos = specialMatchFlowDao.getUnSpecialList();
        List<SnmpInterfaceInfo> interfaceInfos = specialMatchFlowDao.getInterfaceInfo();
        if (CollectionUtils.isEmpty(interfaceInfos) || CollectionUtils.isEmpty(specialMatchVos)) {
            log.info("查询接口（snmp_dev_port）与设备（device）匹配关系为空。。。");
            return;
        }
        Multimap<String, SnmpInterfaceInfo> orgMultimap = ArrayListMultimap.create();
        for (SnmpInterfaceInfo interfaceInfo : interfaceInfos) {
            // ipv4和ipv6不能同时为空
            if (StringUtils.isAllBlank(interfaceInfo.getInterfaceIp(), interfaceInfo.getInterfaceIpV6())) {
                continue;
            }
            // ipv6 的处理：防止接口Ip，用;分号分隔，会有多个IP ,interfaceInfo.getInterfaceIpV6()
            specialMatchInterfaceIp(Boolean.TRUE, interfaceInfo, orgMultimap);
            // ipv4 的处理：防止接口Ip，用;分号分隔，会有多个IP ,interfaceInfo.getInterfaceIp()
            specialMatchInterfaceIp(Boolean.FALSE, interfaceInfo, orgMultimap);
        }
        //匹配
        List<SpecialMatchFlow> flows = new LinkedList<>();
        for (VSpecialMatchVo data : specialMatchVos) {
            Integer orgId = data.getOrgId();
            List<Integer> orgList = specialMatchFlowDao.getOrgSectionById(orgId);
            if (orgList == null) {
                orgList = new LinkedList<>();
            }
            orgList.add(0, orgId);
            String specialZIp = data.getSpecialZip();
            String specialAIp = data.getSpecialAip();
            String devAIp = StringUtils.isNotBlank(data.getDevAip()) ? data.getDevAip() : null;
            String devZIp = StringUtils.isNotBlank(data.getDevZip()) ? data.getDevZip() : null;
            for (Integer oId : orgList) {
                if (StringUtils.isNotBlank(devZIp)) {
                    String zk = oId + devZIp + specialZIp;
                    if (extractedZip(orgMultimap, flows, data, zk)) {
                        break;
                    }
                }

                if (StringUtils.isNotBlank(devAIp)) {
                    String ak = oId + devAIp + specialAIp;
                    if (extractedAip(orgMultimap, flows, data, ak)) {
                        break;
                    }
                }

                String zk = oId + specialZIp;
                if (extractedZip(orgMultimap, flows, data, zk)) {
                    break;
                }
                String ak = oId + specialAIp;
                if (extractedAip(orgMultimap, flows, data, ak)) {
                    break;
                }
            }
        }
        if (!CollectionUtils.isEmpty(flows)) {
            specialMatchFlowDao.saveMatchFlow(flows);
        }
    }

    private void specialMatchInterfaceIp(boolean ipv6State, SnmpInterfaceInfo interfaceInfo, Multimap<String, SnmpInterfaceInfo> orgMultimap) {
        String interfaceIp = interfaceInfo.getInterfaceIp();
        if (ipv6State) {
            interfaceIp = interfaceInfo.getInterfaceIpV6();
        }
        if (StringUtils.isBlank(interfaceIp)) {
            return;
        }
        // 防止接口Ip，用;分号分隔，会有多个IP ，需要去重判断。
        // 2025:10:1234:5677:abcd:efff:aaaa:bbb3;2025::5678:abcd:efff:aaaa:bbb3;2025:10:1234:5678:abcd:efff:aaaa:bbb3;2025:10:0:5678:abcd:efff:aaaa:bbb3;93.0.0.6;97.0.0.6
        String[] interfaceIpSplit = interfaceIp.split(BaseConstant.SEMICOLON);
        Set<String> interfaceIps = new HashSet<>();
        for (String ip : interfaceIpSplit) {
            interfaceIps.add(ip);
        }
        for (String interfaceIpStr : interfaceIps) {
            SnmpInterfaceInfo newSnmpInterfaceInfo = copy(interfaceInfo);
            // 这里单独设置下 接口IP，不然数据库会插入多个IP
            newSnmpInterfaceInfo.setInterfaceIp(interfaceIpStr);

            String k = newSnmpInterfaceInfo.getOrgId() + newSnmpInterfaceInfo.getDevIp() +
                    StringUtils.defaultIfBlank(interfaceIpStr, "");
            String k1 = newSnmpInterfaceInfo.getOrgId() +
                    StringUtils.defaultIfBlank(interfaceIpStr, "");

            if (orgMultimap.get(k) == null || orgMultimap.get(k).isEmpty()) {
                orgMultimap.put(k, newSnmpInterfaceInfo);
            }
            if (orgMultimap.get(k1) == null || orgMultimap.get(k1).isEmpty()) {
                orgMultimap.put(k1, newSnmpInterfaceInfo);
            }
        }
    }

    private SnmpInterfaceInfo copy(SnmpInterfaceInfo interfaceInfo) {
        SnmpInterfaceInfo toObject = new SnmpInterfaceInfo();
        BeanUtils.copyProperties(interfaceInfo, toObject);
        return toObject;
    }


    private boolean extractedAip(Multimap<String, SnmpInterfaceInfo> orgMultimap, List<SpecialMatchFlow> flows, VSpecialMatchVo data, String ak) {
        if (orgMultimap.containsKey(ak)) {
            ArrayList<SnmpInterfaceInfo> list = new ArrayList<>(orgMultimap.get(ak));
            if (list.size() > 1) {
                //匹配上多条，则不匹配
                return false;
            }
            SnmpInterfaceInfo info = list.get(0);
            if (StringUtils.isNotBlank(info.getInterfaceIp())) {
                //  先判断ipv4接口地址
                SpecialMatchFlow specialMatchFlow = new SpecialMatchFlow(data.getId(), info.getDevIp(), info.getInterfaceIp(), 1, info.getOrgId());
                specialMatchFlow.setDevId(info.getDevId());
                specialMatchFlow.setInterfaceId(info.getInterfaceId());
                specialMatchFlow.setCreateTime(new Date());
                if (!existsSpecialMatchFlow(specialMatchFlow)) {
                    flows.add(specialMatchFlow);
                }
            }
            if (StringUtils.isNotBlank(info.getInterfaceIpV6())) {
                // 再判断ipv6接口地址
                SpecialMatchFlow specialMatchFlowIpV6 = new SpecialMatchFlow(data.getId(), info.getDevIp(), info.getInterfaceIpV6(), 1, info.getOrgId());
                specialMatchFlowIpV6.setDevId(info.getDevId());
                specialMatchFlowIpV6.setInterfaceId(info.getInterfaceId());
                specialMatchFlowIpV6.setCreateTime(new Date());
                if (!existsSpecialMatchFlow(specialMatchFlowIpV6)) {
                    flows.add(specialMatchFlowIpV6);
                }
            }
            return true;
        }
        return false;
    }

    private boolean extractedZip(Multimap<String, SnmpInterfaceInfo> orgMultimap, List<SpecialMatchFlow> flows, VSpecialMatchVo data, String zk) {
        if (orgMultimap.containsKey(zk)) {
            ArrayList<SnmpInterfaceInfo> list = new ArrayList<>(orgMultimap.get(zk));
            if (list.size() > 1) {
                //匹配上多条，则不匹配
                log.error("此错误消息忽略，专线匹配流量，匹配了多条数据接口信息。专线ID：{}，flowsSize：{}", data.getId(), list.size());
                return false;
            }
            SnmpInterfaceInfo info = list.get(0);
            if (StringUtils.isNotBlank(info.getInterfaceIp())) {
                //  先判断ipv4接口地址
                SpecialMatchFlow specialMatchFlow = new SpecialMatchFlow(data.getId(), info.getDevIp(), info.getInterfaceIp(), 0, info.getOrgId());
                specialMatchFlow.setDevId(info.getDevId());
                specialMatchFlow.setInterfaceId(info.getInterfaceId());
                specialMatchFlow.setCreateTime(new Date());
                if (!existsSpecialMatchFlow(specialMatchFlow)) {
                    flows.add(specialMatchFlow);
                }
            }

            if (StringUtils.isNotBlank(info.getInterfaceIpV6())) {
                // 再判断ipv6接口地址
                SpecialMatchFlow specialMatchFlowIpV6 = new SpecialMatchFlow(data.getId(), info.getDevIp(), info.getInterfaceIpV6(), 0, info.getOrgId());
                specialMatchFlowIpV6.setDevId(info.getDevId());
                specialMatchFlowIpV6.setInterfaceId(info.getInterfaceId());
                specialMatchFlowIpV6.setCreateTime(new Date());
                if (!existsSpecialMatchFlow(specialMatchFlowIpV6)) {
                    flows.add(specialMatchFlowIpV6);
                }
            }
            return true;
        }
        return false;
    }

    private boolean existsSpecialMatchFlow(SpecialMatchFlow specialMatchFlow) {
        int exists = specialMatchFlowDao.existsSpecialMatchFlow(specialMatchFlow);
        return exists > 0;
    }
}
