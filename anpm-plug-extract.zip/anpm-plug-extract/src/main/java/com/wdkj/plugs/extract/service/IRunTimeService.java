package com.wdkj.plugs.extract.service;

public interface IRunTimeService {

    void analysisData(Integer type);

}
