package com.wdkj.plugs.extract.service;

public interface LanguageService {
    void setLanguage();
}
