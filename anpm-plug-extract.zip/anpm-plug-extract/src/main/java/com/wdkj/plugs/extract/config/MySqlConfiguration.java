//package com.wdkj.plugs.extract.config;
//
//
//import com.alibaba.druid.pool.DruidDataSource;
//import org.apache.ibatis.session.SqlSessionFactory;
//import org.mybatis.spring.SqlSessionFactoryBean;
//import org.mybatis.spring.annotation.MapperScan;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.Primary;
//import org.springframework.core.io.Resource;
//import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
//import org.springframework.core.io.support.ResourcePatternResolver;
//
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.List;
//
//import javax.sql.DataSource;
//
//@Configuration
//@MapperScan(basePackages = "com.wdkj.plugs.**.dao", sqlSessionFactoryRef = "mysqlSqlSessionFactory")
//public class MySqlConfiguration
//{
//
//	private final Logger logger = LoggerFactory.getLogger(this.getClass());
//	/**
//	 * 数据库连接配置
//	 */
//	@Value("${spring.datasource.mysql.jdbcUrl}")
//	private String url;
//	@Value("${spring.datasource.mysql.username}")
//	private String user;
//	@Value("${spring.datasource.mysql.password}")
//	private String password;
//	@Value("${spring.datasource.mysql.driver-class-name}")
//	private String driverClass;
//	@Value("${spring.datasource.mysql.type}")
//	private String type;
//	/**
//	 * druid配置
//	 */
//	@Value("${spring.datasource.druid.maxActive}")
//	private Integer maxActive;
//	@Value("${spring.datasource.druid.minIdle}")
//	private Integer minIdle;
//	@Value("${spring.datasource.druid.initialSize}")
//	private Integer initialSize;
//	@Value("${spring.datasource.druid.maxWait}")
//	private Long maxWait;
//	@Value("${spring.datasource.druid.timeBetweenEvictionRunsMillis}")
//	private Long timeBetweenEvictionRunsMillis;
//	@Value("${spring.datasource.druid.minEvictableIdleTimeMillis}")
//	private Long minEvictableIdleTimeMillis;
//	@Value("${spring.datasource.druid.validationQuery}")
//	private String validationQuery;
//	@Value("${spring.datasource.druid.testWhileIdle}")
//	private Boolean testWhileIdle;
//	@Value("${spring.datasource.druid.testWhileIdle}")
//	private Boolean testOnBorrow;
//	@Value("${spring.datasource.druid.testOnBorrow}")
//	private Boolean testOnReturn;
//	@Value("${spring.datasource.druid.poolPreparedStatements}")
//	private Boolean poolPreparedStatements;
//	@Value("${spring.datasource.druid.maxPoolPreparedStatementPerConnectionSize}")
//	private Integer maxPoolPreparedStatementPerConnectionSize;
//
//	@Primary
//	@Bean(name = "mysqlDataSource")
//	public DataSource masterDataSource()
//	{
//		// return DataSourceBuilder.create().build();
//
//		logger.info("Init Mysql...");
//		DruidDataSource dataSource = new DruidDataSource();
//		dataSource.setDriverClassName(driverClass);
//		dataSource.setUrl(url);
//		dataSource.setUsername(user);
//		dataSource.setPassword(password);
//		dataSource.setDbType(type);
//
//		// 连接池配置
//		dataSource.setMaxActive(maxActive);
//		dataSource.setMinIdle(minIdle);
//		dataSource.setInitialSize(initialSize);
//		dataSource.setMaxWait(maxWait);
//		dataSource.setTimeBetweenEvictionRunsMillis(timeBetweenEvictionRunsMillis);
//		dataSource.setMinEvictableIdleTimeMillis(minEvictableIdleTimeMillis);
//		dataSource.setTestWhileIdle(testWhileIdle);
//		dataSource.setTestOnBorrow(testOnBorrow);
//		dataSource.setTestOnReturn(testOnReturn);
//		dataSource.setValidationQuery(validationQuery);
//
//		dataSource.setPoolPreparedStatements(poolPreparedStatements);
//		dataSource.setMaxPoolPreparedStatementPerConnectionSize(maxPoolPreparedStatementPerConnectionSize);
//
//		return dataSource;
//	}
//
//
//	@Primary
//	@Bean(name = "mysqlSqlSessionFactory")
//	public SqlSessionFactory sqlSessionFactory(@Qualifier("mysqlDataSource") DataSource dataSource) throws Exception
//	{
//		SqlSessionFactoryBean sessionFactoryBean = new SqlSessionFactoryBean();
//		sessionFactoryBean.setDataSource(dataSource);
//		// 注意： com/example/mybatis_demo/mapper/mysql/ 下必须至少要有一个文件，否则启动会失败
//		sessionFactoryBean.setMapperLocations(resolveMapperLocations());
//		//classpath*:config/SqlMapConfig.xml
//		sessionFactoryBean.setConfigLocation(new PathMatchingResourcePatternResolver().getResource("classpath:SqlMapConfig.xml"));//config/
//		//type-aliases-package: com.wdkj.plugs.model.po
//		sessionFactoryBean.setTypeAliasesPackage("com.wdkj.plugs.model.po,com.wdkj.plugs.core.model.po");
//
//		return sessionFactoryBean.getObject();
//	}
//	public Resource[] resolveMapperLocations() throws Exception{
//		ResourcePatternResolver resourceResolver = new PathMatchingResourcePatternResolver();
//		List<String> mapperLocations = new ArrayList<>();
//		mapperLocations.add("classpath*:com/wdkj/plugs/**/dao/*.xml");
//		mapperLocations.add("classpath*:com/wdkj/plugs/**/dao/mysql/*.xml");
//		List<Resource> resources = new ArrayList<>();
//		if (mapperLocations != null) {
//			for (String mapperLocation : mapperLocations) {
//				Resource[] mappers = resourceResolver.getResources(mapperLocation);
//				resources.addAll(Arrays.asList(mappers));
//			}
//		}
//		return resources.toArray(new Resource[resources.size()]);
//	}
//}
