package com.wdkj.plugs.extract.bean;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

public class Result<T> implements Serializable {
    private static final long serialVersionUID = 1L;
    @ApiModelProperty("响应码")
    private int code = 1;
    @ApiModelProperty("结果对象")
    private T data = null;
    @ApiModelProperty("响应消息")
    private String msg = "";

    public Result() {
    }

    public Result(T data) {
        this.data = data;
    }

    public Result(MessageEnum code) {
        this.code = code.code();
        this.msg = code.lable();
    }

    public Result(MessageEnum code, String msg) {
        this.code = code.code();
        this.msg = msg;
    }

    public Result(MessageEnum code, T data) {
        this.code = code.code();
        this.msg = code.lable();
        this.data = data;
    }

    public Result(MessageEnum code, String msg, T data) {
        this.code = code.code();
        this.msg = msg;
        this.data = data;
    }

    public Result(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Result(int code, T data) {
        this.code = code;
        this.data = data;
    }

    public Result(int code, String msg, T data) {
        this.code = code;
        this.msg = msg;
        this.data = data;
    }

    public int getCode() {
        return this.code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public Object getData() {
        return this.data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public String getMsg() {
        return this.msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
