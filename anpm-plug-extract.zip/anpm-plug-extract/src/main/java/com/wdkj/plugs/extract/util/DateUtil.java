package com.wdkj.plugs.extract.util;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;

/**
 * @ClassName DateUtil
 * @Description TODO
 * @Author Mr.xie
 * @Date 2021/12/13 14:26
 */
public class DateUtil {
    public static LocalDateTime getNear5(LocalDateTime dateTime) {
        if (null == dateTime) {
            return null;
        }
        Integer minute = dateTime.getMinute();
        minute = minute/5*5;
        return LocalDateTime.of(dateTime.getYear(), dateTime.getMonth(), dateTime.getDayOfMonth(), dateTime.getHour(), minute, 0);
    }
    /**
     * 秒转换为指定格式的日期
     *
     * @param second
     * @return
     */
    public static String secondToDate(long second) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(second * 1000);// 转换为毫秒
        Date date = calendar.getTime();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String dateString = format.format(date);
        return dateString;
    }
    static String format = "yyyy-MM-dd HH:mm:ss.S";    		
	public static SimpleDateFormat formatter = new SimpleDateFormat(format);
    public static String getNowDateTimeString() {
    	return formatter.format(new Date());
    }
}
