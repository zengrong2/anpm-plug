package com.wdkj.plugs.extract.schedule;

import com.wdkj.plugs.extract.service.IIndexSyncService;
import com.wdkj.plugs.extract.service.ISysAuditLogBackupService;
import com.wdkj.plugs.model.vo.SysAuditLogBackupDefaultValue;
import com.wdkj.plugs.systemlog.service.ISystemLogService;
import com.wdkj.plugs.utils.enu.LogLevelEnum;
import com.wdkj.plugs.utils.enu.LogTypeEnum;
import com.wdkj.plugs.utils.enu.ServiceTypeEnum;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @ClassName 审计日志存储备份
 * @Description TODO
 * @Author lan
 * @Date 2022/04/06
 */
@Component
public class SysAuditLogBackupSchedule {
    private static Logger log = LoggerFactory.getLogger(SysAuditLogBackupSchedule.class);

    private final static String DATABASE_BACKUP = "sys_audit_log";// 备份的表名
    private static final String SYSTEM_CONFIG_AUDIT_ONE = "SYSTEM_CONFIG_AUDIT_ONE";// 备份周期

    @Autowired
    private IIndexSyncService indexSyncService;
    @Autowired
    private ISysAuditLogBackupService sysAuditLogBackupService;
    @Autowired
    private ISystemLogService systemLogService;

    /**
     * 任务执行频率，每小时执行一次
     */
//    @Scheduled(cron = "0 0 1 * * ?")
//    @Scheduled(cron = "0 26,29,33 * * * ?")
    @Scheduled(cron = "0 */60 * * * ?")
//    @Async
    public void execute() {
        log.info("---------start 日志备份任务开始 Job----------");
        try {
            LocalDateTime now = LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES);
            log.info("当前时间now:" + now);
            DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            LocalDateTime lastDateTime = null;
            boolean isFirstExtract = false;
            // 获取数据库备份最后一次执行的时间
            String lastTime = indexSyncService.getLastDateByName(DATABASE_BACKUP);
            if (StringUtils.isBlank(lastTime)) {
                isFirstExtract = true;
                lastDateTime = now;
            } else {
                lastDateTime = LocalDateTime.parse(lastTime,df);
            }
            // 获取自动备份默认值
            List<SysAuditLogBackupDefaultValue> list = sysAuditLogBackupService.getBackupDefaultValue();
            Map<String, String> map = new HashMap<>(16);
            for (SysAuditLogBackupDefaultValue defaultValue : list) {
                map.put(defaultValue.getKey(), defaultValue.getValue());
            }
            // 备份周期
            Long saveCycleDate = Long.parseLong(map.get(SYSTEM_CONFIG_AUDIT_ONE));
            // 获取理论上备份的时间
//            LocalDateTime cycleDateTime = LocalDateTime.parse(now.minusDays(saveCycleDate).format(df),df);
            // 获取当前时间和上次备份时间相差的天数
            Duration duration = Duration.between(lastDateTime,now);
            Long differDays =  duration.toDays();
            // 判断当前时间是否满足备份的周期条件 differDays == 0:表示第一次备份
            boolean flag2 = differDays == 0 && StringUtils.isEmpty(lastTime);
            if (differDays >= saveCycleDate || flag2){
                // 执行备份
                log.info("---------sysAuditLogBackup-执行日志备份！----------");
                sysAuditLogBackupService.dataSourceBackup(now,isFirstExtract,map);
            } else {
                // 表示还没到备份日期,加上备份周期
                 log.info("-sysAuditLogBackup-未到日志备份时间！下一次备份日期：{}-当前日期：{}",lastDateTime.plusDays(saveCycleDate).format(df),now.format(df));
            }
            log.info("-----sysAuditLogBackup-----End 日志备份任务结束 Job----------");
        } catch (Exception e) {
            log.error("-sysAuditLogBackup-日志备份任务出错:" + e.getMessage(), e);
            systemLogService.saveLog(LogLevelEnum.LEVEL1.code(),e.getMessage(), ServiceTypeEnum.EXTRACT.lable(), LogTypeEnum.LOG_TYPE_ERROR.lable(),"sysAuditLogBackup-日志备份任务", this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }
}
