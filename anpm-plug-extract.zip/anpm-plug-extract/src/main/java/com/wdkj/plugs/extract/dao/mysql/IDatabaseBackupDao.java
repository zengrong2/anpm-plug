package com.wdkj.plugs.extract.dao.mysql;

import com.wdkj.plugs.model.po.BackupTableConfig;
import com.wdkj.plugs.model.po.DatabaseBackup;
import com.wdkj.plugs.model.vo.BackupDefaultValue;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @ClassName IDatabaseBackupDao
 * @Description TODO
 * @Author Mr.xie
 * @Date 2021/10/20 10:05
 */
@Repository
@Mapper
public interface IDatabaseBackupDao {
    List<BackupDefaultValue> getBackupDefaultValue();

    void saveBackRecord(DatabaseBackup backup);

    void delBackRecord();

    int updateBaseBackupsById(DatabaseBackup backup);

    Integer getBaseBackupsById(@Param("taskId") String taskId);

    List<BackupTableConfig> getBackTabConfig();

    List<BackupTableConfig> list();
}
