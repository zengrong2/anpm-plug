package com.wdkj.plugs.extract.service.impl;

import com.wdkj.plugs.extract.dao.click.IFlowExtractClickDao;
import com.wdkj.plugs.extract.service.IFlowExtractService;
import com.wdkj.plugs.model.po.SnmpFlowExtraceInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Description:
 * Created by zoujian ON 2021/4/16.
 */
@Service("flowExtractService")
public class FlowExtractServiceImpl implements IFlowExtractService {

    @Autowired
    private IFlowExtractClickDao flowExtractClickMapper;

    private static final int PAGE_MAX_SIZE = 5000;


    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    
    /**
    　* @description: 抽取流量小时数据
    　* @param
    　* @return  
    　* @author zoujian
    　* @date 2021/4/16 10:42 
    　*/
    @Override
    public void extractFlowHourData(String startTime, String endTime) {
        Long insertTime = new Long(0);
        LocalDateTime dateTime = LocalDateTime.parse(startTime, DATE_TIME_FORMATTER);
        insertTime = dateTime.atZone(ZoneOffset.of("+8")).toInstant().toEpochMilli()/1000;
        //抽取小时数据
        List<SnmpFlowExtraceInfo> flowHourDataList = flowExtractClickMapper.extractFlowHourData(startTime, endTime);
        //删除小时数据
        flowExtractClickMapper.deleteFlowHourData(startTime, endTime);
        if(flowHourDataList != null && !flowHourDataList.isEmpty()){
            int total = flowHourDataList.size();
            if(total>PAGE_MAX_SIZE){
                for(int i=0; i<total; i=i+PAGE_MAX_SIZE){
                    int curIndex = (i+PAGE_MAX_SIZE)>total?total:i+PAGE_MAX_SIZE;
                    List<SnmpFlowExtraceInfo> saveList = flowHourDataList.subList(i,curIndex);
                    flowExtractClickMapper.addFlowHourData(saveList, insertTime);
                }
            }else{
                flowExtractClickMapper.addFlowHourData(flowHourDataList, insertTime);
            }
        }
    }

    /**
    　* @description: 抽取流量天数据
    　* @param
    　* @return
    　* @author zoujian
    　* @date 2021/4/16 10:43
    　*/
    @Override
    public void extractFlowDayData(String startTime, String endTime) {
        Long insertTime = new Long(0);
        LocalDateTime dateTime = LocalDateTime.parse(startTime, DATE_TIME_FORMATTER);
        insertTime = dateTime.atZone(ZoneOffset.of("+8")).toInstant().toEpochMilli()/1000;
        //抽取天数据
        List<SnmpFlowExtraceInfo> flowDayDataList = flowExtractClickMapper.extractFlowDayData(startTime, endTime);
        //删除天数据
        flowExtractClickMapper.deleteFlowDayData(startTime, endTime);
        if(flowDayDataList != null && !flowDayDataList.isEmpty()){
            int total = flowDayDataList.size();
            if(total>PAGE_MAX_SIZE){
                for(int i=0; i<total; i=i+PAGE_MAX_SIZE){
                    int curIndex = (i+PAGE_MAX_SIZE)>total?total:i+PAGE_MAX_SIZE;
                    List<SnmpFlowExtraceInfo> saveList = flowDayDataList.subList(i,curIndex);
                    flowExtractClickMapper.addFlowDayData(saveList, insertTime);
                }
            }else{
                flowExtractClickMapper.addFlowDayData(flowDayDataList, insertTime);
            }
        }

    }
}
