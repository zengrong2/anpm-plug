package com.wdkj.plugs.extract.service;

import com.wdkj.plugs.model.vo.BackupDefaultValue;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * @ClassName DatabaseBackupService
 * @Description TODO
 * @Author Mr.xie
 * @Date 2021/10/20 10:03
 */
public interface IDatabaseBackupService {
    void dataSourceBackup(LocalDateTime endTime,Boolean isFirstExtract, Map<String, String> map);

    List<BackupDefaultValue> getBackupDefaultValue();
}
