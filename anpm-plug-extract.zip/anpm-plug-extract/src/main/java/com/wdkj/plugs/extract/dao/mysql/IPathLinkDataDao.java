package com.wdkj.plugs.extract.dao.mysql;


import com.wdkj.plugs.model.po.EngineRoute;
import com.wdkj.plugs.model.vo.PathLinkDataVo;
import org.mapstruct.Mapper;
import org.springframework.stereotype.Repository;
import java.util.List;

/**
 *
 * @author lp
 *
 */
@Repository
@Mapper
public interface IPathLinkDataDao {

    List<PathLinkDataVo> getPathLinkDataList();

    List<PathLinkDataVo> getTaskRouteList();

    void delete();

    List<EngineRoute> getRouteList();

}
