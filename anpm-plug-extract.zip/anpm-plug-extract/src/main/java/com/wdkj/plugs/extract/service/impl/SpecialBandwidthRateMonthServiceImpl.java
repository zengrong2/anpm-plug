package com.wdkj.plugs.extract.service.impl;

import com.alibaba.excel.util.StringUtils;
import com.wdkj.plugs.extract.dao.click.IExtractSpecialClickDao;
import com.wdkj.plugs.extract.dao.mysql.IExtractSpecialDao;
import com.wdkj.plugs.extract.dao.mysql.IIndexSyncDao;
import com.wdkj.plugs.extract.service.ISpecialBandwidthRateMonthService;
import com.wdkj.plugs.model.po.SpecialBandwidthRateMonth;
import com.wdkj.plugs.utils.date.DateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.sql.DataSource;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * @author zr
 */
@Service
public class SpecialBandwidthRateMonthServiceImpl implements ISpecialBandwidthRateMonthService {

    private static Logger log = LoggerFactory.getLogger(SpecialBandwidthRateMonthServiceImpl.class);

    @Autowired
    private IExtractSpecialClickDao extractSpecialClickDao;

    @Autowired
    private IIndexSyncDao indexSyncDao;

    @Autowired
    private IExtractSpecialDao extractSpecialDao;


    private String tableName="special_bandwidth_rate_month";

    //检查抽取范围默认3个月
    @Value("${extract-specialBandwidthRateMonth-checkMonth:3}")
    private Integer monthCount;

    //一次性插入数据库条数默认5w
    @Value("${extract-specialBandwidthRateMonth-saveCount:50000}")
    public Integer extractSflowAnalysisSaveCount;

    @Value("${extract-specialBandwidthRateMonth-queryGroupCount:10}")
    private Integer queryGroupCount;

    //插入数据库线程数量默认2个
    /*@Value("${extract-specialBandwidthRateMonth-insertDataThreadPool:2}")
    private Integer insertDataThreadPool;*/


    private JdbcTemplate jdbcTemplate;
    @Autowired
    public void setJdbcTemplate(@Qualifier("clickDataSource") DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }



    @Override
    public void analysisDataSpecialBandwidthRateMonth(){
        try {
            Boolean isFirstExtract = true;
            String syncTime = indexSyncDao.getLastDateByName(tableName);
            if(StringUtils.isNotBlank(syncTime)){
                isFirstExtract = false;
            }
            // 获取当前时间范围的结束时间列表
            List<Long> endTimeList = new ArrayList<>();
            //获取三个月内所有的月数据
            handelSyncTimeToMonthCurrTimeAllMonths(syncTime, endTimeList);

            endTimeList = endTimeList.stream().distinct().sorted().collect(Collectors.toList());
            // 异步处理每个时间段的数据
            if (!CollectionUtils.isEmpty(endTimeList)) {
                try {
                    List<Integer> specialIds = extractSpecialDao.findAllSpecialIds();
                    for (Long endTime : endTimeList) {
                        // 计算每个时间段的起始时间，通过结束时间戳计算得到起始时间是上个月的01 00:00:00的时间戳
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTimeInMillis(endTime * 1000L);
                        calendar.add(Calendar.MONTH, -1); // 上个月
                        calendar.set(Calendar.DAY_OF_MONTH, 1); // 设置为1号
                        calendar.set(Calendar.HOUR_OF_DAY, 0);
                        calendar.set(Calendar.MINUTE, 0);
                        calendar.set(Calendar.SECOND, 0);
                        calendar.set(Calendar.MILLISECOND, 0);
                        Long startTime = calendar.getTimeInMillis() / 1000; // 转换为秒
                        extractSpecialClickDao.deleteSpecialBandwidthRateMonthByTime(startTime, endTime);
                        if(!CollectionUtils.isEmpty(specialIds)){
                            List<SpecialBandwidthRateMonth> specialBandwidthRateMonths = new ArrayList<>();
                            // 将 specialIds 按每10个分组
                            int specialIdsBatchSize = queryGroupCount;
                            for (int i = 0; i < specialIds.size(); i += specialIdsBatchSize) {
                                List<Integer> batchIds = specialIds.subList(i, Math.min(i + specialIdsBatchSize, specialIds.size()));
                                //查询98峰值下标值
                                List<SpecialBandwidthRateMonth> bandwidthRateNineEightCounts = extractSpecialClickDao.findSpecialBandwidthRateNineEightCountBySpecialIds(batchIds, startTime, endTime,true);
                                //获取入带宽98峰值数据
                                Map<Integer, SpecialBandwidthRateMonth> intoBandwidthRateNineEightMap = new HashMap<>();
                                //获取出带宽98峰值数据
                                Map<Integer, SpecialBandwidthRateMonth> outBandwidthRateNineEightMap = new HashMap<>();
                                if(!CollectionUtils.isEmpty(bandwidthRateNineEightCounts)){
                                    List<SpecialBandwidthRateMonth> intoBandwidthRateNineEights = bandwidthRateNineEightCounts.stream().filter(item->null != item.getIntoNineeightCount() && item.getIntoNineeightCount()>-1).collect(Collectors.toList());
                                    List<SpecialBandwidthRateMonth> outBandwidthRateNineEights = bandwidthRateNineEightCounts.stream().filter(item->null != item.getOutNineeightCount() && item.getOutNineeightCount()>-1).collect(Collectors.toList());
                                    if(!CollectionUtils.isEmpty(intoBandwidthRateNineEights)){
                                        List<SpecialBandwidthRateMonth> intoBandwidthRateNineEightList = extractSpecialClickDao.findIntoBandwidthRateNineEightBySpecialIds(intoBandwidthRateNineEights, startTime, endTime,true);
                                        if(!CollectionUtils.isEmpty(intoBandwidthRateNineEightList)){
                                            intoBandwidthRateNineEightMap = intoBandwidthRateNineEightList.stream().collect(Collectors.toMap(SpecialBandwidthRateMonth::getSpecialId, v -> v));
                                        }
                                    }
                                    if(!CollectionUtils.isEmpty(outBandwidthRateNineEights)){
                                        List<SpecialBandwidthRateMonth> outBandwidthRateNineEightList = extractSpecialClickDao.findOutBandwidthRateNineEightBySpecialIds(outBandwidthRateNineEights, startTime, endTime,true);
                                        if(!CollectionUtils.isEmpty(outBandwidthRateNineEightList)){
                                            outBandwidthRateNineEightMap = outBandwidthRateNineEightList.stream().collect(Collectors.toMap(SpecialBandwidthRateMonth::getSpecialId, v -> v));
                                        }
                                    }
                                }
                                //获取出入带宽最大值平均值
                                List<SpecialBandwidthRateMonth> maxAvgBandwidthRateMonths = extractSpecialClickDao.findSpecialBandwidthRateMonthBySpecialIds(batchIds, startTime, endTime,true);
                                Map<Integer, SpecialBandwidthRateMonth> maxAvgBandwidthRateMonthMap = new HashMap<>();
                                if(!CollectionUtils.isEmpty(maxAvgBandwidthRateMonths)){
                                    maxAvgBandwidthRateMonthMap = maxAvgBandwidthRateMonths.stream().collect(Collectors.toMap(SpecialBandwidthRateMonth::getSpecialId, v -> v));
                                }
                                for (Integer specialId : batchIds) {
                                    // 初始化数据对象
                                    SpecialBandwidthRateMonth saveSpecialBandwidthRateMonth = new SpecialBandwidthRateMonth();
                                    saveSpecialBandwidthRateMonth.setSpecialId(specialId);
                                    boolean isExistSpecialBandwidthRateMonth = false;
                                    //设置入带宽98峰值数据
                                    SpecialBandwidthRateMonth intoBandwidthRateNineEigh = intoBandwidthRateNineEightMap.get(specialId);
                                    if(null != intoBandwidthRateNineEigh){
                                        saveSpecialBandwidthRateMonth.setIntoNineeightbandwithRate(intoBandwidthRateNineEigh.getIntoNineeightbandwithRate());
                                        isExistSpecialBandwidthRateMonth = true;
                                    }
                                    //设置出带宽98峰值数据
                                    SpecialBandwidthRateMonth outBandwidthRateNineEigh = outBandwidthRateNineEightMap.get(specialId);
                                    if(null != outBandwidthRateNineEigh){
                                        saveSpecialBandwidthRateMonth.setOutNineeightbandwithRate(outBandwidthRateNineEigh.getOutNineeightbandwithRate());
                                        isExistSpecialBandwidthRateMonth = true;
                                    }
                                    //设置出入带宽最大值平均值
                                    SpecialBandwidthRateMonth maxAvgBandwidthRateMonth = maxAvgBandwidthRateMonthMap.get(specialId);
                                    if(null != maxAvgBandwidthRateMonth){
                                        saveSpecialBandwidthRateMonth.setMaxIntoBandwithRate(maxAvgBandwidthRateMonth.getMaxIntoBandwithRate());
                                        saveSpecialBandwidthRateMonth.setMaxOutBandwithRate(maxAvgBandwidthRateMonth.getMaxOutBandwithRate());
                                        saveSpecialBandwidthRateMonth.setAvgIntoBandwithRate(maxAvgBandwidthRateMonth.getAvgIntoBandwithRate());
                                        saveSpecialBandwidthRateMonth.setAvgOutBandwithRate(maxAvgBandwidthRateMonth.getAvgOutBandwithRate());
                                        isExistSpecialBandwidthRateMonth = true;
                                    }
                                    if(isExistSpecialBandwidthRateMonth){
                                        saveSpecialBandwidthRateMonth.setCreateTs(endTime);
                                        specialBandwidthRateMonths.add(saveSpecialBandwidthRateMonth);
                                    }
                                }
                            }
                            // 批量插入数据
                            if (specialBandwidthRateMonths.size() > 0) {
                                int batchSize = extractSflowAnalysisSaveCount;  // 优化批次大小
                                insertSpecialBandwidthRateMonthData(specialBandwidthRateMonths, batchSize, tableName, jdbcTemplate);
                            }
                        }
                        Map<String, String> paramMap = new HashMap<>(2);
                        String endTimeStr = DateUtil.timeStampToDateStr(endTime*1000l,DateUtil.YYYYMMDDHH0000);
                        paramMap.put("table", tableName);
                        paramMap.put("syncTime", endTimeStr);
                        // 保存或更新抽取时间
                        if (isFirstExtract) {
                            indexSyncDao.saveSyncDate(paramMap);
                            isFirstExtract = false;
                        } else {
                            indexSyncDao.updateSyncDate(paramMap);
                        }

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    log.error("SnmpFlowHourSpeedBandwith数据抽取小时执行失败: {}", e.getMessage(), e);
                } finally {
                    // 关闭插入数据线程池
                    /*insertDataExecutorService.shutdown();*/
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error("SnmpFlowHourSpeedBandwith数据抽取小时执行失败: {}", e.getMessage(), e);
        }
    }

    @Override
    public void analysisDataSpecialBandwidthRateMonthBefore(){
        try {
            Boolean isFirstExtract = true;
            String syncTime = indexSyncDao.getLastDateByName(tableName);
            if(StringUtils.isNotBlank(syncTime)){
                isFirstExtract = false;
            }
            // 获取当前时间范围的结束时间列表
            List<Long> endTimeList = new ArrayList<>();
            //获取三个月内所有的月数据
            handelSyncTimeToMonthCurrTimeAllMonths(syncTime, endTimeList);

            endTimeList = endTimeList.stream().distinct().sorted().collect(Collectors.toList());
            // 异步处理每个时间段的数据
            if (!CollectionUtils.isEmpty(endTimeList)) {
                //创建插入数据库线程数
//                ExecutorService insertDataExecutorService = Executors.newFixedThreadPool(insertDataThreadPool);
                try {
                    List<Integer> specialIds = extractSpecialDao.findAllSpecialIds();
                    for (Long endTime : endTimeList) {
                        // 计算每个时间段的起始时间，通过结束时间戳计算得到起始时间是上个月的01 00:00:00的时间戳
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTimeInMillis(endTime * 1000L);
                        calendar.add(Calendar.MONTH, -1); // 上个月
                        calendar.set(Calendar.DAY_OF_MONTH, 1); // 设置为1号
                        calendar.set(Calendar.HOUR_OF_DAY, 0);
                        calendar.set(Calendar.MINUTE, 0);
                        calendar.set(Calendar.SECOND, 0);
                        calendar.set(Calendar.MILLISECOND, 0);
                        Long startTime = calendar.getTimeInMillis() / 1000; // 转换为秒
                        extractSpecialClickDao.deleteSpecialBandwidthRateMonthByTime(startTime, endTime);
                        if(!CollectionUtils.isEmpty(specialIds)){
                            List<SpecialBandwidthRateMonth> specialBandwidthRateMonths = new ArrayList<>();
                            // 使用并行流处理大量数据，提高性能
                            specialIds.forEach(specialId -> {
                                // 初始化数据对象
                                SpecialBandwidthRateMonth saveSpecialBandwidthRateMonth = new SpecialBandwidthRateMonth();
                                saveSpecialBandwidthRateMonth.setSpecialId(specialId);
                                // 标记是否有有效数据
                                // 获取98%带宽数据
                                SpecialBandwidthRateMonth bandwidthRateNineEightCount = extractSpecialClickDao.getSpecialBandwidthRateNineEightCountBySpecialId(specialId, startTime, endTime);
                                if(null != bandwidthRateNineEightCount){
                                    if(null != bandwidthRateNineEightCount.getIntoNineeightCount() && bandwidthRateNineEightCount.getIntoNineeightCount()>-1){
                                        SpecialBandwidthRateMonth intoBandwidthRateNineEight = extractSpecialClickDao.getIntoBandwidthRateNineEightBySpecialId(specialId, startTime, endTime,bandwidthRateNineEightCount.getIntoNineeightCount());
                                        if(null != intoBandwidthRateNineEight){
                                            saveSpecialBandwidthRateMonth.setIntoNineeightbandwithRate(intoBandwidthRateNineEight.getIntoNineeightbandwithRate());
                                        }
                                    }
                                    if(null != bandwidthRateNineEightCount.getOutNineeightCount() && bandwidthRateNineEightCount.getOutNineeightCount()>-1){
                                        SpecialBandwidthRateMonth outBandwidthRateNineEight = extractSpecialClickDao.getOutBandwidthRateNineEightBySpecialId(specialId, startTime, endTime,bandwidthRateNineEightCount.getOutNineeightCount());
                                        if(null != outBandwidthRateNineEight){
                                            saveSpecialBandwidthRateMonth.setOutNineeightbandwithRate(outBandwidthRateNineEight.getOutNineeightbandwithRate());
                                        }
                                    }
                                }
                                //获取最大值和平均值
                                SpecialBandwidthRateMonth specialBandwidthRateMonth = extractSpecialClickDao.getSpecialBandwidthRateMonthBySpecialId(specialId, startTime, endTime);
                                if (specialBandwidthRateMonth != null) {
                                    /*saveSpecialBandwidthRateMonth.setIntoNineeightbandwithRate(specialBandwidthRateMonth.getIntoNineeightbandwithRate());
                                    saveSpecialBandwidthRateMonth.setOutNineeightbandwithRate(specialBandwidthRateMonth.getOutNineeightbandwithRate());*/
                                    saveSpecialBandwidthRateMonth.setMaxIntoBandwithRate(specialBandwidthRateMonth.getMaxIntoBandwithRate());
                                    saveSpecialBandwidthRateMonth.setMaxOutBandwithRate(specialBandwidthRateMonth.getMaxOutBandwithRate());
                                    saveSpecialBandwidthRateMonth.setAvgIntoBandwithRate(specialBandwidthRateMonth.getAvgIntoBandwithRate());
                                    saveSpecialBandwidthRateMonth.setAvgOutBandwithRate(specialBandwidthRateMonth.getAvgOutBandwithRate());
                                    saveSpecialBandwidthRateMonth.setCreateTs(endTime);
                                    specialBandwidthRateMonths.add(saveSpecialBandwidthRateMonth);
                                }
                                try {
                                    Thread.sleep(1 * 1000);
                                } catch (InterruptedException e1) {

                                }
                            });
                            // 批量插入数据
                            if (specialBandwidthRateMonths.size() > 0) {
                                int batchSize = extractSflowAnalysisSaveCount;  // 优化批次大小
                                /*List<CompletableFuture<Void>> insertDataFutures = newInsertSflowDataApplyDayData(specialBandwidthRateMonths, batchSize, tableName, insertDataExecutorService, jdbcTemplate);
                                  // 等待所有插入数据任务完成
                                CompletableFuture.allOf(insertDataFutures.toArray(new CompletableFuture[0])).join();*/
                                insertSpecialBandwidthRateMonthData(specialBandwidthRateMonths, batchSize, tableName, jdbcTemplate);
                            }
                        }
                        Map<String, String> paramMap = new HashMap<>(2);
                        String endTimeStr = DateUtil.timeStampToDateStr(endTime*1000l,DateUtil.YYYYMMDDHH0000);
                        paramMap.put("table", tableName);
                        paramMap.put("syncTime", endTimeStr);
                        // 保存或更新抽取时间
                        if (isFirstExtract) {
                            indexSyncDao.saveSyncDate(paramMap);
                            isFirstExtract = false;
                        } else {
                            indexSyncDao.updateSyncDate(paramMap);
                        }

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    log.error("SnmpFlowHourSpeedBandwith数据抽取小时执行失败: {}", e.getMessage(), e);
                } finally {
                    // 关闭插入数据线程池
                    /*insertDataExecutorService.shutdown();*/
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error("SnmpFlowHourSpeedBandwith数据抽取小时执行失败: {}", e.getMessage(), e);
        }
    }
    /**
     * 插入数据
     * @param resSflowDataVos 待插入的数据列表
     * @param batchSize 批次大小
     * @param tableName 表名
     * @param jdbcTemplate jdbc模板
     */
    private void insertSpecialBandwidthRateMonthData(List<SpecialBandwidthRateMonth> resSflowDataVos, int batchSize, String tableName, JdbcTemplate jdbcTemplate) {
        try {
            // 计算需要分成多少批次
            int totalBatches = (resSflowDataVos.size() + batchSize - 1) / batchSize;
            // 按批次处理数据
            for (int i = 0; i < totalBatches; i++) {
                int start = i * batchSize;
                int end = Math.min(resSflowDataVos.size(), start + batchSize);
                List<SpecialBandwidthRateMonth> batch = resSflowDataVos.subList(start, end);
                String sql = "INSERT INTO "+tableName+" (special_id,max_into_bandwith_rate, avg_into_bandwith_rate, into_nineeightbandwith_rate,max_out_bandwith_rate,avg_out_bandwith_rate,out_nineeightbandwith_rate, create_ts) VALUES (?, ?, ?, ?, ?, ?,?,?)";
                jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
                    @Override
                    public void setValues(PreparedStatement ps, int i) throws SQLException {
                        SpecialBandwidthRateMonth item = batch.get(i);
                        ps.setInt(1, item.getSpecialId());
                        ps.setDouble(2, null != item.getMaxIntoBandwithRate()?item.getMaxIntoBandwithRate():-1);
                        ps.setDouble(3, null != item.getAvgIntoBandwithRate()?item.getAvgIntoBandwithRate():-1);
                        ps.setDouble(4, null != item.getIntoNineeightbandwithRate()?item.getIntoNineeightbandwithRate():-1);
                        ps.setDouble(5, null != item.getMaxOutBandwithRate()?item.getMaxOutBandwithRate():-1);
                        ps.setDouble(6, null != item.getAvgOutBandwithRate()?item.getAvgOutBandwithRate():-1);
                        ps.setDouble(7, null != item.getOutNineeightbandwithRate()?item.getOutNineeightbandwithRate():-1);
                        ps.setLong(8, item.getCreateTs());
                    }
                    @Override
                    public int getBatchSize() {
                        return batch.size();
                    }
                });
            }
        } catch (Exception e) {
            log.error("批量插入数据失败: {}", e.getMessage(), e);
            throw new RuntimeException("批量插入数据失败", e);
        }
    }

    /**
     * 插入数据
     * @param resSflowDataVos
     * @param batchSize
     * @param tableName
     * @param insertDateexecutorService
     * @param jdbcTemplate
     * @return
     */
    private List<CompletableFuture<Void>> newInsertSflowDataApplyDayData(List<SpecialBandwidthRateMonth> resSflowDataVos, int batchSize, String tableName, ExecutorService insertDateexecutorService, JdbcTemplate jdbcTemplate) {
        // 将任务分成多个批次
        List<CompletableFuture<Void>> futures =  IntStream.range(0, (resSflowDataVos.size() + batchSize - 1) / batchSize)
                .mapToObj(i -> {
                    int start = i * batchSize;
                    int end = Math.min(resSflowDataVos.size(), start + batchSize);
                    List<SpecialBandwidthRateMonth> batch = resSflowDataVos.subList(start, end);
                    // 提交任务到线程池
                    return CompletableFuture.runAsync(() -> {
                        try {
                            String sql = "INSERT INTO "+tableName+" (special_id,max_into_bandwith_rate, avg_into_bandwith_rate, into_nineeightbandwith_rate,max_out_bandwith_rate,avg_out_bandwith_rate,out_nineeightbandwith_rate, create_ts) VALUES (?, ?, ?, ?, ?, ?,?,?)";
                            jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
                                @Override
                                public void setValues(PreparedStatement ps, int i) throws SQLException {
                                    SpecialBandwidthRateMonth item = batch.get(i);
                                    ps.setInt(1, item.getSpecialId());
                                    ps.setDouble(2, null != item.getMaxIntoBandwithRate()?item.getMaxIntoBandwithRate():-1);
                                    ps.setDouble(3, null != item.getAvgIntoBandwithRate()?item.getAvgIntoBandwithRate():-1);
                                    ps.setDouble(4, null != item.getIntoNineeightbandwithRate()?item.getIntoNineeightbandwithRate():-1);
                                    ps.setDouble(5, null != item.getMaxOutBandwithRate()?item.getMaxOutBandwithRate():-1);
                                    ps.setDouble(6, null != item.getAvgOutBandwithRate()?item.getAvgOutBandwithRate():-1);
                                    ps.setDouble(7, null != item.getOutNineeightbandwithRate()?item.getOutNineeightbandwithRate():-1);
                                    ps.setLong(8, item.getCreateTs());
                                }
                                @Override
                                public int getBatchSize() {
                                    return batch.size();
                                }
                            });
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }, insertDateexecutorService);
                }).collect(Collectors.toList());
        return futures;
    }

    /**
     * 获取所有的月份时间戳添加到endTimeList
     * 1syncTime不为空时获取syncDate到当前时间的所有月份
     * 2syncTime为空时获取当前月份往前推monthCount个月份
     * @param syncTime
     * @param endTimeList
     * @throws ParseException
     */
    private void handelSyncTimeToMonthCurrTimeAllMonths(String syncTime, List<Long> endTimeList) throws ParseException {
        if(StringUtils.isNotBlank(syncTime)){
            // 将syncTime转换为日期对象
            Date syncDate = DateUtil.str2DateTime(syncTime, DateUtil.YYYYMMDDHH0000);
            
            // 将syncDate设置为当月的1号0时
            Calendar syncCalendar = Calendar.getInstance();
            syncCalendar.setTime(syncDate);
            syncCalendar.set(Calendar.DAY_OF_MONTH, 1); // 设置为当月的1号
            syncCalendar.set(Calendar.HOUR_OF_DAY, 0);
            syncCalendar.set(Calendar.MINUTE, 0);
            syncCalendar.set(Calendar.SECOND, 0);
            syncCalendar.set(Calendar.MILLISECOND, 0);
            
            // 获取当前时间并设置为当月的1号0时
            Calendar currentCalendar = Calendar.getInstance();
            currentCalendar.set(Calendar.DAY_OF_MONTH, 1); // 设置为当月的1号
            currentCalendar.set(Calendar.HOUR_OF_DAY, 0);
            currentCalendar.set(Calendar.MINUTE, 0);
            currentCalendar.set(Calendar.SECOND, 0);
            currentCalendar.set(Calendar.MILLISECOND, 0);
            
            // 如果syncDate是月1号，则从下个月开始遍历
            Calendar iterateCalendar = (Calendar) syncCalendar.clone();
            iterateCalendar.add(Calendar.MONTH, 1); // 跳过syncDate所在的月份
            
            // 遍历从syncDate下个月到当前月的每个月的1号
            while (iterateCalendar.get(Calendar.YEAR) < currentCalendar.get(Calendar.YEAR) || 
                  (iterateCalendar.get(Calendar.YEAR) == currentCalendar.get(Calendar.YEAR) && 
                   iterateCalendar.get(Calendar.MONTH) <= currentCalendar.get(Calendar.MONTH))) {
                // 添加当前月的1号的时间戳（秒）
                endTimeList.add(iterateCalendar.getTimeInMillis() / 1000);
                // 移动到下个月的1号
                iterateCalendar.add(Calendar.MONTH, 1);
            }
        } else {
            // 获取当前时间往前推monthCount个月的所有月份
            Calendar calendar = Calendar.getInstance();
            // 设置为当月的1号0时
            calendar.set(Calendar.DAY_OF_MONTH, 1);
            calendar.set(Calendar.HOUR_OF_DAY, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            
            // 往前推monthCount-1个月（因为已经包含当前月）
            calendar.add(Calendar.MONTH, -(monthCount-1));
            
            // 遍历monthCount个月
            for (int i = 0; i < monthCount; i++) {
                // 添加当前月的时间戳（秒）
                endTimeList.add(calendar.getTimeInMillis() / 1000);
                // 移动到下一个月
                calendar.add(Calendar.MONTH, 1);
            }
        }
    }

//    public static void main(String[] args) throws ParseException {
//        SpecialBandwidthRateMonthServiceImpl service = new SpecialBandwidthRateMonthServiceImpl();
//        service.monthCount = 3; // 设置monthCount值
//
//        List<Long> endTimeList = new ArrayList<>();
//        service.handelSyncTimeToMonthCurrTimeAllMonths("", endTimeList);
//        for (Long endTime:endTimeList) {
//            System.out.println(endTime+"月份时间戳: "+DateUtil.timeStampToDateStr(endTime*1000l,DateUtil.YYYYMMDDHH0000));
//        }
//    }
}
