package com.wdkj.plugs.extract.dao.mysql;

import com.wdkj.plugs.model.po.RunTimeDataPo;
import com.wdkj.plugs.model.po.RunTimeRecordPo;
import org.mapstruct.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;


@Mapper
@Repository
public interface IRunTimeDao {

    void insertData(List<RunTimeDataPo> dataList);

    void insertRecord(RunTimeRecordPo recordPo);

    List<RunTimeRecordPo> findRecordList(Long startTime, Integer type);
}
