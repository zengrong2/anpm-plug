package com.wdkj.plugs.extract.dao.click;

import com.wdkj.plugs.model.po.DelayLossData;
import com.wdkj.plugs.model.po.DelaySnmpData;
import com.wdkj.plugs.model.po.ExtractSnmpData;
import com.wdkj.plugs.model.vo.DevFlowVo;
import com.wdkj.plugs.model.vo.SnmpFlowVo;
import com.wdkj.plugs.model.vo.VRunTime;
import org.apache.ibatis.annotations.Param;
import org.mapstruct.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @ClassName ExtractSnmpClickDao
 * @Description TODO
 * @Author Mr.xie
 * @Date 2021/10/13 17:01
 */
@Mapper
@Repository
public interface IExtractSnmpClickDao {
    DelayLossData getDelayLoss(@Param("tableName") String tableName, @Param("linkId") Integer linkId, @Param("startTimeSecond") Long startTimeSecond, @Param("endTimeSecond") Long endTimeSecond);

    List<VRunTime> getRunTimeList(@Param("startTimeSecond")Long startTimeSecond,@Param("endTimeSecond") Long endTimeSecond);

    List<DevFlowVo> getDevFlowSpeed(@Param("startTimeSecond")Long startTimeSecond,@Param("endTimeSecond") Long endTimeSecond);

    void save(List<ExtractSnmpData> list);

    List<VRunTime> getRepairRunTimeList(@Param("startTimeSecond")Long startTimeSecond,@Param("endTimeSecond") Long endTimeSecond);

    List<DelaySnmpData> getDelayList(@Param("tableName") String tableName, @Param("linkIds") List<Integer> linkId, @Param("startTimeSecond") Long startTimeSecond, @Param("endTimeSecond") Long endTimeSecond);

    List<SnmpFlowVo> findSpeedBandwithByStartAndEndTime(@Param("startTime")Long startTime, @Param("endTime")Long endTime);

    void deleteSnmpFlowHourSpeedBandwithByTime(@Param("startTime")Long startTime, @Param("endTime")Long endTime);
}
