package com.wdkj.plugs.extract.dao.mysql;

import com.wdkj.plugs.model.po.TaskDestIpNamePo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author 郑兴泉 956607644@qq.com
 * @data 2024/9/12
 * 描述：
 */
@Mapper
@Deprecated
public interface SysDialConfigDestIpNameDao {

    @Deprecated
    List<TaskDestIpNamePo> queryTaskDestIpName(@Param("taskIds") List<Integer> taskIds);
    @Deprecated
    List<Integer> queryTaskAllByTaskId();
    @Deprecated
    void deleteAll();
    @Deprecated
    List<Integer> queryExistsDestIpNameByTaskId();

}
