package com.wdkj.plugs.extract.service;

/**
 * Description: 中继健康档案抽取service
 * Created by zoujian ON 2021/4/14.
 */
public interface IFlowExtractService {

    //抽取流量小时数据
    void extractFlowHourData(String startTime, String endTime);

    //抽取流量天数据
    void extractFlowDayData(String startTime, String endTime);


}
