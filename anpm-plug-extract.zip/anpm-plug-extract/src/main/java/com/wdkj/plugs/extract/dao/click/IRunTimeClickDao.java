package com.wdkj.plugs.extract.dao.click;

import com.wdkj.plugs.model.vo.RunTimeDataVo;
import org.mapstruct.Mapper;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;

@Mapper
@Repository
public interface IRunTimeClickDao {

	List<RunTimeDataVo> findLinkData(Long startTime, Long endTime, Integer type);

	List<RunTimeDataVo> findTaskData(Long startTime, Long endTime, Integer type,Integer taskType);
}
