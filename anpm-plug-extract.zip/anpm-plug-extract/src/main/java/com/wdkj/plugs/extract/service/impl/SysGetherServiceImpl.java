package com.wdkj.plugs.extract.service.impl;

import com.wdkj.plugs.extract.dao.mysql.ISysGetherDao;
import com.wdkj.plugs.extract.service.SysGetherService;
import com.wdkj.plugs.model.po.SysGether;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Service
public class SysGetherServiceImpl implements SysGetherService {

    @Resource
    private ISysGetherDao sysGetherDao;

    @Override
    public void updateSysGether() {
        List<SysGether> list = sysGetherDao.getList();
        Integer heartTimeOut = sysGetherDao.getGetherAlarmCount();
        List<Integer> ids = new ArrayList<Integer>();
        //当前时间戳
        long nowTime = getTs();
        for (SysGether bean : list) {
            if (Objects.isNull(bean.getLastActiveTs())) {
                continue;
            }
            //如果当前时间和采集器上报时间差大于配置的时间差，比如大于3分钟，那么要更新状态为离线
            if (nowTime - bean.getLastActiveTs() > heartTimeOut * 60) {
                ids.add(bean.getId());
            }
        }
        if (!CollectionUtils.isEmpty(ids)) {
            sysGetherDao.updateByIds(ids);
        }
    }

    public static int getTs() {
        double d = ((new Date()).getTime()) / 1000;
        int ts = (int) Math.floor(d);
        return ts;
    }

    @Override
    public void updateSflowSnmpGether() {
        List<SysGether> list = sysGetherDao.getSflowList();
        // 数据库中默认配置的就是秒
        Integer heartTimeOut = sysGetherDao.getSflowGetherAlarmCount();
        List<Integer> ids = new ArrayList<Integer>();
        //当前时间戳
        long nowTime = getTs();
        for (SysGether bean : list) {
            if (Objects.isNull(bean.getLastActiveTs())) {
                continue;
            }
            //如果当前时间和采集器上报时间差大于配置的时间差，比如大于3分钟，那么要更新状态为离线
            if (nowTime - bean.getLastActiveTs() > heartTimeOut * 3) {
                ids.add(bean.getId());
            }
        }
        if (!CollectionUtils.isEmpty(ids)) {
            sysGetherDao.updateSflowByIds(ids);
        }
    }
}
