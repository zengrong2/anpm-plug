package com.wdkj.plugs.extract.web;

import com.wdkj.plugs.core.model.to.Result;
import com.wdkj.plugs.extract.service.SysGetherService;
import com.wdkj.plugs.utils.enu.MessageEnum;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @ClassName UpdateSnmpRepeatController
 * @Description TODO
 * @Author Mr.xie
 * @Date 2021/7/15 15:34
 */
@RestController
@RequestMapping("/sysGether")
public class UpdateSysGetherController {
    @Autowired
    private SysGetherService sysGetherService;

    @PostMapping("/update")
    @ApiOperation(value = "更新探针状态", httpMethod = "POST")
    public Result<?> update() {
        try {
            sysGetherService.updateSysGether();
            return new Result<>(MessageEnum.SUCCESS);
        } catch (Exception e) {
            e.printStackTrace();
            return new Result<>(MessageEnum.FAIL,e.getMessage());
        }
    }

}
