package com.wdkj.plugs.extract.dao.mysql;


import com.wdkj.plugs.model.bo.FlowAnalysisQuery;
import com.wdkj.plugs.model.po.RunTimeRecordPo;
import com.wdkj.plugs.model.po.SysDataTable;
import com.wdkj.plugs.model.vo.FlowAnalysisVo;
import com.wdkj.plugs.model.vo.SflowDataVo;
import com.wdkj.plugs.model.vo.SnmpDevPortVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Collection;
import java.util.List;

@Mapper
public interface IFlowAnalysisDao {


    List<FlowAnalysisVo> getPageList(@Param("flowAnalysisQuery")FlowAnalysisQuery flowAnalysisQuery,@Param("groupIds") String[] groupIds);


    void updateDeviceFlowReport(@Param("devIds")List<Integer> devIds, @Param("flowReport")Integer flowReport);

    SysDataTable getSysDataTableByKey(@Param("key")String key);

    List<SnmpDevPortVo> queryPortsByDeviceId(@Param("deviceId")Integer deviceId);

    List<FlowAnalysisVo> findDeviceList(@Param("flowAnalysisQuery")FlowAnalysisQuery flowAnalysisQuery);

    List<Integer> findDeviceId();

    void insertRecord(RunTimeRecordPo recordPo);

    List<RunTimeRecordPo> findGreaterThanRecordList(Long startTime, Integer type);

    List<RunTimeRecordPo> findLessThanCurrRecordList(Long startTime, Integer type);

    RunTimeRecordPo getEquelCurrRecordList(Long startTime, Integer type);

    Long findRecordDayHourCountByTime(@Param("startTime")Long startTime, @Param("endTime")Long endTime, @Param("hourType")Integer hourType);
}