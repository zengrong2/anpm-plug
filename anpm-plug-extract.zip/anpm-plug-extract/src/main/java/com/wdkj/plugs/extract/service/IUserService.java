package com.wdkj.plugs.extract.service;

/**
 * @description:
 * @author: guoyang
 * @date: 2022/12/26
 **/

public interface IUserService {
    /**
     * 激活账号  只能激活因输错密码被休眠的用户
     */
    void activeUser();

    /**
     * 休眠账号，密码过期，临期账号 到期会被休眠
     */
    void inactiveUser();
}
