package com.wdkj.plugs.extract.schedule;

import com.wdkj.plugs.extract.service.IFlowExtractService;
import com.wdkj.plugs.systemlog.service.ISystemLogService;
import com.wdkj.plugs.utils.enu.LogLevelEnum;
import com.wdkj.plugs.utils.enu.LogTypeEnum;
import com.wdkj.plugs.utils.enu.ServiceTypeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Description:
 * Created by zoujian ON 2021/4/14.
 */
@Component
public class FlowDayExtractSchedule {

    private static final Logger logger = LoggerFactory.getLogger(FlowDayExtractSchedule.class);


    @Autowired
    private IFlowExtractService flowExtractService;
    @Autowired
    private ISystemLogService systemLogService;



    @Scheduled(cron = "0 5/30 * * * ? ")
    public void extractFlowDayData(){
        try{
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Calendar nowCalendar = Calendar.getInstance();
            logger.info("开始抽取流量天数据。。。。。" + sdf.format(nowCalendar.getTime()));
            //计算抽取开始结束时间，抽取1分钟以前当前数据
            nowCalendar.add(Calendar.MINUTE, -5);
            String endTime = sdf.format(nowCalendar.getTime());
            //刚好跨天处理
            if(nowCalendar.get(Calendar.HOUR) == 0 && nowCalendar.get(Calendar.MINUTE) == 0){
                nowCalendar.add(Calendar.DAY_OF_MONTH, -1);//抽取昨天数据
            }
            //开始时间天凌晨
            nowCalendar.set(Calendar.HOUR_OF_DAY, 0);
            nowCalendar.set(Calendar.MINUTE, 0);
            nowCalendar.set(Calendar.SECOND, 0);
            String startTime = sdf.format(nowCalendar.getTime());

            //执行抽取
            flowExtractService.extractFlowDayData(startTime, endTime);

            nowCalendar = Calendar.getInstance();
            logger.info("抽取流量天数据完成！ " + sdf.format(nowCalendar.getTime()));

        }catch (Exception ee){
            logger.error("抽取流量天数据异常：={}", ee.getMessage() );
            systemLogService.saveLog(LogLevelEnum.LEVEL1.code(),ee.getMessage(), ServiceTypeEnum.EXTRACT.lable(), LogTypeEnum.LOG_TYPE_ERROR.lable(),"抽取流量天数据", this.getClass().getName(), Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

}
