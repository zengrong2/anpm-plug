package com.wdkj.plugs.extract.service;

import com.wdkj.plugs.model.po.ExtractSpecialData;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @ClassName IExtractSpecialService
 * @Description TODO
 * @Author Mr.xie
 * @Date 2020/11/12 11:36
 */
public interface IExtractSpecialService {

    void batchSaveData(List<ExtractSpecialData> saveList);

    void saveSpecialData(Boolean isFirstExtract, LocalDateTime startTime, LocalDateTime end) throws IOException, ClassNotFoundException;
}
