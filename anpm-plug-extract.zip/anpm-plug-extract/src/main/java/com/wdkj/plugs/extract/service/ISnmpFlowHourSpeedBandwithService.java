package com.wdkj.plugs.extract.service;

import java.text.ParseException;

public interface ISnmpFlowHourSpeedBandwithService {
    void analysisDataSnmpFlowHour() throws ParseException;
}
