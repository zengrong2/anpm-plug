package com.wdkj.plugs.extract.service;

import com.wdkj.plugs.model.po.ExtractSnmpData;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @ClassName ExtractSnmpService
 * @Description TODO
 * @Author Mr.xie
 * @Date 2021/10/13 16:59
 */
public interface IExtractSnmpService {


    void batchSaveData(List<ExtractSnmpData> saveList);

    void saveSnmpData(Boolean isFirstExtract, LocalDateTime startTime, LocalDateTime end) throws IOException, ClassNotFoundException;
}
