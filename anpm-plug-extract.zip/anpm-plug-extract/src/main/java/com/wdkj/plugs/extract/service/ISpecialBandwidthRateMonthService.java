package com.wdkj.plugs.extract.service;

import java.text.ParseException;

public interface ISpecialBandwidthRateMonthService {

    void analysisDataSpecialBandwidthRateMonth() throws ParseException;

    void analysisDataSpecialBandwidthRateMonthBefore() throws ParseException;
}
