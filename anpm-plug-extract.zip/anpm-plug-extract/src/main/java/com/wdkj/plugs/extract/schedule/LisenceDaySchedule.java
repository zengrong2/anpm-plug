package com.wdkj.plugs.extract.schedule;

import com.wdkj.plugs.extract.service.ILisenceDayService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class LisenceDaySchedule {

    private static Logger log = LoggerFactory.getLogger(LisenceDaySchedule.class);

    @Autowired
    private ILisenceDayService iLisenceDayService;

    /**
     * 任务执行频率，5分钟检查一次
     */
    @Scheduled(cron = "0 */5 * * * *")
    public void checkLicence() {
        try {
            iLisenceDayService.checkLicence();
        } catch (Exception e) {
            log.error("licence check error ! error={}", e.getMessage());
        }
    }
}
