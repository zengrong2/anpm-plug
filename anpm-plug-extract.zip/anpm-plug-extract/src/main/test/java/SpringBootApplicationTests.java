
import com.wdkj.plugs.extract.AnpmPlugExtractApplication;
import com.wdkj.plugs.extract.schedule.ProbeTaskIpOrMacUpdateSchedule;
import com.wdkj.plugs.extract.service.IUserService;
import com.wdkj.plugs.extract.service.IpMacService;
import org.checkerframework.checker.units.qual.A;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = AnpmPlugExtractApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class SpringBootApplicationTests {
    @Autowired
    private IUserService userService;
    @Autowired
    private IpMacService ipMacService;
    @Test
    public void  test1() {
        userService.inactiveUser();
    }

    @Test
    public void  test2() {
        ipMacService.excute();
    }
}
